"""Pydantic schemas for the CEFR curriculum (Phase 7.4)."""

from __future__ import annotations

from pydantic import BaseModel, Field


class CurriculumObjectiveOut(BaseModel):
    id: str
    level: str
    title: str
    grammar: str = ""
    vocab: str = ""
    example: str = ""
    feature: str
    status: str = "new"


class CurriculumLevelOut(BaseModel):
    level: str
    status: str


class CurriculumOverviewOut(BaseModel):
    current_level: str
    next_level: str | None = None
    mastery_progress_percent: int = 0
    objectives_total: int = 0
    objectives_mastered: int = 0
    levels: list[CurriculumLevelOut] = Field(default_factory=list)
    objectives: list[CurriculumObjectiveOut] = Field(default_factory=list)


class ObjectivePracticeIn(BaseModel):
    objective_id: str


class ObjectivePracticeOut(BaseModel):
    objective_id: str
    status: str
    practice_count: int = 0


class DailyPlanItemOut(BaseModel):
    kind: str
    title: str
    feature: str
    focus: str | None = None
    objective_id: str | None = None
    detail: str | None = None
    done: bool = False


class DailyPlanOut(BaseModel):
    current_level: str | None = None
    adaptive_recommendation: str = "MAINTAIN"
    adaptive_detail_ar: str | None = None
    mastery_progress_percent: int = 0
    objectives_mastered: int = 0
    objectives_total: int = 0
    goal: int = 0
    completed_today: int = 0
    due_vocab: int = 0
    items: list[DailyPlanItemOut] = Field(default_factory=list)


class PromotionQuestionOut(BaseModel):
    id: int
    prompt: str
    choices: list[str] = Field(default_factory=list)


class PromotionTestOut(BaseModel):
    test_id: str
    level: str
    pass_ratio: float = 0.8
    questions: list[PromotionQuestionOut] = Field(default_factory=list)
    eligible: bool = True
    next_level: str | None = None


class PromotionSubmitIn(BaseModel):
    test_id: str
    answers: dict[str, int] = Field(default_factory=dict)


class PromotionResultOut(BaseModel):
    score_percent: int = 0
    correct: int = 0
    total: int = 0
    passed: bool = False
    promoted: bool = False
    new_level: str | None = None
    expired: bool = False
