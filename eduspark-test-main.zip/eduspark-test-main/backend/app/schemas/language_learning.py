from datetime import date, datetime

from typing import Literal

from pydantic import BaseModel, Field


class LessonProgressOut(BaseModel):
    status: str = "not_started"
    score_percent: float | None = None
    completed_at: datetime | None = None
    attempt_count: int = 0


class LessonListItemOut(BaseModel):
    id: int
    title: str
    level: str
    sort_order: int
    progress: LessonProgressOut
    audio_available: bool | None = None


class LessonListOut(BaseModel):
    student_level: str
    lesson_level: str | None = None
    lessons: list[LessonListItemOut] = Field(default_factory=list)


class LessonQuestionOut(BaseModel):
    id: str
    type: str = "mcq"
    stem: str
    choices: list[str]


class ReadingLessonOut(BaseModel):
    id: int
    title: str
    level: str
    passage: str
    passage_ar: str | None = None
    questions: list[LessonQuestionOut]
    progress: LessonProgressOut


class ListeningLessonOut(BaseModel):
    id: int
    title: str
    level: str
    instructions: str | None = None
    questions: list[LessonQuestionOut]
    audio_url: str | None = None
    audio_available: bool = False
    progress: LessonProgressOut


class LessonSubmitIn(BaseModel):
    answers: dict[str, dict] = Field(default_factory=dict)


class LessonSubmitOut(BaseModel):
    content_item_id: int
    score_percent: float
    passed: bool
    status: str
    attempt_count: int
    completed_at: datetime | None = None
    correct_count: int
    total_questions: int


class SkillGrowthSkillOut(BaseModel):
    level: str | None = None
    growth_percent: int = 0
    lessons_completed: int = 0
    lessons_total: int = 0
    average_score_percent: float | None = None


class SkillGrowthOut(BaseModel):
    reading: SkillGrowthSkillOut | None = None
    listening: SkillGrowthSkillOut | None = None
    writing: SkillGrowthSkillOut | None = None
    speaking: SkillGrowthSkillOut | None = None
    vocabulary: dict | None = None


class VocabularyMetricsOut(BaseModel):
    total_words: int = 0
    known_words: int = 0
    learning_words: int = 0
    new_words: int = 0


class VocabularyCardOut(BaseModel):
    id: int
    word: str
    translation_ar: str | None = None
    example: str | None = None
    example_ar: str | None = None
    level: str | None = None
    status: str = "new"
    review_count: int = 0
    last_reviewed_at: datetime | None = None


class VocabularyListOut(BaseModel):
    student_level: str
    lesson_level: str | None = None
    metrics: VocabularyMetricsOut
    cards: list[VocabularyCardOut] = Field(default_factory=list)


class VocabularyReviewIn(BaseModel):
    action: Literal["known", "review_later"]


class WritingPromptOut(BaseModel):
    id: int
    title: str
    level: str | None = None
    prompt: str
    prompt_ar: str | None = None
    min_words: int = 20
    min_sentences: int = 2
    progress: dict = Field(default_factory=dict)


class WritingListOut(BaseModel):
    student_level: str
    lesson_level: str | None = None
    prompts: list[WritingPromptOut] = Field(default_factory=list)


class WritingSubmitIn(BaseModel):
    response_text: str


class WritingSubmitOut(BaseModel):
    prompt_id: int
    score_percent: float
    passed: bool
    word_count: int
    sentence_count: int
    completed_at: datetime | None = None
    status: str
    scoring_version: str | None = None
    feedback: str | None = None
    feedback_ar: str | None = None
    estimated_cefr: str | None = None
    criteria: dict | None = None


class SpeakingPromptOut(BaseModel):
    id: int
    title: str
    level: str | None = None
    prompt: str
    prompt_ar: str | None = None
    min_seconds: int = 20
    progress: dict = Field(default_factory=dict)


class SpeakingListOut(BaseModel):
    student_level: str
    lesson_level: str | None = None
    prompts: list[SpeakingPromptOut] = Field(default_factory=list)


class SpeakingSubmitIn(BaseModel):
    media_object_id: int
    duration_seconds: int | None = None


class SpeakingCoachDetailOut(BaseModel):
    what_was_good: str | None = None
    biggest_mistake: str | None = None
    better_version: str | None = None
    pronunciation_tip: str | None = None
    fluency_tip: str | None = None
    grammar_tip: str | None = None


class SpeakingAttemptSnapshotOut(BaseModel):
    attempt: int
    transcript: str | None = None
    score_percent: float | None = None
    grammar_errors: int = 0
    fluency_score: float | None = None
    estimated_cefr: str | None = None
    retry_sentence: str | None = None


class SpeakingAttemptComparisonOut(BaseModel):
    attempt_1: SpeakingAttemptSnapshotOut | None = None
    attempt_2: SpeakingAttemptSnapshotOut | None = None
    improvement_score: float | None = None
    grammar_improvement: int | None = None
    fluency_improvement: float | None = None


class ShadowSentenceOut(BaseModel):
    id: int
    text: str
    level: str
    source: str = "level"


class ShadowSentenceListOut(BaseModel):
    level: str
    sentences: list[ShadowSentenceOut] = Field(default_factory=list)
    focus: str | None = None


class ShadowSubmitOut(BaseModel):
    transcript: str | None = None
    similarity: int
    overall_score: int
    words: list[dict] = Field(default_factory=list)
    weak_words: list[str] = Field(default_factory=list)
    note: str | None = None
    passed: bool


class SpeakingSubmitOut(BaseModel):
    prompt_id: int
    media_object_id: int
    public_url: str | None = None
    duration_seconds: int | None = None
    score_percent: float
    passed: bool
    completed_at: datetime | None = None
    status: str
    scoring_version: str | None = None
    transcript: str | None = None
    correction_text: str | None = None
    grammar_errors: list[dict] = Field(default_factory=list)
    reply: str | None = None
    reply_audio_url: str | None = None
    feedback: str | None = None
    feedback_ar: str | None = None
    estimated_cefr: str | None = None
    criteria: dict | None = None
    coach_feedback: str | None = None
    coach_feedback_ar: str | None = None
    retry_sentence: str | None = None
    improvement_score: float | None = None
    grammar_improvement: int | None = None
    fluency_improvement: float | None = None
    attempt_number: int = 1
    coach_detail: SpeakingCoachDetailOut | None = None
    attempt_comparison: SpeakingAttemptComparisonOut | None = None


class LanguageHubPlacementOut(BaseModel):
    completed_at: datetime | None = None
    overall_level: str | None = None
    can_retake: bool = False
    next_allowed_retake_date: datetime | None = None


class LanguageHubPathOut(BaseModel):
    path_id: int | None = None
    generated_at: datetime | None = None
    items_total: int = 0
    items_completed: int = 0


class LanguageHubOut(BaseModel):
    levels: dict[str, str | None] = Field(default_factory=dict)
    skill_growth: SkillGrowthOut = Field(default_factory=SkillGrowthOut)
    target_level: str | None = None
    target_date: date | None = None
    placement: LanguageHubPlacementOut | None = None
    learning_path: LanguageHubPathOut = Field(default_factory=LanguageHubPathOut)
    quick_stats: dict[str, int | float] = Field(default_factory=dict)
    widgets: dict = Field(default_factory=dict)


class ActivityEventItemOut(BaseModel):
    id: int
    event_type: str
    skill: str | None = None
    title: str | None = None
    score_percent: float | None = None
    created_at: datetime


class SpeakingCorrectionDisplayOut(BaseModel):
    has_errors: bool = False
    no_correction_message: str | None = None
    your_sentence: str | None = None
    corrected_sentence: str | None = None
    explanation: str | None = None
    speech_prefix: str | None = None


class SpeakingConversationMessageOut(BaseModel):
    role: Literal["user", "assistant"]
    content: str
    turn_index: int | None = None
    evaluation: dict | None = None
    correction_display: SpeakingCorrectionDisplayOut | None = None
    reply_audio_url: str | None = None
    reply_audio_pending: bool = False


class SpeakingTurnCorrectionOut(BaseModel):
    has_errors: bool = False
    original: str = ""
    corrected: str = ""
    errors: list[dict] = Field(default_factory=list)


class SpeakingTurnScoresOut(BaseModel):
    fluency: int = 0
    grammar: int = 0
    vocabulary: int = 0
    confidence: int = 0


class SpeakingTurnEvaluationOut(BaseModel):
    correction: SpeakingTurnCorrectionOut = Field(default_factory=SpeakingTurnCorrectionOut)
    correction_display: SpeakingCorrectionDisplayOut | None = None
    scores: SpeakingTurnScoresOut = Field(default_factory=SpeakingTurnScoresOut)
    estimated_cefr: str | None = None
    coaching_note_ar: str | None = None
    grammar_tool_used: bool = False
    topic: str | None = None
    reply_audio_pending: bool = False


class SpeakingConversationStateOut(BaseModel):
    session_id: int | None = None
    effective_speaking_level: str | None = None
    turn_count: int = 0
    messages: list[SpeakingConversationMessageOut] = Field(default_factory=list)
    welcome_hint: str | None = None


class SpeakingConversationTurnOut(BaseModel):
    session_id: int
    turn_index: int
    transcript: str
    evaluation: SpeakingTurnEvaluationOut
    correction_display: SpeakingCorrectionDisplayOut
    reply: str
    reply_audio_url: str | None = None
    reply_audio_pending: bool = False
    effective_speaking_level: str | None = None
    level_changed: bool = False
    timing_ms: dict[str, int] = Field(default_factory=dict)


class SpeakingConversationProgressOut(BaseModel):
    effective_speaking_level: str | None = None
    placement_baseline_level: str | None = None
    conversation_turns_total: int = 0
    sessions_completed: int = 0
    average_scores: SpeakingTurnScoresOut = Field(default_factory=SpeakingTurnScoresOut)
    level_trend: str | None = None
    last_conversation_at: datetime | None = None


class SpeakingConversationResetOut(BaseModel):
    ok: bool = True


class LanguageProgressOut(BaseModel):
    overall_level: str | None = None
    reading_level: str | None = None
    listening_level: str | None = None
    writing_level: str | None = None
    speaking_level: str | None = None
    skill_growth: SkillGrowthOut = Field(default_factory=SkillGrowthOut)
    completed_activities: int = 0
    reading_completion_percent: int = 0
    listening_completion_percent: int = 0
    vocabulary_count: int = 0
    vocabulary_learned: int = 0
    vocabulary_learning: int = 0
    writing_completed: int = 0
    speaking_completed: int = 0
    writing_completion_percent: int = 0
    speaking_completion_percent: int = 0
    current_streak: int = 0
    longest_streak: int = 0
    recent_activity: list[ActivityEventItemOut] = Field(default_factory=list)
    target_level: str | None = None
    target_date: date | None = None
    analytics: dict = Field(default_factory=dict)
