"""Student Language Learning — access, placement, and Phase C1 lessons."""

from fastapi import APIRouter, BackgroundTasks, Depends, File, Form, HTTPException, UploadFile, status
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.deps import require_student_actor
from app.db.session import get_db
from app.models.language.assessment import LanguageAssessmentSkillScore
from app.models.language.enums import LanguageSkill
from app.models.language.placement import LanguagePlacementAttempt
from app.models.user import User
from app.schemas.language import LanguageAccessOut, LanguageProductOut, LanguageSubscribeOut, LanguageSubscribeRequest
from app.schemas.language_learning import (
    LanguageHubOut,
    LanguageProgressOut,
    LessonListItemOut,
    LessonListOut,
    LessonProgressOut,
    LessonSubmitIn,
    LessonSubmitOut,
    ListeningLessonOut,
    ReadingLessonOut,
    SpeakingListOut,
    SpeakingPromptOut,
    SpeakingConversationProgressOut,
    SpeakingConversationResetOut,
    SpeakingConversationStateOut,
    SpeakingConversationTurnOut,
    ShadowSentenceListOut,
    ShadowSubmitOut,
    SpeakingSubmitIn,
    SpeakingSubmitOut,
    VocabularyCardOut,
    VocabularyListOut,
    VocabularyReviewIn,
    WritingListOut,
    WritingPromptOut,
    WritingSubmitIn,
    WritingSubmitOut,
)
from app.schemas.language_placement import (
    PlacementResultsOut,
    PlacementSaveResponseIn,
    PlacementSaveResponseOut,
    PlacementSpeakingUploadOut,
    PlacementStartOut,
    PlacementSubmitIn,
)
from app.schemas.language_adaptive import AdaptiveStateOut
from app.schemas.language_analytics import LanguageAchievementsOut, LanguageAnalyticsDashboardOut
from app.schemas.language_certificate import LanguageCertificateListOut
from app.schemas.language_scenario import (
    ScenarioDetailOut,
    ScenarioEndIn,
    ScenarioEndOut,
    ScenarioListOut,
    ScenarioSessionOut,
    ScenarioStartOut,
    ScenarioTurnIn,
    ScenarioTurnOut,
)
from app.schemas.language_curriculum import (
    CurriculumOverviewOut,
    DailyPlanOut,
    ObjectivePracticeIn,
    ObjectivePracticeOut,
    PromotionResultOut,
    PromotionSubmitIn,
    PromotionTestOut,
)
from app.services.language_access_service import (
    build_language_access,
    require_active_language_subscription,
    require_language_learning_ready,
)
from app.services.language_content_service import (
    get_listening_lesson,
    get_reading_lesson,
    lesson_body_for_student,
    list_lessons,
    resolve_listening_audio,
)
from app.services.language_hub_service import build_language_hub, build_language_progress
from app.services.language_placement_service import (
    get_bank_with_responses,
    save_response,
    start_or_resume_attempt,
    submit_attempt,
    upload_speaking_audio,
)
from app.services.language_skill_progress_service import submit_listening, submit_reading
from app.services.language_tts_service import get_lesson_audio
from app.services.language_speaking_service import (
    get_speaking_prompt,
    list_speaking,
    submit_speaking,
    upload_speaking_recording,
)
from app.services.language_conversation_service import (
    get_conversation_progress,
    get_conversation_state,
    process_conversation_turn,
    reset_conversation,
)
from app.services.language_shadowing_service import list_shadow_sentences, submit_shadow
from app.services.language_conversation_scenario_service import (
    SCENARIO_CATEGORIES,
    end_session_with_feedback,
    get_scenario_detail,
    get_scenario_session,
    list_scenarios,
    process_scenario_turn,
    process_scenario_voice_turn,
    start_scenario_session,
)
from app.services.language_subscription_service import get_default_product, subscribe_language, get_default_language
from app.services.language_vocabulary_service import get_vocabulary_card, list_vocabulary, review_vocabulary
from app.services.language_vocabulary_sr_service import (
    count_due,
    get_review_queue,
    get_vocabulary_stats,
    submit_review,
)
from app.services.language_writing_service import get_writing_prompt, list_writing, submit_writing
from app.services.language_certificate_service import list_student_certificates
from app.services.language_promotion_test_service import build_promotion_test, grade_promotion_test
from app.services.language_curriculum_service import build_curriculum_overview, record_objective_practice
from app.services.language_daily_plan_service import build_daily_plan
from app.services.language_adaptive_service import build_adaptive_state
from app.services.language_achievement_service import list_student_achievements
from app.services.language_analytics_dashboard_service import build_language_analytics_dashboard
from app.services.language_microlesson_service import get_micro_lesson

router = APIRouter(prefix="/student/languages", tags=["Language Learning"])


def _progress_out(row) -> LessonProgressOut:
    if not row:
        return LessonProgressOut()
    return LessonProgressOut(
        status=row.status.value if hasattr(row.status, "value") else str(row.status),
        score_percent=row.score_percent,
        completed_at=row.completed_at,
        attempt_count=int(row.attempt_count or 0),
    )


@router.get("/access", response_model=LanguageAccessOut)
async def language_access(
    student: User = Depends(require_student_actor()),
    db: AsyncSession = Depends(get_db),
):
    return await build_language_access(db, student.id)


@router.get("/product", response_model=LanguageProductOut)
async def language_product(db: AsyncSession = Depends(get_db)):
    product = await get_default_product(db)
    return LanguageProductOut(
        id=product.id,
        slug=product.slug,
        name_ar=product.name_ar,
        description_ar=product.description_ar,
        price=product.price,
        currency=product.currency,
        term_days=product.term_days,
    )


@router.post("/subscribe", response_model=LanguageSubscribeOut)
async def language_subscribe(
    body: LanguageSubscribeRequest,
    student: User = Depends(require_student_actor()),
    db: AsyncSession = Depends(get_db),
):
    result = await subscribe_language(db, student.id, body.method)
    await db.commit()
    return result


@router.post("/placement/start", response_model=PlacementStartOut)
async def placement_start(
    student: User = Depends(require_active_language_subscription()),
    db: AsyncSession = Depends(get_db),
):
    attempt_id, language_id = await start_or_resume_attempt(db, student_id=student.id)
    sections, questions, responses_by_qid = await get_bank_with_responses(
        db, student_id=student.id, attempt_id=attempt_id
    )
    attempt = await db.get(LanguagePlacementAttempt, attempt_id)
    await db.commit()
    return PlacementStartOut(
        attempt={
            "id": attempt_id,
            "language_id": language_id,
            "status": attempt.status.value if hasattr(attempt.status, "value") else str(attempt.status),
            "started_at": attempt.started_at,
            "submitted_at": attempt.submitted_at,
        },
        sections=[
            {
                "id": s.id,
                "skill": s.skill.value if hasattr(s.skill, "value") else str(s.skill),
                "title_ar": s.title_ar,
                "sort_order": s.sort_order,
            }
            for s in sections
        ],
        questions=[
            {
                "id": q.id,
                "section_id": q.section_id,
                "question_type": q.question_type,
                "prompt": q.prompt_json or {},
                "media_url": q.media_url,
                "max_points": q.max_points,
                "level_hint": q.level_hint,
                "sort_order": q.sort_order,
            }
            for q in questions
        ],
        responses_by_question_id=responses_by_qid,
    )


@router.put("/placement/responses", response_model=PlacementSaveResponseOut)
async def placement_save_response(
    body: PlacementSaveResponseIn,
    student: User = Depends(require_active_language_subscription()),
    db: AsyncSession = Depends(get_db),
):
    await save_response(
        db,
        student_id=student.id,
        attempt_id=body.attempt_id,
        question_id=body.question_id,
        response_json=body.response_json,
    )
    await db.commit()
    return PlacementSaveResponseOut(ok=True)


@router.post("/placement/speaking/upload", response_model=PlacementSpeakingUploadOut)
async def placement_upload_speaking(
    attempt_id: int = Form(...),
    question_id: int = Form(...),
    file: UploadFile = File(...),
    duration_seconds: int | None = Form(default=None),
    student: User = Depends(require_active_language_subscription()),
    db: AsyncSession = Depends(get_db),
):
    media, stored_duration = await upload_speaking_audio(
        db,
        student_id=student.id,
        attempt_id=attempt_id,
        question_id=question_id,
        file=file,
        duration_seconds=duration_seconds,
    )
    await db.commit()
    return PlacementSpeakingUploadOut(
        ok=True,
        media_object_id=media.id,
        public_url=media.public_url,
        duration_seconds=stored_duration,
    )


@router.post("/placement/submit", response_model=PlacementResultsOut)
async def placement_submit(
    body: PlacementSubmitIn,
    student: User = Depends(require_active_language_subscription()),
    db: AsyncSession = Depends(get_db),
):
    assessment, path_id = await submit_attempt(db, student_id=student.id, attempt_id=body.attempt_id)
    await db.commit()
    scores = await db.execute(select(LanguageAssessmentSkillScore).where(LanguageAssessmentSkillScore.assessment_id == assessment.id))
    rows = scores.scalars().all()
    return PlacementResultsOut(
        assessment_id=assessment.id,
        overall_level=assessment.overall_level.value if assessment.overall_level else None,
        overall_calculation_method=assessment.overall_calculation_method,
        completed_at=assessment.completed_at,
        skills=[
            {
                "skill": r.skill.value if hasattr(r.skill, "value") else str(r.skill),
                "score_percent": r.score_percent,
                "level": r.level.value if hasattr(r.level, "value") else str(r.level),
                "raw_metrics_json": r.raw_metrics_json,
                "ai_evaluation_json": r.ai_evaluation_json,
            }
            for r in rows
        ],
        path_id=path_id,
    )


@router.get("/hub", response_model=LanguageHubOut)
async def language_hub(
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    return await build_language_hub(db, student_id=student.id)


@router.get("/curriculum", response_model=CurriculumOverviewOut)
async def language_curriculum(
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    payload = await build_curriculum_overview(db, student_id=student.id)
    return CurriculumOverviewOut(**payload)


@router.get("/daily-plan", response_model=DailyPlanOut)
async def language_daily_plan(
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    payload = await build_daily_plan(db, student_id=student.id)
    return DailyPlanOut(**payload)


@router.get("/promotion-test", response_model=PromotionTestOut)
async def language_promotion_test(
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    payload = await build_promotion_test(db, student_id=student.id)
    return PromotionTestOut(**payload)


@router.post("/promotion-test/submit", response_model=PromotionResultOut)
async def language_promotion_test_submit(
    body: PromotionSubmitIn,
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    result = await grade_promotion_test(db, student_id=student.id, test_id=body.test_id, answers=body.answers)
    await db.commit()
    return PromotionResultOut(**result)


@router.get("/adaptive/state", response_model=AdaptiveStateOut)
async def language_adaptive_state(
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    language = await get_default_language(db)
    payload = await build_adaptive_state(db, student_id=student.id, language_id=language.id)
    return AdaptiveStateOut(**payload)


@router.post("/curriculum/objective/practiced", response_model=ObjectivePracticeOut)
async def language_curriculum_objective_practiced(
    body: ObjectivePracticeIn,
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    result = await record_objective_practice(db, student_id=student.id, objective_id=body.objective_id)
    await db.commit()
    return ObjectivePracticeOut(**result)


@router.get("/curriculum/objective/{objective_id}/lesson")
async def language_objective_lesson(
    objective_id: str,
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    return await get_micro_lesson(objective_id=objective_id)


@router.get("/reading", response_model=LessonListOut)
async def reading_list(
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    student_level, lesson_level, items, progress_map = await list_lessons(
        db, student_id=student.id, skill=LanguageSkill.reading
    )
    lessons = [
        LessonListItemOut(
            id=item.id,
            title=item.title,
            level=item.level.value if item.level else (lesson_level.value if lesson_level else ""),
            sort_order=item.sort_order,
            progress=_progress_out(progress_map.get(item.id)),
        )
        for item in items
    ]
    return LessonListOut(
        student_level=student_level.value,
        lesson_level=lesson_level.value if lesson_level else None,
        lessons=lessons,
    )


@router.get("/listening", response_model=LessonListOut)
async def listening_list(
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    student_level, lesson_level, items, progress_map = await list_lessons(
        db, student_id=student.id, skill=LanguageSkill.listening
    )
    out_lessons: list[LessonListItemOut] = []
    for item in items:
        _url, audio_available = await resolve_listening_audio(db, item)
        out_lessons.append(
            LessonListItemOut(
                id=item.id,
                title=item.title,
                level=item.level.value if item.level else (lesson_level.value if lesson_level else ""),
                sort_order=item.sort_order,
                progress=_progress_out(progress_map.get(item.id)),
                audio_available=audio_available,
            )
        )
    return LessonListOut(
        student_level=student_level.value,
        lesson_level=lesson_level.value if lesson_level else None,
        lessons=out_lessons,
    )


@router.get("/reading/{content_id}", response_model=ReadingLessonOut)
async def reading_detail(
    content_id: int,
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    item, progress = await get_reading_lesson(db, student_id=student.id, content_id=content_id)
    if not item:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="الدرس غير موجود")
    body = lesson_body_for_student(item)
    return ReadingLessonOut(
        id=item.id,
        title=item.title,
        level=item.level.value if item.level else "A1",
        passage=body.get("passage") or "",
        passage_ar=body.get("passage_ar"),
        questions=body.get("questions") or [],
        progress=_progress_out(progress),
    )


@router.post("/reading/{content_id}/submit", response_model=LessonSubmitOut)
async def reading_submit(
    content_id: int,
    body: LessonSubmitIn,
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    result = await submit_reading(db, student_id=student.id, content_id=content_id, answers=body.answers)
    await db.commit()
    return LessonSubmitOut(**result)


@router.get("/listening/{content_id}", response_model=ListeningLessonOut)
async def listening_detail(
    content_id: int,
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    item, progress, audio_url, audio_available = await get_listening_lesson(
        db, student_id=student.id, content_id=content_id
    )
    if not item:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="الدرس غير موجود")
    body = lesson_body_for_student(item)
    if not audio_url:
        try:
            tts = await get_lesson_audio(db, content_item_id=item.id)
            if tts and tts.get("public_url"):
                audio_url = tts["public_url"]
                audio_available = True
                await db.commit()
        except Exception:
            await db.rollback()
    return ListeningLessonOut(
        id=item.id,
        title=item.title,
        level=item.level.value if item.level else "A1",
        instructions=body.get("instructions"),
        questions=body.get("questions") or [],
        audio_url=audio_url,
        audio_available=audio_available,
        progress=_progress_out(progress),
    )


@router.post("/listening/{content_id}/submit", response_model=LessonSubmitOut)
async def listening_submit(
    content_id: int,
    body: LessonSubmitIn,
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    result = await submit_listening(db, student_id=student.id, content_id=content_id, answers=body.answers)
    await db.commit()
    return LessonSubmitOut(**result)


@router.get("/progress", response_model=LanguageProgressOut)
async def language_progress(
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    return await build_language_progress(db, student_id=student.id)


@router.get("/analytics/dashboard", response_model=LanguageAnalyticsDashboardOut)
async def language_analytics_dashboard(
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    return await build_language_analytics_dashboard(db, student_id=student.id)


@router.get("/achievements", response_model=LanguageAchievementsOut)
async def language_achievements(
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    language = await get_default_language(db)
    return await list_student_achievements(db, student_id=student.id, language_id=language.id)


@router.get("/vocabulary", response_model=VocabularyListOut)
async def vocabulary_list(
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    return await list_vocabulary(db, student_id=student.id)


class VocabSRReviewIn(BaseModel):
    vocabulary_id: int
    quality: int


@router.get("/vocabulary/review")
async def vocabulary_review_queue(
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    language = await get_default_language(db)
    items = await get_review_queue(db, student_id=student.id, language_id=language.id)
    due = await count_due(db, student_id=student.id, language_id=language.id)
    return {"due_count": due, "items": items}


@router.post("/vocabulary/review")
async def vocabulary_sr_review_submit(
    body: VocabSRReviewIn,
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    result = await submit_review(db, student_id=student.id, vocabulary_id=body.vocabulary_id, quality=body.quality)
    await db.commit()
    return result


@router.get("/vocabulary/stats")
async def vocabulary_stats(
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    language = await get_default_language(db)
    return await get_vocabulary_stats(db, student_id=student.id, language_id=language.id)


@router.get("/vocabulary/{content_id}", response_model=VocabularyCardOut)
async def vocabulary_detail(
    content_id: int,
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    return await get_vocabulary_card(db, student_id=student.id, content_id=content_id)


@router.post("/vocabulary/{content_id}/review", response_model=VocabularyCardOut)
async def vocabulary_review(
    content_id: int,
    body: VocabularyReviewIn,
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    result = await review_vocabulary(db, student_id=student.id, content_id=content_id, action=body.action)
    await db.commit()
    return result


@router.get("/writing", response_model=WritingListOut)
async def writing_list(
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    return await list_writing(db, student_id=student.id)


@router.get("/writing/{prompt_id}", response_model=WritingPromptOut)
async def writing_detail(
    prompt_id: int,
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    return await get_writing_prompt(db, student_id=student.id, prompt_id=prompt_id)


@router.post("/writing/{prompt_id}/submit", response_model=WritingSubmitOut)
async def writing_submit(
    prompt_id: int,
    body: WritingSubmitIn,
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    result = await submit_writing(
        db, student_id=student.id, prompt_id=prompt_id, response_text=body.response_text
    )
    await db.commit()
    return WritingSubmitOut(**result)


@router.get("/speaking", response_model=SpeakingListOut)
async def speaking_list(
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    return await list_speaking(db, student_id=student.id)


@router.get("/speaking/conversation", response_model=SpeakingConversationStateOut)
async def speaking_conversation_state(
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    payload = await get_conversation_state(db, student_id=student.id)
    await db.commit()
    return SpeakingConversationStateOut(**payload)


@router.get("/speaking/conversation/progress", response_model=SpeakingConversationProgressOut)
async def speaking_conversation_progress(
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    payload = await get_conversation_progress(db, student_id=student.id)
    await db.commit()
    return SpeakingConversationProgressOut(**payload)


@router.post("/speaking/conversation/turn", response_model=SpeakingConversationTurnOut)
async def speaking_conversation_turn(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    duration_seconds: int | None = Form(default=None),
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    result = await process_conversation_turn(
        db,
        student_id=student.id,
        file=file,
        duration_seconds=duration_seconds,
    )
    bg = result.pop("_background_tts", None)
    result.pop("turn_id", None)
    await db.commit()
    if bg:
        from app.services.language_conversation_tts_task import generate_conversation_reply_audio

        background_tasks.add_task(generate_conversation_reply_audio, **bg)
    return SpeakingConversationTurnOut(**result)


@router.delete("/speaking/conversation", response_model=SpeakingConversationResetOut)
async def speaking_conversation_reset(
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    result = await reset_conversation(db, student_id=student.id)
    await db.commit()
    return SpeakingConversationResetOut(**result)


@router.get("/speaking/scenarios", response_model=ScenarioListOut)
async def speaking_scenarios(
    category: str | None = None,
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    language = await get_default_language(db)
    scenarios = await list_scenarios(
        db, student_id=student.id, language_id=language.id, category=category
    )
    return ScenarioListOut(scenarios=scenarios, categories=list(SCENARIO_CATEGORIES))


@router.get("/speaking/scenarios/{scenario_id}", response_model=ScenarioDetailOut)
async def speaking_scenario_detail(
    scenario_id: int,
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    language = await get_default_language(db)
    return await get_scenario_detail(
        db, student_id=student.id, language_id=language.id, scenario_id=scenario_id
    )


@router.post("/speaking/scenarios/{scenario_id}/start", response_model=ScenarioStartOut)
async def speaking_scenario_start(
    scenario_id: int,
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    language = await get_default_language(db)
    result = await start_scenario_session(
        db, student_id=student.id, language_id=language.id, scenario_id=scenario_id
    )
    await db.commit()
    return result


@router.get("/speaking/scenarios/session/{session_id}", response_model=ScenarioSessionOut)
async def speaking_scenario_session(
    session_id: int,
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    return await get_scenario_session(db, session_id=session_id, student_id=student.id)


@router.post("/speaking/scenarios/turn", response_model=ScenarioTurnOut)
async def speaking_scenario_turn(
    body: ScenarioTurnIn,
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    language = await get_default_language(db)
    result = await process_scenario_turn(
        db, session_id=body.session_id, student_id=student.id, user_text=body.text, language_id=language.id
    )
    await db.commit()
    return result


@router.post("/speaking/scenarios/turn/voice", response_model=ScenarioTurnOut)
async def speaking_scenario_voice_turn(
    session_id: int = Form(...),
    duration_seconds: int | None = Form(default=None),
    file: UploadFile = File(...),
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    language = await get_default_language(db)
    result = await process_scenario_voice_turn(
        db,
        session_id=session_id,
        student_id=student.id,
        language_id=language.id,
        file=file,
        duration_seconds=duration_seconds,
    )
    await db.commit()
    return result


@router.post("/speaking/scenarios/end", response_model=ScenarioEndOut)
async def speaking_scenario_end(
    body: ScenarioEndIn,
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    result = await end_session_with_feedback(db, session_id=body.session_id, student_id=student.id)
    await db.commit()
    return result


@router.get("/speaking/shadow/sentences", response_model=ShadowSentenceListOut)
async def shadow_sentences(
    focus: str | None = None,
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    payload = await list_shadow_sentences(db, student_id=student.id, focus=focus)
    return ShadowSentenceListOut(**payload)


@router.post("/speaking/shadow", response_model=ShadowSubmitOut)
async def shadow_submit(
    target_text: str = Form(...),
    file: UploadFile = File(...),
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    result = await submit_shadow(db, student_id=student.id, target_text=target_text, file=file)
    await db.commit()
    return ShadowSubmitOut(**result)


@router.get("/speaking/{prompt_id}", response_model=SpeakingPromptOut)
async def speaking_detail(
    prompt_id: int,
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    return await get_speaking_prompt(db, student_id=student.id, prompt_id=prompt_id)


@router.post("/speaking/{prompt_id}/upload", response_model=PlacementSpeakingUploadOut)
async def speaking_upload(
    prompt_id: int,
    file: UploadFile = File(...),
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    media = await upload_speaking_recording(
        db, student_id=student.id, prompt_id=prompt_id, file=file
    )
    await db.commit()
    return PlacementSpeakingUploadOut(ok=True, media_object_id=media["media_object_id"], public_url=media["public_url"])


@router.post("/speaking/{prompt_id}/submit", response_model=SpeakingSubmitOut)
async def speaking_submit(
    prompt_id: int,
    body: SpeakingSubmitIn,
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    result = await submit_speaking(
        db,
        student_id=student.id,
        prompt_id=prompt_id,
        media_object_id=body.media_object_id,
        duration_seconds=body.duration_seconds,
    )
    await db.commit()
    return SpeakingSubmitOut(**result)


@router.get("/certificates", response_model=LanguageCertificateListOut)
async def certificates_list(
    student: User = Depends(require_language_learning_ready()),
    db: AsyncSession = Depends(get_db),
):
    payload = await list_student_certificates(db, student_id=student.id)
    await db.commit()
    return LanguageCertificateListOut(**payload)
