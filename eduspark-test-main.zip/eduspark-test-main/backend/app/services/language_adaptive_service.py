"""Adaptive progression — mastery windows, recommendations, and state API."""

from __future__ import annotations

from typing import Literal

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.models.language.adaptive import LanguageSkillLevelState
from app.models.language.analytics import LanguageAnalytics
from app.models.language.enums import LanguageLevel, LanguageSkill
from app.services.language_curriculum_service import build_curriculum_overview
from app.services.language_level_utils import bottleneck_level
from app.services.language_subscription_service import get_default_language

settings = get_settings()

Recommendation = Literal["PROMOTE", "MAINTAIN", "REMEDIAL"]
CORE_SKILLS = (
    LanguageSkill.reading,
    LanguageSkill.listening,
    LanguageSkill.writing,
    LanguageSkill.speaking,
)

SKILL_LABELS_AR = {
    "reading": "القراءة",
    "listening": "الاستماع",
    "writing": "الكتابة",
    "speaking": "التحدث",
}

FEATURE_TO_SKILL = {
    "reading": "reading",
    "listening": "listening",
    "writing": "writing",
    "speaking": "speaking",
    "conversation": "speaking",
    "vocabulary": "reading",
}


def _as_skill(skill: LanguageSkill | str) -> LanguageSkill:
    return skill if isinstance(skill, LanguageSkill) else LanguageSkill(skill)


def _as_level(level: LanguageLevel | str | None) -> LanguageLevel:
    if level is None:
        return LanguageLevel.A1
    return level if isinstance(level, LanguageLevel) else LanguageLevel(level)


def _mastery_settings() -> tuple[int, float, float]:
    window = max(1, int(settings.LANGUAGE_MASTERY_WINDOW_SIZE))
    up = float(settings.LANGUAGE_MASTERY_UP_THRESHOLD)
    down = float(settings.LANGUAGE_MASTERY_DOWN_THRESHOLD)
    return window, up, down


def min_samples_for_promote(window_size: int) -> int:
    return max(3, window_size // 2)


def _normalize_scores(raw: list | None) -> list[float]:
    if not raw:
        return []
    out: list[float] = []
    for item in raw:
        try:
            out.append(float(item))
        except (TypeError, ValueError):
            continue
    return out


def _append_score(scores: list[float], score_percent: float, window_size: int) -> list[float]:
    updated = scores + [float(score_percent)]
    if len(updated) > window_size:
        updated = updated[-window_size:]
    return updated


def rolling_average(scores: list[float]) -> float | None:
    if not scores:
        return None
    return round(sum(scores) / len(scores), 2)


def compute_skill_recommendation(
    recent_scores: list[float],
    avg: float | None,
    *,
    window_size: int,
    up_threshold: float,
    down_threshold: float,
) -> Recommendation:
    if avg is not None and avg <= down_threshold:
        return "REMEDIAL"
    min_samples = min_samples_for_promote(window_size)
    if avg is not None and len(recent_scores) >= min_samples and avg >= up_threshold:
        return "PROMOTE"
    return "MAINTAIN"


def compute_overall_recommendation(
    skill_snapshots: dict[str, dict],
    *,
    window_size: int,
    up_threshold: float,
    down_threshold: float,
) -> Recommendation:
    recs = {sk: snap["recommendation"] for sk, snap in skill_snapshots.items()}
    if any(r == "REMEDIAL" for r in recs.values()):
        return "REMEDIAL"

    avgs = [snap["rolling_average"] for snap in skill_snapshots.values() if snap.get("rolling_average") is not None]
    if avgs:
        overall = round(sum(avgs) / len(avgs), 2)
        if overall <= down_threshold:
            return "REMEDIAL"
        min_samples = min_samples_for_promote(window_size)
        enough_data = sum(1 for snap in skill_snapshots.values() if snap.get("samples_in_window", 0) >= min_samples)
        if overall >= up_threshold and enough_data >= 2:
            return "PROMOTE"
        if overall >= up_threshold and enough_data >= 1 and all(r != "REMEDIAL" for r in recs.values()):
            promote_count = sum(1 for r in recs.values() if r == "PROMOTE")
            if promote_count >= 2:
                return "PROMOTE"

    if sum(1 for r in recs.values() if r == "PROMOTE") >= 2:
        return "PROMOTE"
    return "MAINTAIN"


def derive_strengths_weaknesses(
    skill_snapshots: dict[str, dict],
    *,
    up_threshold: float,
    down_threshold: float,
    primary_focus_skill: str | None = None,
    objective_weak_features: list[str] | None = None,
) -> tuple[list[str], list[str]]:
    strengths: list[str] = []
    weaknesses: list[str] = []

    for skill, snap in skill_snapshots.items():
        avg = snap.get("rolling_average")
        rec = snap.get("recommendation")
        if rec == "PROMOTE" or (avg is not None and avg >= up_threshold):
            strengths.append(skill)
        if rec == "REMEDIAL" or (avg is not None and avg <= down_threshold):
            weaknesses.append(skill)

    if primary_focus_skill and primary_focus_skill in SKILL_LABELS_AR and primary_focus_skill not in strengths:
        if primary_focus_skill not in weaknesses:
            weaknesses.append(primary_focus_skill)

    for feature in objective_weak_features or []:
        sk = FEATURE_TO_SKILL.get(feature, feature)
        if sk in SKILL_LABELS_AR and sk not in strengths and sk not in weaknesses:
            weaknesses.append(sk)

    return strengths, weaknesses


def _objective_weak_features(objectives: list[dict]) -> list[str]:
    weak: list[str] = []
    for o in objectives:
        if o.get("status") in ("new", "in_progress"):
            feat = (o.get("feature") or "").strip().lower()
            if feat and feat not in weak:
                weak.append(feat)
    return weak[:3]


def _current_level_from_analytics(analytics: LanguageAnalytics | None) -> str:
    if not analytics:
        return LanguageLevel.A1.value
    level = analytics.overall_level_internal or bottleneck_level(
        {
            "reading": analytics.reading_level.value if analytics.reading_level else None,
            "listening": analytics.listening_level.value if analytics.listening_level else None,
            "writing": analytics.writing_level.value if analytics.writing_level else None,
            "speaking": analytics.speaking_level.value if analytics.speaking_level else None,
        }
    )
    return level.value if level else LanguageLevel.A1.value


async def get_or_create_skill_state(
    db: AsyncSession,
    *,
    student_id: int,
    language_id: int,
    skill: LanguageSkill | str,
    initial_level: LanguageLevel | str | None,
) -> LanguageSkillLevelState:
    skill = _as_skill(skill)
    result = await db.execute(
        select(LanguageSkillLevelState).where(
            LanguageSkillLevelState.student_id == student_id,
            LanguageSkillLevelState.language_id == language_id,
            LanguageSkillLevelState.skill == skill,
        )
    )
    state = result.scalar_one_or_none()
    if state is None:
        state = LanguageSkillLevelState(
            student_id=student_id,
            language_id=language_id,
            skill=skill,
            current_level=_as_level(initial_level),
            recent_scores_json=[],
        )
        db.add(state)
        await db.flush()
    return state


async def record_lesson_result(
    db: AsyncSession,
    *,
    student_id: int,
    language_id: int,
    skill: LanguageSkill | str,
    score_percent: float,
) -> dict:
    """Append a lesson score to the mastery window and update streak counters."""
    skill = _as_skill(skill)
    window_size, up_threshold, down_threshold = _mastery_settings()

    analytics = await db.get(LanguageAnalytics, {"student_id": student_id, "language_id": language_id})
    initial_level = getattr(analytics, f"{skill.value}_level", None) if analytics else None
    state = await get_or_create_skill_state(
        db, student_id=student_id, language_id=language_id, skill=skill, initial_level=initial_level
    )

    previous_scores = _normalize_scores(state.recent_scores_json)
    recent_scores = _append_score(previous_scores, score_percent, window_size)
    state.recent_scores_json = recent_scores

    if score_percent >= up_threshold:
        state.consecutive_pass_count = int(state.consecutive_pass_count or 0) + 1
        state.consecutive_fail_count = 0
    elif score_percent < down_threshold:
        state.consecutive_fail_count = int(state.consecutive_fail_count or 0) + 1
        state.consecutive_pass_count = 0
    else:
        state.consecutive_pass_count = 0
        state.consecutive_fail_count = 0

    avg = rolling_average(recent_scores)
    recommendation = compute_skill_recommendation(
        recent_scores, avg, window_size=window_size, up_threshold=up_threshold, down_threshold=down_threshold
    )
    await db.flush()
    return {
        "skill": skill.value,
        "current_level": state.current_level.value,
        "changed": False,
        "direction": None,
        "score_percent": float(score_percent),
        "recent_scores": recent_scores,
        "rolling_average": avg,
        "recommendation": recommendation,
        "window_size": window_size,
        "consecutive_pass_count": int(state.consecutive_pass_count or 0),
        "consecutive_fail_count": int(state.consecutive_fail_count or 0),
    }


def _build_skill_snapshot(
    state: LanguageSkillLevelState,
    *,
    window_size: int,
    up_threshold: float,
    down_threshold: float,
) -> dict:
    recent_scores = _normalize_scores(state.recent_scores_json)
    avg = rolling_average(recent_scores)
    recommendation = compute_skill_recommendation(
        recent_scores, avg, window_size=window_size, up_threshold=up_threshold, down_threshold=down_threshold
    )
    return {
        "current_level": state.current_level.value,
        "recent_scores": recent_scores,
        "rolling_average": avg,
        "recommendation": recommendation,
        "window_size": window_size,
        "samples_in_window": len(recent_scores),
        "consecutive_pass": int(state.consecutive_pass_count or 0),
        "consecutive_fail": int(state.consecutive_fail_count or 0),
        "up_threshold": up_threshold,
        "down_threshold": down_threshold,
    }


async def build_adaptive_state(db: AsyncSession, *, student_id: int, language_id: int | None = None) -> dict:
    """Full adaptive snapshot for GET /adaptive/state."""
    language = await get_default_language(db) if language_id is None else None
    lang_id = language_id or language.id

    window_size, up_threshold, down_threshold = _mastery_settings()
    analytics = await db.get(LanguageAnalytics, {"student_id": student_id, "language_id": lang_id})
    overview = await build_curriculum_overview(db, student_id=student_id)
    objectives = overview.get("objectives") or []

    skill_snapshots: dict[str, dict] = {}
    for skill in CORE_SKILLS:
        initial_level = getattr(analytics, f"{skill.value}_level", None) if analytics else None
        state = await get_or_create_skill_state(
            db, student_id=student_id, language_id=lang_id, skill=skill, initial_level=initial_level
        )
        skill_snapshots[skill.value] = _build_skill_snapshot(
            state, window_size=window_size, up_threshold=up_threshold, down_threshold=down_threshold
        )

    recommendation = compute_overall_recommendation(
        skill_snapshots,
        window_size=window_size,
        up_threshold=up_threshold,
        down_threshold=down_threshold,
    )
    primary = analytics.primary_focus_skill if analytics else None
    obj_weak = _objective_weak_features(objectives)
    strengths, weaknesses = derive_strengths_weaknesses(
        skill_snapshots,
        up_threshold=up_threshold,
        down_threshold=down_threshold,
        primary_focus_skill=primary,
        objective_weak_features=obj_weak,
    )

    avgs = [s["rolling_average"] for s in skill_snapshots.values() if s.get("rolling_average") is not None]
    overall_avg = round(sum(avgs) / len(avgs), 2) if avgs else None

    in_progress = sum(1 for o in objectives if o.get("status") == "in_progress")
    mastered = sum(1 for o in objectives if o.get("status") == "mastered")

    return {
        "current_level": overview.get("current_level") or _current_level_from_analytics(analytics),
        "rolling_average": overall_avg,
        "recommendation": recommendation,
        "strengths": strengths,
        "weaknesses": weaknesses,
        "objectives_in_progress": in_progress,
        "objectives_mastered": mastered,
        "objectives_total": len(objectives),
        "skills": skill_snapshots,
    }


async def get_adaptive_state_overview(db: AsyncSession, *, student_id: int, language_id: int) -> dict:
    """Backward-compatible alias."""
    return await build_adaptive_state(db, student_id=student_id, language_id=language_id)


def sort_objectives_for_adaptive(
    objectives: list[dict],
    *,
    recommendation: Recommendation,
    strengths: list[str],
    weaknesses: list[str],
) -> list[dict]:
    """Order curriculum objectives for daily plan items."""

    def _skill(o: dict) -> str:
        return FEATURE_TO_SKILL.get((o.get("feature") or "").strip().lower(), "reading")

    def _idx(o: dict) -> int:
        oid = o.get("id") or ""
        try:
            return int(str(oid).rsplit("-", 1)[-1])
        except ValueError:
            return 0

    unmastered = [o for o in objectives if o.get("status") != "mastered"]

    if recommendation == "PROMOTE":
        return sorted(
            unmastered,
            key=lambda o: (
                0 if _skill(o) in strengths else 1,
                0 if o.get("status") == "in_progress" else 1,
                -_idx(o),
            ),
        )

    if recommendation == "REMEDIAL":
        return sorted(
            unmastered,
            key=lambda o: (
                0 if _skill(o) in weaknesses else 1,
                0 if o.get("status") == "in_progress" else 1,
                _idx(o),
            ),
        )

    return sorted(
        unmastered,
        key=lambda o: (0 if o.get("status") == "in_progress" else 1, _idx(o)),
    )
