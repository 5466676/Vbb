"""English speech-to-text for language conversation — accuracy-first faster-whisper."""

from __future__ import annotations

import asyncio
import logging
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path

from app.core.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

_conversation_whisper_model = None
_whisper_patched = False

DEFAULT_INITIAL_PROMPT = (
    "English speaking practice. The student introduces themselves. "
    "My name is Hamza. My name are Hamza Al-Kuzbari."
)


@dataclass
class ConversationTranscription:
    text: str
    engine: str
    model: str
    duration_s: float = 0.0
    avg_logprob: float | None = None
    no_speech_prob: float | None = None
    language_probability: float | None = None
    low_confidence: bool = False
    raw_text: str = ""
    meta: dict = field(default_factory=dict)


def _resolve_ffmpeg() -> str | None:
    ffmpeg = shutil.which("ffmpeg")
    if ffmpeg:
        return ffmpeg
    try:
        import imageio_ffmpeg

        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return None


def _normalize_to_wav_16k(source: Path) -> Path:
    """Decode browser webm/opus to mono 16 kHz wav — required for reliable Whisper accuracy."""
    ffmpeg = _resolve_ffmpeg()
    if not ffmpeg:
        raise RuntimeError("ffmpeg not available for audio normalization")

    out = Path(tempfile.mkstemp(suffix=".wav")[1])
    cmd = [
        ffmpeg,
        "-y",
        "-i",
        str(source),
        "-ar",
        "16000",
        "-ac",
        "1",
        "-c:a",
        "pcm_s16le",
        str(out),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0 or not out.exists() or out.stat().st_size == 0:
        out.unlink(missing_ok=True)
        raise RuntimeError(f"ffmpeg normalize failed: {(result.stderr or result.stdout)[-500:]}")
    return out


def _patch_whisper_ffmpeg() -> bool:
    global _whisper_patched
    if _whisper_patched:
        return True
    ffmpeg = _resolve_ffmpeg()
    if not ffmpeg:
        return False
    try:
        import whisper.audio as whisper_audio

        original = whisper_audio.run

        def run_with_ffmpeg(cmd, *args, **kwargs):
            if isinstance(cmd, (list, tuple)) and cmd and cmd[0] == "ffmpeg":
                cmd = [ffmpeg, *cmd[1:]]
            return original(cmd, *args, **kwargs)

        whisper_audio.run = run_with_ffmpeg
        _whisper_patched = True
        return True
    except Exception:
        return False


def _get_conversation_whisper_model():
    global _conversation_whisper_model
    if _conversation_whisper_model is not None:
        return _conversation_whisper_model

    from faster_whisper import WhisperModel

    model_id = (settings.LANGUAGE_CONVERSATION_WHISPER_MODEL or "small.en").strip()
    compute = (settings.LANGUAGE_CONVERSATION_WHISPER_COMPUTE_TYPE or "float32").strip()
    logger.info(
        "Loading conversation faster-whisper model=%s compute_type=%s device=cpu",
        model_id,
        compute,
    )
    _conversation_whisper_model = WhisperModel(model_id, device="cpu", compute_type=compute)
    return _conversation_whisper_model


def _initial_prompt() -> str:
    raw = (settings.LANGUAGE_CONVERSATION_WHISPER_INITIAL_PROMPT or "").strip()
    return raw or DEFAULT_INITIAL_PROMPT


def _segment_confidence(segments: list) -> tuple[float | None, float | None]:
    if not segments:
        return None, None
    logprobs = [s.avg_logprob for s in segments if getattr(s, "avg_logprob", None) is not None]
    no_speech = [s.no_speech_prob for s in segments if getattr(s, "no_speech_prob", None) is not None]
    avg_logprob = sum(logprobs) / len(logprobs) if logprobs else None
    max_no_speech = max(no_speech) if no_speech else None
    return avg_logprob, max_no_speech


def _is_low_confidence(avg_logprob: float | None, no_speech_prob: float | None) -> bool:
    if no_speech_prob is not None and no_speech_prob >= 0.55:
        return True
    if avg_logprob is not None and avg_logprob <= -0.85:
        return True
    return False


def _transcribe_faster_whisper(wav_path: Path) -> ConversationTranscription:
    model = _get_conversation_whisper_model()
    model_id = (settings.LANGUAGE_CONVERSATION_WHISPER_MODEL or "small.en").strip()
    beam = max(1, int(settings.LANGUAGE_CONVERSATION_WHISPER_BEAM_SIZE or 5))
    vad = bool(settings.LANGUAGE_CONVERSATION_WHISPER_VAD)

    segments, info = model.transcribe(
        str(wav_path),
        language="en",
        beam_size=beam,
        best_of=beam,
        vad_filter=vad,
        initial_prompt=_initial_prompt(),
        condition_on_previous_text=False,
    )
    seg_list = list(segments)
    text = "".join(s.text for s in seg_list).strip()
    avg_logprob, no_speech_prob = _segment_confidence(seg_list)

    return ConversationTranscription(
        text=text,
        raw_text=text,
        engine="faster-whisper",
        model=model_id,
        duration_s=float(info.duration or 0.0),
        avg_logprob=avg_logprob,
        no_speech_prob=no_speech_prob,
        language_probability=float(info.language_probability or 0.0),
        low_confidence=_is_low_confidence(avg_logprob, no_speech_prob),
        meta={
            "beam_size": beam,
            "vad_filter": vad,
            "compute_type": settings.LANGUAGE_CONVERSATION_WHISPER_COMPUTE_TYPE,
            "segment_count": len(seg_list),
        },
    )


def _transcribe_openai_whisper_fallback(wav_path: Path) -> ConversationTranscription:
    _patch_whisper_ffmpeg()
    import whisper

    model_name = settings.WHISPER_MODEL or "turbo"
    logger.warning("Using openai-whisper fallback model=%s", model_name)
    model = whisper.load_model(model_name)
    result = model.transcribe(
        str(wav_path),
        language="en",
        task="transcribe",
        initial_prompt=_initial_prompt(),
        condition_on_previous_text=False,
    )
    text = (result.get("text") or "").strip()
    segments = result.get("segments") or []
    logprobs = [s.get("avg_logprob") for s in segments if s.get("avg_logprob") is not None]
    no_speech = [s.get("no_speech_prob") for s in segments if s.get("no_speech_prob") is not None]
    avg_logprob = sum(logprobs) / len(logprobs) if logprobs else None
    no_speech_prob = max(no_speech) if no_speech else None

    return ConversationTranscription(
        text=text,
        raw_text=text,
        engine="openai-whisper",
        model=model_name,
        avg_logprob=avg_logprob,
        no_speech_prob=no_speech_prob,
        low_confidence=_is_low_confidence(avg_logprob, no_speech_prob),
        meta={"segment_count": len(segments)},
    )


def _transcribe_sync(source_path: Path) -> tuple[ConversationTranscription, float]:
    started = time.perf_counter()
    wav_path: Path | None = None
    try:
        wav_path = _normalize_to_wav_16k(source_path)
        try:
            result = _transcribe_faster_whisper(wav_path)
        except ImportError:
            result = _transcribe_openai_whisper_fallback(wav_path)
        except Exception as exc:
            logger.warning("faster-whisper failed (%s) — trying openai-whisper fallback", exc)
            result = _transcribe_openai_whisper_fallback(wav_path)
        result.meta["normalized_wav"] = True
        elapsed = time.perf_counter() - started
        return result, elapsed
    finally:
        if wav_path and wav_path.exists():
            try:
                wav_path.unlink()
            except OSError:
                pass


async def transcribe_english_audio(data: bytes, *, suffix: str = ".webm") -> ConversationTranscription:
    """Transcribe uploaded audio to English text with confidence metadata."""
    if not data:
        return ConversationTranscription(text="", raw_text="", engine="none", model="")
    if not settings.ENABLE_WHISPER:
        logger.info("Whisper disabled — skipping transcription")
        return ConversationTranscription(text="", raw_text="", engine="disabled", model="")

    tmp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            tmp.write(data)
            tmp_path = Path(tmp.name)
        result, elapsed = await asyncio.to_thread(_transcribe_sync, tmp_path)
        logger.info(
            "Conversation transcription engine=%s model=%s duration_s=%.2f text=%r "
            "avg_logprob=%s no_speech_prob=%s low_confidence=%s",
            result.engine,
            result.model,
            elapsed,
            result.text,
            result.avg_logprob,
            result.no_speech_prob,
            result.low_confidence,
        )
        return result
    except Exception as exc:
        logger.warning("English transcription failed: %s", exc)
        return ConversationTranscription(text="", raw_text="", engine="error", model="", meta={"error": str(exc)})
    finally:
        if tmp_path and tmp_path.exists():
            try:
                tmp_path.unlink()
            except OSError:
                pass
