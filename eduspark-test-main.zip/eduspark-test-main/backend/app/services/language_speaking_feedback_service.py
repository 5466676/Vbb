"""Speaking prompts — AI feedback (STT → grammar → tutor reply → TTS → score).

Each external step degrades gracefully so submit always returns a response.
Scoring: Gemini CEFR rubric when available; otherwise duration + grammar heuristic.
"""

from __future__ import annotations

import asyncio
import logging
import re
from pathlib import Path

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.models.language.enums import LanguageLevel
from app.models.media import MediaObject
from app.services.ai_service import generate_ollama_text
from app.services.language_grammar_service import analyze_grammar
from app.services.language_placement_ai_scoring import score_speaking_ai
from app.services.language_placement_scoring_service import percent_to_level, score_speaking
from app.services.language_reply_tts_service import synthesize_english_reply
from app.services.language_transcription_service import transcribe_english_audio

logger = logging.getLogger(__name__)
settings = get_settings()

TUTOR_SYSTEM_PROMPT = (
    "You are an English conversation tutor helping an Arabic-speaking learner practice English.\n"
    "Rules:\n"
    "- If the sentence is correct -> respond naturally (do NOT repeat it back).\n"
    "- If it is wrong -> correct it briefly, then continue the conversation.\n"
    "- Keep replies short and natural.\n"
    "- Match the learner's CEFR level.\n"
    "- Stay on the topic of the speaking prompt.\n"
    "- Reply in plain English only. Do not use JSON, markdown, or labels."
)


def _read_media_bytes(media: MediaObject) -> tuple[bytes, str]:
    try:
        path = Path(settings.UPLOAD_DIR) / media.storage_key
        suffix = Path(media.storage_key).suffix or ".webm"
        return path.read_bytes(), suffix
    except Exception as exc:
        logger.warning("Speaking feedback: could not read media %s: %s", getattr(media, "id", None), exc)
        return b"", ".webm"


def _build_tutor_user_prompt(*, prompt_text: str, level: str, transcript: str, corrected_text: str) -> str:
    lines = [f"Learner CEFR level: {level}."]
    if prompt_text:
        lines.append(f"Speaking prompt: {prompt_text}")
    lines.append(f"Learner said: {transcript}")
    if corrected_text and corrected_text.strip() and corrected_text.strip() != transcript.strip():
        lines.append(f"Grammar-corrected version: {corrected_text}")
    lines.append("Respond as the tutor.")
    return "\n".join(lines)


async def _generate_tutor_reply(*, prompt_text: str, level: str, transcript: str, corrected_text: str) -> str:
    if not transcript.strip():
        return ""

    user_prompt = _build_tutor_user_prompt(
        prompt_text=prompt_text,
        level=level,
        transcript=transcript,
        corrected_text=corrected_text,
    )

    if settings.LLM_PROVIDER.lower() == "ollama":
        try:
            reply = await generate_ollama_text(
                user_prompt,
                system=TUTOR_SYSTEM_PROMPT,
                temperature=0.3,
                max_tokens=256,
            )
            return (reply or "").strip()
        except Exception as exc:
            logger.warning("Speaking feedback: Ollama tutor reply failed: %s", exc)
            return ""

    if settings.GEMINI_API_KEY:
        try:
            import google.generativeai as genai

            genai.configure(api_key=settings.GEMINI_API_KEY)
            model = genai.GenerativeModel(
                settings.GEMINI_MODEL,
                system_instruction=TUTOR_SYSTEM_PROMPT,
                generation_config={"max_output_tokens": 256 + 3072, "temperature": 0.3},
            )
            response = await asyncio.to_thread(
                model.generate_content, user_prompt, request_options={"timeout": 60}
            )
            return (response.text or "").strip()
        except Exception as exc:
            logger.warning("Speaking feedback: Gemini tutor reply failed: %s", exc)
            return ""

    logger.info("Speaking feedback: no LLM provider configured — skipping tutor reply")
    return ""


def _word_count(text: str) -> int:
    return len(re.findall(r"[A-Za-z']+", text or ""))


def _rule_hybrid_score(
    *,
    media: MediaObject,
    duration_seconds: int | None,
    min_seconds: int,
    transcript: str,
    errors: list,
    stt_engine: str,
) -> tuple[float, dict, str]:
    duration_pct, dur_metrics = score_speaking(
        {"media_object_id": media.id, "duration_seconds": duration_seconds},
        min_seconds=min_seconds,
    )
    word_count = _word_count(transcript)
    if transcript:
        accuracy = max(0.0, 100.0 - (len(errors) / max(1, word_count)) * 150.0)
        score_percent = round(0.4 * float(duration_pct) + 0.6 * accuracy, 2)
    elif stt_engine == "disabled":
        accuracy = 0.0
        score_percent = round(float(duration_pct), 2)
    else:
        accuracy = 0.0
        score_percent = 0.0

    metrics = {
        **dur_metrics,
        "word_count": word_count,
        "grammar_errors": len(errors),
        "accuracy_pct": round(accuracy, 2),
        "duration_pct": round(float(duration_pct), 2),
        "scorer": "rule_hybrid_v1",
    }
    return score_percent, metrics, "rule_hybrid_v1"


async def analyze_speaking_recording(
    db: AsyncSession,
    *,
    student_id: int,
    media: MediaObject,
    prompt_text: str,
    level: LanguageLevel | None,
    duration_seconds: int | None,
    min_seconds: int,
) -> dict:
    """Full AI feedback pipeline for one speaking-prompt recording."""
    level_str = level.value if level else LanguageLevel.A1.value

    data, suffix = _read_media_bytes(media)
    stt = await transcribe_english_audio(data, suffix=suffix)
    transcript = (stt.text or "").strip()

    grammar = analyze_grammar(transcript)
    grammar_available = bool(grammar.get("available"))
    corrected_text = grammar.get("corrected_text") or transcript
    errors = grammar.get("errors") or []

    reply = await _generate_tutor_reply(
        prompt_text=prompt_text,
        level=level_str,
        transcript=transcript,
        corrected_text=corrected_text,
    )

    reply_media: MediaObject | None = None
    if reply:
        try:
            reply_media = await synthesize_english_reply(db, student_id=student_id, text=reply)
        except Exception as exc:
            logger.warning("Speaking feedback: reply TTS failed: %s", exc)
            reply_media = None

    scoring_version = "rule_hybrid_v1"
    ai_rubric = None
    if data:
        ai_rubric = await score_speaking_ai(audio_data=data, suffix=suffix, prompt=prompt_text)

    if ai_rubric:
        score_percent, ai_metrics = ai_rubric
        scoring_version = "ai_rubric_v2"
        metrics = {
            **ai_metrics,
            "grammar_errors": len(errors),
            "grammar_available": grammar_available,
            "stt_engine": stt.engine,
            "stt_low_confidence": bool(stt.low_confidence),
            "has_reply_audio": reply_media is not None,
            "duration_seconds": duration_seconds,
            "min_seconds": min_seconds,
        }
        if not transcript and ai_metrics.get("transcript"):
            transcript = str(ai_metrics["transcript"])
    else:
        score_percent, metrics, scoring_version = _rule_hybrid_score(
            media=media,
            duration_seconds=duration_seconds,
            min_seconds=min_seconds,
            transcript=transcript,
            errors=errors,
            stt_engine=stt.engine,
        )
        metrics["grammar_available"] = grammar_available
        metrics["stt_engine"] = stt.engine
        metrics["stt_low_confidence"] = bool(stt.low_confidence)
        metrics["has_reply_audio"] = reply_media is not None

    level_estimate = percent_to_level(score_percent)

    return {
        "transcript": transcript,
        "correction": {"corrected_text": corrected_text, "errors": errors},
        "grammar_available": grammar_available,
        "reply": reply,
        "reply_media": reply_media,
        "score_percent": score_percent,
        "level_estimate": level_estimate,
        "scoring_version": scoring_version,
        "metrics": metrics,
    }
