"""Micro-lesson for each curriculum objective — Arabic explanation, English examples."""

from __future__ import annotations

import json
import logging
import re
import time

from fastapi import HTTPException, status

from app.core.config import get_settings
from app.services.ai_service import generate_gemini_json
from app.services.language_curriculum_service import get_level_curriculum

logger = logging.getLogger(__name__)
settings = get_settings()

_CACHE_TTL = 60 * 60 * 24
_cache: dict[str, tuple[float, dict]] = {}

_SYSTEM = (
    "You are a warm English teacher for Arabic-speaking students in Syria. "
    "Teach ONE learning objective at the given CEFR level. Explain in clear Syrian Arabic "
    "(شو، ليش، هلأ، منيح — not Egyptian). Keep it short. Return ONLY JSON: "
    '{"explanation_ar": str, "rule_points": [str], '
    '"examples": [{"en": str, "ar": str}], '
    '"key_vocab": [{"word": str, "meaning_ar": str}], '
    '"common_mistake_ar": str, "practice_tip_ar": str}'
)


def _parse(raw: str) -> dict | None:
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", (raw or "").strip())
    s, e = text.find("{"), text.rfind("}")
    if s == -1 or e == -1:
        return None
    try:
        data = json.loads(text[s : e + 1])
    except json.JSONDecodeError:
        return None
    return data if isinstance(data, dict) else None


def _obj_brief(obj: dict) -> dict:
    return {
        "id": obj["id"],
        "level": obj.get("level"),
        "title": obj.get("title"),
        "feature": obj.get("feature"),
        "grammar": obj.get("grammar"),
        "vocab": obj.get("vocab"),
    }


def _curated(obj: dict) -> dict:
    grammar = obj.get("grammar") or ""
    example = obj.get("example") or ""
    return {
        "explanation_ar": (
            f"هدف اليوم: {obj.get('title')}. "
            + (f"ركّز على القاعدة: {grammar}. " if grammar else "")
            + "اقرأ المثال جيداً ثم جرّب تطبيقه."
        ),
        "rule_points": [p for p in [grammar] if p],
        "examples": [{"en": example, "ar": ""}] if example else [],
        "key_vocab": [],
        "common_mistake_ar": "",
        "practice_tip_ar": "تمرّن قليلاً كل يوم — التكرار يثبّت اللغة.",
    }


def _normalize(lesson: dict) -> dict:
    out = {
        "explanation_ar": str(lesson.get("explanation_ar") or "").strip(),
        "rule_points": [str(p).strip() for p in (lesson.get("rule_points") or []) if str(p).strip()][:5],
        "examples": [],
        "key_vocab": [],
        "common_mistake_ar": str(lesson.get("common_mistake_ar") or "").strip(),
        "practice_tip_ar": str(lesson.get("practice_tip_ar") or "").strip(),
    }
    for ex in lesson.get("examples") or []:
        if isinstance(ex, dict) and str(ex.get("en") or "").strip():
            out["examples"].append({"en": str(ex["en"]).strip(), "ar": str(ex.get("ar") or "").strip()})
    for kv in lesson.get("key_vocab") or []:
        if isinstance(kv, dict) and str(kv.get("word") or "").strip():
            out["key_vocab"].append(
                {"word": str(kv["word"]).strip(), "meaning_ar": str(kv.get("meaning_ar") or "").strip()}
            )
    out["examples"] = out["examples"][:5]
    out["key_vocab"] = out["key_vocab"][:6]
    return out


async def get_micro_lesson(*, objective_id: str) -> dict:
    objective_id = (objective_id or "").strip()
    level = objective_id.split("-")[0] if "-" in objective_id else "A1"
    objectives = await get_level_curriculum(level)
    obj = next((o for o in objectives if o.get("id") == objective_id), None)
    if not obj:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="الهدف غير موجود")

    cached = _cache.get(objective_id)
    if cached and cached[0] > time.time():
        return {**cached[1], "objective": _obj_brief(obj)}

    lesson = None
    if settings.GEMINI_API_KEY:
        try:
            user = (
                f"Level: {obj['level']}. Objective: {obj.get('title')}. "
                f"Grammar: {obj.get('grammar')}. Vocabulary: {obj.get('vocab')}. "
                f"Example: {obj.get('example')}."
            )
            raw = await generate_gemini_json(user, system=_SYSTEM, temperature=0.5, max_output_tokens=4096)
            parsed = _parse(raw)
            if parsed and str(parsed.get("explanation_ar") or "").strip():
                lesson = _normalize(parsed)
        except Exception as exc:
            logger.warning("Micro-lesson AI failed for %s: %s", objective_id, exc)

    if not lesson:
        lesson = _normalize(_curated(obj))

    _cache[objective_id] = (time.time() + _CACHE_TTL, lesson)
    return {**lesson, "objective": _obj_brief(obj)}
