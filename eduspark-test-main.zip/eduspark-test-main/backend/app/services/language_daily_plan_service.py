"""Daily learning mission — personalized plan with adaptive objective selection."""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.language.analytics import LanguageAnalytics
from app.models.language.engagement import LanguageActivityLog
from app.services.language_adaptive_service import (
    SKILL_LABELS_AR,
    build_adaptive_state,
    sort_objectives_for_adaptive,
)
from app.services.language_curriculum_service import FEATURE_ALIASES, build_curriculum_overview
from app.services.language_subscription_service import get_default_language
from app.services.language_vocabulary_sr_service import count_due

FEATURE_DONE_EVENTS = {
    "vocabulary": ("vocabulary_known", "vocabulary_review_later", "vocabulary_reviewed"),
    "reading": ("reading_lesson_completed",),
    "listening": ("listening_lesson_completed",),
    "writing": ("writing_completed",),
    "speaking": ("speaking_completed",),
    "conversation": ("speaking_conversation_turn",),
}

ADAPTIVE_DETAIL_AR = {
    "PROMOTE": "تحدّيات أصعب اليوم — أنت جاهز للتقدّم.",
    "REMEDIAL": "مراجعة وتقوية — ركّز على الأساسيات.",
    "MAINTAIN": "استمر على وتيرة التعلّم الحالية.",
}


async def _today_events(db: AsyncSession, *, student_id: int, language_id: int) -> set[str]:
    start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    rows = await db.execute(
        select(LanguageActivityLog.event_type).where(
            LanguageActivityLog.student_id == student_id,
            LanguageActivityLog.language_id == language_id,
            LanguageActivityLog.created_at >= start,
        )
    )
    return {e for (e,) in rows.all() if e}


def _normalize_feature(feature: str | None) -> str:
    f = (feature or "conversation").strip().lower()
    return FEATURE_ALIASES.get(f, f)


def _done(feature: str, today: set[str]) -> bool:
    feature = _normalize_feature(feature)
    return any(ev in today for ev in FEATURE_DONE_EVENTS.get(feature, ()))


async def build_daily_plan(db: AsyncSession, *, student_id: int) -> dict:
    overview = await build_curriculum_overview(db, student_id=student_id)
    objectives = overview.get("objectives") or []
    adaptive = await build_adaptive_state(db, student_id=student_id)

    recommendation = adaptive.get("recommendation") or "MAINTAIN"
    strengths = adaptive.get("strengths") or []
    weaknesses = adaptive.get("weaknesses") or []
    ranked = sort_objectives_for_adaptive(
        objectives,
        recommendation=recommendation,
        strengths=strengths,
        weaknesses=weaknesses,
    )

    language = await get_default_language(db)
    analytics = await db.get(LanguageAnalytics, {"student_id": student_id, "language_id": language.id})
    today = await _today_events(db, student_id=student_id, language_id=language.id)
    due_vocab = await count_due(db, student_id=student_id, language_id=language.id)

    items: list[dict] = []

    if due_vocab > 0:
        items.append(
            {
                "kind": "vocabulary",
                "title": f"راجع {due_vocab} كلمة مستحقة",
                "detail": "التكرار المتباعد يحافظ على المفردات في الذاكرة.",
                "feature": "vocabulary",
                "focus": None,
                "objective_id": None,
                "done": _done("vocabulary", today),
            }
        )
    elif not _done("vocabulary", today):
        items.append(
            {
                "kind": "vocabulary",
                "title": "راجع المفردات اليوم",
                "detail": "حافظ على كلماتك الجديدة عبر بطاقات المفردات.",
                "feature": "vocabulary",
                "focus": None,
                "objective_id": None,
                "done": False,
            }
        )

    if recommendation == "REMEDIAL":
        weak = weaknesses[0] if weaknesses else ((analytics.primary_focus_skill if analytics else None) or None)
        if weak in SKILL_LABELS_AR:
            items.append(
                {
                    "kind": "skill",
                    "title": f"قوّي {SKILL_LABELS_AR[weak]}",
                    "detail": "مراجعة موجّهة — مهارة تحتاج دعماً إضافياً.",
                    "feature": weak if weak != "speaking" else "speaking",
                    "focus": None,
                    "objective_id": None,
                    "done": _done(weak, today),
                }
            )
    elif recommendation == "PROMOTE" and strengths:
        strong = strengths[0]
        if strong in SKILL_LABELS_AR:
            items.append(
                {
                    "kind": "skill",
                    "title": f"تحدّي {SKILL_LABELS_AR[strong]}",
                    "detail": "أداء قوي — جرّب تمريناً أصعب اليوم.",
                    "feature": strong,
                    "focus": None,
                    "objective_id": None,
                    "done": _done(strong, today),
                }
            )
    else:
        weak = (analytics.primary_focus_skill if analytics else None) or None
        if weak in SKILL_LABELS_AR:
            items.append(
                {
                    "kind": "skill",
                    "title": f"قوّي {SKILL_LABELS_AR[weak]}",
                    "detail": "مهارة تحتاج تركيزاً إضافياً اليوم.",
                    "feature": weak,
                    "focus": None,
                    "objective_id": None,
                    "done": _done(weak, today),
                }
            )

    objective_kind = "objective"
    if recommendation == "PROMOTE":
        objective_kind = "objective_challenge"
    elif recommendation == "REMEDIAL":
        objective_kind = "objective_reinforcement"

    for o in ranked[:2]:
        grammar = o.get("grammar") or ""
        focus = f"{o['title']} ({grammar})" if grammar else o["title"]
        feature = _normalize_feature(o.get("feature"))
        detail = grammar or o.get("vocab") or None
        if recommendation == "PROMOTE":
            detail = (detail or "") + (" · " if detail else "") + "تحدّي اليوم"
        elif recommendation == "REMEDIAL":
            detail = (detail or "") + (" · " if detail else "") + "مراجعة وتقوية"
        items.append(
            {
                "kind": objective_kind,
                "title": f"تمرّن: {o['title']}",
                "detail": detail,
                "feature": feature,
                "focus": focus,
                "objective_id": o["id"],
                "done": o.get("status") == "mastered" or _done(feature, today),
            }
        )

    items.append(
        {
            "kind": "conversation",
            "title": "محادثة إنجليزية قصيرة",
            "detail": "طبّق ما تعلّمته بالتحدث مع المعلم الذكي.",
            "feature": "conversation",
            "focus": None,
            "objective_id": None,
            "done": _done("conversation", today),
        }
    )

    items = items[:5]
    completed_today = sum(1 for it in items if it["done"])
    return {
        "current_level": overview.get("current_level"),
        "adaptive_recommendation": recommendation,
        "adaptive_detail_ar": ADAPTIVE_DETAIL_AR.get(recommendation, ADAPTIVE_DETAIL_AR["MAINTAIN"]),
        "mastery_progress_percent": overview.get("mastery_progress_percent", 0),
        "objectives_mastered": overview.get("objectives_mastered", 0),
        "objectives_total": overview.get("objectives_total", 0),
        "goal": len(items),
        "completed_today": completed_today,
        "due_vocab": due_vocab,
        "items": items,
    }
