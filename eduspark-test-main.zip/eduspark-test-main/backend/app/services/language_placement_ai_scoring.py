"""CEFR AI evaluation for placement writing & speaking (Arabic-speaking English learners).

Returns per-criterion scores, integrity flags, and evidence. Final score is a weighted
aggregate with anti-gaming caps — never trust a single self-reported number.

Returns None on failure so callers fall back to rule-based heuristics.

Score bands (percent_to_level):
    A1 <20 | A2 20-39 | B1 40-59 | B2 60-74 | C1 75-89 | C2 90-100
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import tempfile
from pathlib import Path

from app.core.config import get_settings
from app.services.ai_service import generate_gemini_json
from app.services.language_transcription_service import _normalize_to_wav_16k

logger = logging.getLogger(__name__)
settings = get_settings()

_MAX_TOKENS = 8192

_LEARNER_CONTEXT = (
    "The learner is an Arabic-speaking student learning English as a foreign language. "
    "Be a strict but fair examiner. Do not assume European school context."
)

_BANDS = (
    "CEFR sub-score bands (apply to EVERY criterion): A1=0-19, A2=20-39, B1=40-59, "
    "B2=60-74, C1=75-89, C2=90-100. Judge only what the learner actually produced."
)

WRITING_WEIGHTS = {
    "task_achievement": 0.20,
    "coherence_cohesion": 0.15,
    "grammar_accuracy": 0.20,
    "grammar_range": 0.15,
    "lexical_resource": 0.20,
    "mechanics": 0.10,
}
SPEAKING_WEIGHTS = {
    "task_relevance": 0.15,
    "fluency_coherence": 0.25,
    "pronunciation": 0.20,
    "grammar_accuracy": 0.20,
    "grammar_range": 0.10,
    "lexical_resource": 0.10,
}

WRITING_SYSTEM = (
    "You are a senior CEFR writing examiner. "
    f"{_LEARNER_CONTEXT} "
    f"{_BANDS} "
    "Return ONLY JSON: {"
    '"criteria": {"task_achievement": int, "coherence_cohesion": int, "grammar_accuracy": int, '
    '"grammar_range": int, "lexical_resource": int, "mechanics": int}, '
    '"flags": {"off_topic": bool, "gibberish": bool, "non_english": bool, "too_short": bool, "likely_memorized": bool}, '
    '"estimated_cefr": string, "strength": string, "key_error": string, '
    '"feedback": string, "feedback_ar": string}'
)

SPEAKING_SYSTEM = (
    "You are a senior CEFR speaking examiner. Listen to the learner's audio and evaluate it "
    "against official CEFR descriptors, criterion by criterion. "
    f"{_LEARNER_CONTEXT} "
    f"{_BANDS} "
    "Return ONLY JSON: {"
    '"transcript": string, '
    '"criteria": {"task_relevance": int, "fluency_coherence": int, "pronunciation": int, '
    '"grammar_accuracy": int, "grammar_range": int, "lexical_resource": int}, '
    '"flags": {"off_topic": bool, "gibberish": bool, "non_english": bool, "too_short": bool, "no_speech": bool, "likely_memorized": bool}, '
    '"estimated_cefr": string, "strength": string, "key_error": string, '
    '"feedback": string, "feedback_ar": string}'
)


def _parse(raw: str) -> dict | None:
    text = (raw or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    s, e = text.find("{"), text.rfind("}")
    if s == -1 or e == -1:
        return None
    try:
        return json.loads(text[s : e + 1])
    except json.JSONDecodeError:
        return None


def _clamp_int(v, lo=0, hi=100) -> int:
    try:
        return max(lo, min(hi, int(round(float(v)))))
    except (TypeError, ValueError):
        return 0


def _aggregate(criteria: dict, weights: dict, flags: dict) -> tuple[float, dict]:
    norm = {k: _clamp_int(criteria.get(k)) for k in weights}
    score = sum(norm[k] * w for k, w in weights.items())

    if flags.get("non_english") or flags.get("gibberish") or flags.get("no_speech"):
        score = min(score, 10.0)
    elif flags.get("off_topic"):
        score = min(score, 45.0)
    elif flags.get("too_short"):
        score = min(score, 55.0)
    if flags.get("likely_memorized"):
        score *= 0.75

    return max(0.0, min(100.0, round(score, 2))), norm


def _flags(data: dict) -> dict:
    raw = data.get("flags") or {}
    return {k: bool(v) for k, v in raw.items()} if isinstance(raw, dict) else {}


def _structured_metrics(data: dict, *, criteria: dict, score: float, weights: dict, flags: dict, extra: dict | None = None) -> dict:
    metrics = {
        "scorer": "ai_rubric_v2",
        "score_percent": score,
        "criteria": criteria,
        "weights": weights,
        "flags": flags,
        "estimated_cefr": data.get("estimated_cefr"),
        "strength": (data.get("strength") or "").strip(),
        "key_error": (data.get("key_error") or "").strip(),
        "feedback": (data.get("feedback") or "").strip(),
        "feedback_ar": (data.get("feedback_ar") or "").strip(),
    }
    if extra:
        metrics.update(extra)
    return metrics


async def score_writing_ai(*, text: str, prompt: str = "") -> tuple[float, dict] | None:
    text = (text or "").strip()
    if not settings.GEMINI_API_KEY or not text:
        return None
    user_prompt = f'Task prompt: {prompt or "(general writing task)"}\n\nLearner\'s writing:\n"""\n{text}\n"""'
    try:
        raw = await generate_gemini_json(
            user_prompt, system=WRITING_SYSTEM, temperature=0.1, max_output_tokens=_MAX_TOKENS
        )
    except Exception as exc:
        logger.warning("Placement writing AI scoring failed: %s", exc)
        return None
    data = _parse(raw)
    if not data or "criteria" not in data:
        return None
    flags = _flags(data)
    score, criteria = _aggregate(data.get("criteria") or {}, WRITING_WEIGHTS, flags)
    metrics = _structured_metrics(
        data,
        criteria=criteria,
        score=score,
        weights=WRITING_WEIGHTS,
        flags=flags,
        extra={"word_count": len(re.findall(r"[A-Za-z']+", text))},
    )
    return score, metrics


def _speaking_eval_sync(wav_bytes: bytes, prompt: str) -> dict | None:
    import google.generativeai as genai

    genai.configure(api_key=settings.GEMINI_API_KEY)
    model = genai.GenerativeModel(
        settings.GEMINI_MODEL,
        generation_config={
            "response_mime_type": "application/json",
            "max_output_tokens": _MAX_TOKENS,
            "temperature": 0.1,
        },
    )
    user = f'Speaking task prompt: {prompt or "(open speaking task)"}. Evaluate the attached audio now.'
    response = model.generate_content(
        [SPEAKING_SYSTEM + "\n\n" + user, {"mime_type": "audio/wav", "data": wav_bytes}],
        request_options={"timeout": 90},
    )
    return _parse(response.text or "")


async def score_speaking_ai(*, audio_data: bytes, suffix: str = ".webm", prompt: str = "") -> tuple[float, dict] | None:
    if not settings.GEMINI_API_KEY or not audio_data:
        return None
    tmp_path: Path | None = None
    wav_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            tmp.write(audio_data)
            tmp_path = Path(tmp.name)
        wav_path = _normalize_to_wav_16k(tmp_path)
        data = await asyncio.to_thread(_speaking_eval_sync, wav_path.read_bytes(), prompt)
    except Exception as exc:
        logger.warning("Placement speaking AI scoring failed: %s", exc)
        return None
    finally:
        for p in (tmp_path, wav_path):
            if p and p.exists():
                try:
                    p.unlink()
                except OSError:
                    pass
    if not data or "criteria" not in data:
        return None
    flags = _flags(data)
    score, criteria = _aggregate(data.get("criteria") or {}, SPEAKING_WEIGHTS, flags)
    metrics = _structured_metrics(
        data,
        criteria=criteria,
        score=score,
        weights=SPEAKING_WEIGHTS,
        flags=flags,
        extra={
            "transcript": (data.get("transcript") or "").strip(),
            "has_media": True,
        },
    )
    return score, metrics
