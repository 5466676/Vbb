"""Lesson audio synthesis — teacher voice clone (XTTS) with a gTTS fallback, cached on disk."""

from __future__ import annotations

import asyncio
import base64
import logging
from io import BytesIO
from pathlib import Path

import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.models.catalog import TeacherProfile
from app.models.language.content import LanguageContentItem
from app.models.language.tts_cache import LanguageLessonAudioCache
from app.models.teacher_voice import TeacherVoiceSample, VoiceSampleStatus

logger = logging.getLogger(__name__)
settings = get_settings()


def _xtts_base_url() -> str:
    return (settings.XTTS_SERVICE_URL or settings.TTS_WORKER_URL or "").strip().rstrip("/")


def _lesson_text(item: LanguageContentItem) -> str:
    body = item.body_json or {}
    text = body.get("audio_transcript") or body.get("prompt") or body.get("text") or item.title or ""
    return str(text).strip()


def _audio_dir(content_item_id: int) -> Path:
    d = Path(settings.UPLOAD_DIR) / "language_audio" / str(content_item_id)
    d.mkdir(parents=True, exist_ok=True)
    return d


def _storage_key(dest: Path) -> str:
    rel = dest.resolve().relative_to(Path(settings.UPLOAD_DIR).resolve())
    return "/".join(rel.parts)


def _synthesize_gtts(text: str, lang: str = "en") -> bytes | None:
    try:
        from gtts import gTTS

        buf = BytesIO()
        gTTS(text=text[:5000], lang=lang).write_to_fp(buf)
        data = buf.getvalue()
        return data or None
    except Exception as exc:
        logger.warning("gTTS synthesis failed: %s", exc)
        return None


async def _synthesize_xtts(text: str, speaker_wav_path: str, prompt: str) -> bytes | None:
    base = _xtts_base_url()
    if not base:
        return None
    try:
        wav_bytes = Path(speaker_wav_path).read_bytes()
    except OSError as exc:
        logger.warning("XTTS speaker wav unreadable (%s): %s", speaker_wav_path, exc)
        return None
    payload = {
        "text": text[:5000],
        "speaker_wav_base64": base64.b64encode(wav_bytes).decode("ascii"),
        "prompt": prompt or "",
    }
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(f"{base}/synthesize", json=payload)
            resp.raise_for_status()
            return resp.content or None
    except Exception as exc:
        logger.warning("XTTS service call failed: %s", exc)
        return None


async def _teacher_speaker_wav(db: AsyncSession, *, teacher_id: int) -> str | None:
    result = await db.execute(
        select(TeacherVoiceSample.storage_path)
        .join(TeacherProfile, TeacherProfile.id == TeacherVoiceSample.teacher_profile_id)
        .where(
            TeacherProfile.user_id == teacher_id,
            TeacherVoiceSample.processing_status == VoiceSampleStatus.ready.value,
            TeacherVoiceSample.teacher_accepted.is_(True),
        )
        .order_by(TeacherVoiceSample.uploaded_at.desc())
        .limit(1)
    )
    return result.scalar_one_or_none()


async def _cache_lookup(
    db: AsyncSession, *, content_item_id: int, teacher_id: int | None
) -> LanguageLessonAudioCache | None:
    query = select(LanguageLessonAudioCache).where(
        LanguageLessonAudioCache.content_item_id == content_item_id
    )
    if teacher_id is not None:
        query = query.where(
            (LanguageLessonAudioCache.teacher_id == teacher_id)
            | (LanguageLessonAudioCache.teacher_id.is_(None))
        )
    result = await db.execute(query)
    rows = list(result.scalars().all())
    if not rows:
        return None
    rows.sort(key=lambda r: 0 if r.voice_source == "teacher_clone" else 1)
    return rows[0]


def _out(row: LanguageLessonAudioCache) -> dict:
    return {
        "public_url": row.public_url,
        "duration_seconds": row.duration_seconds,
        "voice_source": row.voice_source,
    }


async def get_lesson_audio(db: AsyncSession, *, content_item_id: int, teacher_id: int | None = None) -> dict | None:
    cached = await _cache_lookup(db, content_item_id=content_item_id, teacher_id=teacher_id)
    if cached:
        disk_path = Path(settings.UPLOAD_DIR) / cached.audio_storage_key
        if disk_path.exists():
            return _out(cached)
    return await generate_lesson_audio(db, content_item_id=content_item_id, teacher_id=teacher_id)


async def generate_lesson_audio(
    db: AsyncSession, *, content_item_id: int, teacher_id: int | None = None
) -> dict | None:
    item = await db.get(LanguageContentItem, content_item_id)
    if not item:
        return None
    text = _lesson_text(item)
    if not text:
        return None

    audio: bytes | None = None
    voice_source = "gtts"
    cache_teacher_id: int | None = None

    if teacher_id is not None and _xtts_base_url():
        speaker_wav = await _teacher_speaker_wav(db, teacher_id=teacher_id)
        if speaker_wav:
            audio = await _synthesize_xtts(text, speaker_wav, prompt=item.title or "")
            if audio:
                voice_source = "teacher_clone"
                cache_teacher_id = teacher_id

    if audio is None:
        audio = await asyncio.to_thread(_synthesize_gtts, text)
        voice_source = "gtts"
        cache_teacher_id = None

    if not audio:
        return None

    suffix = "mp3"
    fname = f"{voice_source}" + (f"_{cache_teacher_id}" if cache_teacher_id else "") + f".{suffix}"
    dest = _audio_dir(content_item_id) / fname
    dest.write_bytes(audio)
    storage_key = _storage_key(dest)
    public_url = "/uploads/" + storage_key

    existing = await db.execute(
        select(LanguageLessonAudioCache).where(
            LanguageLessonAudioCache.content_item_id == content_item_id,
            LanguageLessonAudioCache.voice_source == voice_source,
            LanguageLessonAudioCache.teacher_id.is_(None)
            if cache_teacher_id is None
            else LanguageLessonAudioCache.teacher_id == cache_teacher_id,
        )
    )
    row = existing.scalar_one_or_none()
    if row is None:
        row = LanguageLessonAudioCache(
            content_item_id=content_item_id,
            voice_source=voice_source,
            teacher_id=cache_teacher_id,
        )
        db.add(row)
    row.audio_storage_key = storage_key
    row.public_url = public_url
    row.duration_seconds = None
    await db.flush()

    return {"public_url": public_url, "duration_seconds": row.duration_seconds, "voice_source": voice_source}
