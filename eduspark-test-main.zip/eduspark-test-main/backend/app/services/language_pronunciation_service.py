"""Gemini multimodal pronunciation assessment — per-word scoring, no local model/RAM.

Listens to the learner's audio (optionally against a target sentence for shadowing)
and returns an overall score plus per-word pronunciation scores. Degrades gracefully:
returns None on any failure so callers never break.
"""

from __future__ import annotations

import asyncio
import json
import logging
import tempfile
from pathlib import Path

from app.core.config import get_settings
from app.services.language_transcription_service import _normalize_to_wav_16k

logger = logging.getLogger(__name__)
settings = get_settings()

WEAK_WORD_THRESHOLD = 70  # words scoring below this are flagged as needing practice

_PROMPT_BASE = (
    "You are an English pronunciation coach. Listen to the learner's audio. {target}"
    "Return ONLY JSON with this shape: "
    '{{"transcript": string, "overall_score": integer 0-100, '
    '"words": [{{"word": string, "score": integer 0-100, "issue": short string or empty}}], '
    '"note": one short coaching tip in English}}. '
    "Score each spoken word for pronunciation clarity (100 = clear and native-like). "
    "Keep 'issue' empty when the word is fine."
)


def _clamp(value, lo=0, hi=100) -> int:
    try:
        return max(lo, min(hi, int(round(float(value)))))
    except (TypeError, ValueError):
        return 0


def _normalize_result(raw: dict | None) -> dict | None:
    if not isinstance(raw, dict):
        return None
    words_in = raw.get("words") if isinstance(raw.get("words"), list) else []
    words: list[dict] = []
    for w in words_in:
        if not isinstance(w, dict):
            continue
        word = str(w.get("word") or "").strip()
        if not word:
            continue
        score = _clamp(w.get("score"))
        words.append(
            {
                "word": word,
                "score": score,
                "issue": str(w.get("issue") or "").strip(),
                "weak": score < WEAK_WORD_THRESHOLD,
            }
        )
    return {
        "overall_score": _clamp(raw.get("overall_score")),
        "transcript": str(raw.get("transcript") or "").strip(),
        "words": words,
        "weak_words": [w["word"] for w in words if w["weak"]],
        "note": str(raw.get("note") or "").strip(),
    }


def _assess_sync(wav_bytes: bytes, expected_text: str | None) -> dict | None:
    import google.generativeai as genai

    genai.configure(api_key=settings.GEMINI_API_KEY)
    target = f'The learner is trying to say: "{expected_text}". ' if expected_text else ""
    prompt = _PROMPT_BASE.format(target=target)
    model = genai.GenerativeModel(
        settings.GEMINI_MODEL,
        generation_config={
            "response_mime_type": "application/json",
            "max_output_tokens": 1024 + 3072,  # thinking-token headroom
            "temperature": 0.2,
        },
    )
    response = model.generate_content(
        [prompt, {"mime_type": "audio/wav", "data": wav_bytes}],
        request_options={"timeout": 60},
    )
    return json.loads((response.text or "").strip())


async def assess_pronunciation(
    data: bytes, *, suffix: str = ".webm", expected_text: str | None = None
) -> dict | None:
    """Assess pronunciation of the audio. Returns None when disabled/empty/unavailable."""
    if not data or not settings.GEMINI_API_KEY:
        return None

    tmp_path: Path | None = None
    wav_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            tmp.write(data)
            tmp_path = Path(tmp.name)
        wav_path = _normalize_to_wav_16k(tmp_path)
        wav_bytes = wav_path.read_bytes()
        raw = await asyncio.to_thread(_assess_sync, wav_bytes, expected_text)
        return _normalize_result(raw)
    except Exception as exc:
        logger.warning("Pronunciation assessment failed (continuing without it): %s", exc)
        return None
    finally:
        for p in (tmp_path, wav_path):
            if p and p.exists():
                try:
                    p.unlink()
                except OSError:
                    pass


def word_similarity(spoken: str, target: str) -> int:
    """Rough word-overlap similarity (0-100) for shadowing — how close the repeat is."""
    def norm(t: str) -> list[str]:
        import re

        return [w for w in re.findall(r"[a-z']+", (t or "").lower())]

    a = norm(spoken)
    b = norm(target)
    if not b:
        return 0
    from collections import Counter

    ca, cb = Counter(a), Counter(b)
    overlap = sum((ca & cb).values())
    return _clamp(overlap / len(b) * 100)
