"""AI speaking conversation — session lifecycle and turn pipeline."""

from __future__ import annotations

import logging
import time
from datetime import datetime, timezone
from io import BytesIO

from fastapi import HTTPException, UploadFile, status
from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.models.language.analytics import LanguageAnalytics
from app.models.language.conversation import LanguageSpeakingConversationSession, LanguageSpeakingConversationTurn
from app.models.language.enums import LanguageLevel, LanguageSkill
from app.models.media import MediaObject
from app.services.language_conversation_ai_service import generate_conversation_turn
from app.services.language_conversation_correction import (
    build_correction_display,
    build_spoken_reply_text,
    resolve_correction_display,
)
from app.services.language_curriculum_service import credit_feature_objectives
from app.services.language_engagement_service import record_activity
from app.services.language_grammar_service import analyze_grammar
from app.services.language_media_service import upload_student_speaking
from app.services.language_reply_tts_service import synthesize_english_reply
from app.services.language_speaking_evolution_service import (
    build_conversation_progress,
    update_speaking_level_from_conversation,
)
from app.services.language_subscription_service import get_default_language
from app.services.language_transcription_service import transcribe_english_audio

logger = logging.getLogger(__name__)
settings = get_settings()

WELCOME_HINT = (
    "تحدّث بالإنجليزية — سأصحّح أخطاءك وأرد عليك بمستوى يناسبك."
)


def _conversation_turn_score(evaluation: dict) -> float:
    scores = (evaluation or {}).get("scores") or {}
    vals: list[float] = []
    for v in scores.values():
        try:
            vals.append(float(v))
        except (TypeError, ValueError):
            continue
    if vals:
        return round(sum(vals) / len(vals), 2)
    return 70.0


async def _effective_level(db: AsyncSession, *, student_id: int, language_id: int) -> str:
    analytics = await db.get(LanguageAnalytics, {"student_id": student_id, "language_id": language_id})
    if analytics and analytics.speaking_level:
        return analytics.speaking_level.value
    return LanguageLevel.A1.value


async def _get_or_create_active_session(
    db: AsyncSession,
    *,
    student_id: int,
    language_id: int,
) -> LanguageSpeakingConversationSession:
    result = await db.execute(
        select(LanguageSpeakingConversationSession)
        .where(
            LanguageSpeakingConversationSession.student_id == student_id,
            LanguageSpeakingConversationSession.language_id == language_id,
            LanguageSpeakingConversationSession.status == "active",
        )
        .order_by(desc(LanguageSpeakingConversationSession.started_at))
        .limit(1)
    )
    session = result.scalar_one_or_none()
    if session:
        return session

    level_str = await _effective_level(db, student_id=student_id, language_id=language_id)
    try:
        level_enum = LanguageLevel(level_str)
    except ValueError:
        level_enum = LanguageLevel.A1

    session = LanguageSpeakingConversationSession(
        student_id=student_id,
        language_id=language_id,
        status="active",
        effective_level_at_start=level_enum,
        turn_count=0,
    )
    db.add(session)
    await db.flush()
    return session


async def get_conversation_state(db: AsyncSession, *, student_id: int) -> dict:
    language = await get_default_language(db)
    session = await _get_or_create_active_session(db, student_id=student_id, language_id=language.id)
    result = await db.execute(
        select(LanguageSpeakingConversationTurn)
        .where(LanguageSpeakingConversationTurn.session_id == session.id)
        .order_by(LanguageSpeakingConversationTurn.turn_index)
    )
    turns = list(result.scalars().all())

    messages: list[dict] = []
    for turn in turns:
        user_eval = turn.evaluation_json or {}
        messages.append(
            {
                "role": "user",
                "content": turn.user_transcript,
                "turn_index": turn.turn_index,
                "evaluation": user_eval,
                "reply_audio_url": None,
            }
        )
        reply_url = None
        if turn.reply_media_object_id:
            media = await db.get(MediaObject, turn.reply_media_object_id)
            reply_url = media.public_url if media else None
        correction_display = resolve_correction_display(user_eval)
        audio_pending = bool(user_eval.get("reply_audio_pending")) and not reply_url
        messages.append(
            {
                "role": "assistant",
                "content": turn.assistant_reply,
                "turn_index": turn.turn_index,
                "evaluation": None,
                "correction_display": correction_display,
                "reply_audio_url": reply_url,
                "reply_audio_pending": audio_pending,
            }
        )

    effective = await _effective_level(db, student_id=student_id, language_id=language.id)
    return {
        "session_id": session.id,
        "effective_speaking_level": effective,
        "turn_count": session.turn_count,
        "messages": messages,
        "welcome_hint": WELCOME_HINT if not turns else None,
    }


async def process_conversation_turn(
    db: AsyncSession,
    *,
    student_id: int,
    file: UploadFile,
    duration_seconds: int | None = None,
) -> dict:
    turn_started = time.perf_counter()
    timing_ms: dict[str, int] = {}

    language = await get_default_language(db)
    session = await _get_or_create_active_session(db, student_id=student_id, language_id=language.id)
    effective = await _effective_level(db, student_id=student_id, language_id=language.id)

    upload_started = time.perf_counter()
    data = await file.read()
    if not data:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="ملف الصوت فارغ")

    upload_file = UploadFile(
        filename=file.filename or "speech.webm",
        file=BytesIO(data),
        headers={"content-type": file.content_type or "audio/webm"},
    )
    user_media = await upload_student_speaking(
        db,
        student_id=student_id,
        subfolder="language_conversation",
        filename_hint=f"turn_{session.turn_count + 1}",
        file=upload_file,
    )
    timing_ms["upload"] = int((time.perf_counter() - upload_started) * 1000)

    suffix = ".webm"
    if file.filename and "." in file.filename:
        suffix = "." + file.filename.rsplit(".", 1)[-1].lower()

    whisper_started = time.perf_counter()
    stt = await transcribe_english_audio(data, suffix=suffix)
    transcript = stt.text
    timing_ms["whisper"] = int((time.perf_counter() - whisper_started) * 1000)

    grammar_started = time.perf_counter()
    grammar = analyze_grammar(transcript)
    grammar_hints = grammar.get("errors") or []
    timing_ms["grammar"] = int((time.perf_counter() - grammar_started) * 1000)

    history_result = await db.execute(
        select(LanguageSpeakingConversationTurn)
        .where(LanguageSpeakingConversationTurn.session_id == session.id)
        .order_by(LanguageSpeakingConversationTurn.turn_index)
    )
    prior_turns = list(history_result.scalars().all())
    history = []
    for t in prior_turns:
        history.append({"role": "user", "content": t.user_transcript})
        history.append({"role": "assistant", "content": t.assistant_reply})

    gemini_started = time.perf_counter()
    ai_result = await generate_conversation_turn(
        transcript=transcript,
        effective_level=effective,
        grammar_hints=grammar_hints,
        history=history,
    )
    timing_ms["gemini"] = int((time.perf_counter() - gemini_started) * 1000)

    reply_text = ai_result.get("reply") or ""
    follow_up = ai_result.get("follow_up")
    if follow_up:
        reply_text = f"{reply_text} {follow_up}".strip()

    correction_raw = ai_result.get("correction") or {}
    correction_display = build_correction_display(correction_raw)
    spoken_reply_text = build_spoken_reply_text(
        correction_display=correction_display,
        conversation_reply=reply_text,
    )

    async_tts = bool(settings.LANGUAGE_CONVERSATION_ASYNC_TTS and settings.ENABLE_TTS and spoken_reply_text.strip())
    reply_media = None
    if not async_tts and spoken_reply_text.strip():
        tts_started = time.perf_counter()
        reply_media = await synthesize_english_reply(db, student_id=student_id, text=spoken_reply_text)
        timing_ms["tts"] = int((time.perf_counter() - tts_started) * 1000)

    evaluation = {
        "correction": correction_raw,
        "correction_display": correction_display,
        "scores": ai_result.get("scores") or {},
        "estimated_cefr": ai_result.get("estimated_cefr"),
        "coaching_note_ar": ai_result.get("coaching_note_ar"),
        "grammar_tool_used": grammar.get("available", False),
        "topic": ai_result.get("topic"),
        "reply_audio_pending": async_tts and not reply_media,
        "stt": {
            "engine": stt.engine,
            "model": stt.model,
            "raw_text": stt.raw_text,
            "avg_logprob": stt.avg_logprob,
            "no_speech_prob": stt.no_speech_prob,
            "language_probability": stt.language_probability,
            "low_confidence": stt.low_confidence,
        },
    }

    turn_index = session.turn_count + 1
    try:
        estimated = LanguageLevel(evaluation["estimated_cefr"])
    except (ValueError, TypeError):
        estimated = LanguageLevel(effective)

    turn = LanguageSpeakingConversationTurn(
        session_id=session.id,
        student_id=student_id,
        turn_index=turn_index,
        user_transcript=transcript,
        assistant_reply=reply_text,
        user_media_object_id=user_media.id,
        reply_media_object_id=reply_media.id if reply_media else None,
        duration_seconds=duration_seconds,
        evaluation_json=evaluation,
        estimated_cefr=estimated,
    )
    db.add(turn)
    session.turn_count = turn_index
    await db.flush()

    new_level, level_changed = await update_speaking_level_from_conversation(
        db, student_id=student_id, language_id=language.id
    )

    await record_activity(
        db,
        student_id=student_id,
        language_id=language.id,
        event_type="speaking_conversation_turn",
        skill=LanguageSkill.speaking,
        duration_seconds=int(duration_seconds or 0),
        payload_json={
            "session_id": session.id,
            "turn_index": turn_index,
            "estimated_cefr": evaluation.get("estimated_cefr"),
            "scores": evaluation.get("scores"),
        },
    )

    turn_score = _conversation_turn_score(evaluation)
    await credit_feature_objectives(
        db,
        student_id=student_id,
        language_id=language.id,
        feature="conversation",
        score_percent=turn_score,
        passed=bool(transcript.strip()) and turn_score >= float(settings.LANGUAGE_MASTERY_DOWN_THRESHOLD),
    )

    timing_ms["total"] = int((time.perf_counter() - turn_started) * 1000)
    logger.info(
        "Conversation turn timing_ms session=%s turn=%s upload=%s whisper=%s grammar=%s gemini=%s total=%s async_tts=%s",
        session.id,
        turn_index,
        timing_ms.get("upload"),
        timing_ms.get("whisper"),
        timing_ms.get("grammar"),
        timing_ms.get("gemini"),
        timing_ms.get("total"),
        async_tts,
    )

    result = {
        "session_id": session.id,
        "turn_id": turn.id,
        "turn_index": turn_index,
        "transcript": transcript,
        "evaluation": evaluation,
        "correction_display": correction_display,
        "reply": reply_text,
        "reply_audio_url": reply_media.public_url if reply_media else None,
        "reply_audio_pending": async_tts and not reply_media,
        "effective_speaking_level": new_level.value if new_level else effective,
        "level_changed": level_changed,
        "timing_ms": timing_ms,
    }
    if async_tts:
        result["_background_tts"] = {
            "turn_id": turn.id,
            "student_id": student_id,
            "spoken_text": spoken_reply_text,
        }
    return result


async def reset_conversation(db: AsyncSession, *, student_id: int) -> dict:
    language = await get_default_language(db)
    result = await db.execute(
        select(LanguageSpeakingConversationSession).where(
            LanguageSpeakingConversationSession.student_id == student_id,
            LanguageSpeakingConversationSession.language_id == language.id,
            LanguageSpeakingConversationSession.status == "active",
        )
    )
    now = datetime.now(timezone.utc)
    for session in result.scalars().all():
        session.status = "completed"
        session.ended_at = now
    await db.flush()
    return {"ok": True}


async def get_conversation_progress(db: AsyncSession, *, student_id: int) -> dict:
    language = await get_default_language(db)
    return await build_conversation_progress(db, student_id=student_id, language_id=language.id)
