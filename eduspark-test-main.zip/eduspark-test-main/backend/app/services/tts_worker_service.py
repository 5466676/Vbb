"""XTTS worker health probes and cached status for lesson chat voice availability."""

from __future__ import annotations

import logging
import time
from typing import Any

import httpx

from app.core.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

_last_probe: dict[str, Any] | None = None
_last_probe_at: float = 0.0
_PROBE_TTL_SECONDS = 15.0


def _worker_health_url() -> str | None:
    if not settings.ENABLE_TTS:
        return None
    provider = (settings.TTS_PROVIDER or "worker").strip().lower()
    if provider != "worker":
        return None
    base = (settings.TTS_WORKER_URL or "").strip().rstrip("/")
    return f"{base}/health" if base else None


async def probe_tts_worker(*, force: bool = False) -> dict[str, Any]:
    """Return worker reachability; cache briefly to avoid hammering /health."""
    global _last_probe, _last_probe_at

    if not settings.ENABLE_TTS:
        return {
            "enabled": False,
            "provider": settings.TTS_PROVIDER,
            "worker_url": settings.TTS_WORKER_URL,
            "available": False,
            "status": "disabled",
            "detail": "ENABLE_TTS is false",
        }

    provider = (settings.TTS_PROVIDER or "worker").strip().lower()
    if provider != "worker":
        return {
            "enabled": True,
            "provider": provider,
            "worker_url": None,
            "available": True,
            "status": "inline",
            "detail": f"TTS provider is {provider!r} (no external worker)",
        }

    health_url = _worker_health_url()
    if not health_url:
        return {
            "enabled": True,
            "provider": provider,
            "worker_url": settings.TTS_WORKER_URL,
            "available": False,
            "status": "misconfigured",
            "detail": "TTS_WORKER_URL is empty",
        }

    now = time.monotonic()
    if not force and _last_probe and (now - _last_probe_at) < _PROBE_TTL_SECONDS:
        return dict(_last_probe)

    started = time.perf_counter()
    try:
        timeout = httpx.Timeout(5.0, connect=3.0)
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.get(health_url)
        latency_ms = round((time.perf_counter() - started) * 1000, 1)
        if response.status_code == 200:
            body = response.json()
            result = {
                "enabled": True,
                "provider": provider,
                "worker_url": settings.TTS_WORKER_URL,
                "available": True,
                "status": "ok",
                "model_loaded": bool(body.get("model_loaded")),
                "latency_ms": latency_ms,
            }
        else:
            result = {
                "enabled": True,
                "provider": provider,
                "worker_url": settings.TTS_WORKER_URL,
                "available": False,
                "status": "error",
                "http_status": response.status_code,
                "detail": response.text[:200],
                "latency_ms": latency_ms,
            }
    except Exception as exc:
        latency_ms = round((time.perf_counter() - started) * 1000, 1)
        result = {
            "enabled": True,
            "provider": provider,
            "worker_url": settings.TTS_WORKER_URL,
            "available": False,
            "status": "unreachable",
            "detail": str(exc),
            "latency_ms": latency_ms,
        }

    _last_probe = result
    _last_probe_at = now
    return dict(result)


async def is_tts_worker_available(*, force: bool = False) -> bool:
    status = await probe_tts_worker(force=force)
    if not status.get("enabled"):
        return False
    if status.get("provider") != "worker":
        return True
    return bool(status.get("available"))
