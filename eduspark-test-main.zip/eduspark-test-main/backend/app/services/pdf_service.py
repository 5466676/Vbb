"""PDF text extraction with marker-pdf, with PyMuPDF/Gemini Vision OCR fallback."""

import asyncio
import base64
import logging
import os
import re
import unicodedata
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import fitz  # PyMuPDF

from app.core.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

_marker_converter = None


def _configure_marker_cache() -> None:
    cache_dir = Path(settings.UPLOAD_DIR) / "model-cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("MODEL_CACHE_DIR", str(cache_dir / "surya"))
    os.environ.setdefault("HF_HOME", str(cache_dir / "huggingface"))
    os.environ.setdefault("TRANSFORMERS_CACHE", str(cache_dir / "huggingface"))
    os.environ.setdefault("TORCH_HOME", str(cache_dir / "torch"))


def _get_marker_converter():
    global _marker_converter
    if _marker_converter is not None:
        return _marker_converter

    _configure_marker_cache()

    from marker.config.parser import ConfigParser
    from marker.converters.pdf import PdfConverter
    from marker.models import create_model_dict

    config = ConfigParser({"langs": ["Arabic", "English"]})
    _marker_converter = PdfConverter(
        config=config.generate_config_dict(),
        artifact_dict=create_model_dict(),
        processor_list=config.get_processors(),
        renderer=config.get_renderer(),
    )
    return _marker_converter


def _text_is_too_short(text: str) -> bool:
    clean = re.sub(r"\[[^\]]+\]", " ", text or "").strip()
    words = re.findall(r"[\w\u0600-\u06FF]+", clean)
    return len(clean) < settings.MIN_EXTRACTED_TEXT_CHARS or len(words) < 20


def _short_text_error() -> ValueError:
    return ValueError(
        "النص المستخرج من PDF قصير جداً. يبدو أن الملف صورة أو سكان وتعذر التعرف عليه، "
        "أو لم يتم ضبط مفتاح Gemini API. ارفع PDF نصي أوضح."
    )


def extract_text_from_pdf(pdf_path: str | Path) -> tuple[str, int, list[dict]]:
    """Returns (full_text, page_count, metadata_list per page)."""
    if settings.PDF_EXTRACTOR.lower() == "marker":
        try:
            text = extract_text_marker(pdf_path)
            if text.strip():
                page_count = _count_pdf_pages(pdf_path)
                meta = [{"page": i + 1, "chars": 0} for i in range(page_count)]
                logger.info("marker-pdf extracted %s chars from %s", len(text), pdf_path)
                return _normalize_arabic_text(text), page_count, meta
        except Exception as exc:
            logger.warning("marker-pdf extraction failed, using PyMuPDF fallback: %s", exc)

    full_text, page_count, pages_meta = extract_text_pymupdf(pdf_path)
    if _text_is_too_short(full_text):
        raise _short_text_error()
    return full_text, page_count, pages_meta


async def extract_text_from_pdf_async(pdf_path: str | Path) -> tuple[str, int, list[dict]]:
    if settings.PDF_EXTRACTOR.lower() == "marker":
        try:
            text = await asyncio.wait_for(
                asyncio.to_thread(extract_text_marker, pdf_path),
                timeout=settings.PDF_EXTRACTOR_TIMEOUT_SECONDS,
            )
            if text.strip():
                page_count = _count_pdf_pages(pdf_path)
                meta = [{"page": i + 1, "chars": 0} for i in range(page_count)]
                logger.info("marker-pdf extracted %s chars from %s", len(text), pdf_path)
                return _normalize_arabic_text(text), page_count, meta
        except TimeoutError:
            logger.warning(
                "marker-pdf exceeded %ss, using PyMuPDF fallback",
                settings.PDF_EXTRACTOR_TIMEOUT_SECONDS,
            )
        except Exception as exc:
            logger.warning("marker-pdf extraction failed, using PyMuPDF fallback: %s", exc)

    full_text, page_count, pages_meta = await asyncio.to_thread(extract_text_pymupdf, pdf_path)
    if _text_is_too_short(full_text):
        raise _short_text_error()
    return full_text, page_count, pages_meta


def extract_text_marker(pdf_path: str | Path) -> str:
    converter = _get_marker_converter()
    rendered = converter(str(pdf_path))
    return getattr(rendered, "markdown", "") or ""


def extract_text_pymupdf(pdf_path: str | Path) -> tuple[str, int, list[dict]]:
    path = Path(pdf_path)
    doc = fitz.open(path)
    texts: list[str] = []
    ocr_jobs: dict[int, bytes] = {}

    for i, page in enumerate(doc):
        text = _normalize_arabic_text(page.get_text("text") or "")
        if len(text.strip()) < 40:
            pix = page.get_pixmap(matrix=fitz.Matrix(1.5, 1.5))
            ocr_jobs[i] = pix.tobytes("png")
        texts.append(text)

    doc.close()

    if ocr_jobs:
        with ThreadPoolExecutor(max_workers=settings.OCR_MAX_CONCURRENCY) as executor:
            results = executor.map(_ocr_image, ocr_jobs.values())
            for i, ocr_text in zip(ocr_jobs.keys(), results):
                if ocr_text:
                    texts[i] = ocr_text

    pages_meta: list[dict] = []
    parts: list[str] = []
    for i, text in enumerate(texts):
        pages_meta.append({"page": i + 1, "chars": len(text)})
        if text.strip():
            parts.append(f"[صفحة {i + 1}]\n{text}")

    full = "\n\n".join(parts).strip()
    return full, len(pages_meta), pages_meta


def _count_pdf_pages(pdf_path: str | Path) -> int:
    try:
        doc = fitz.open(Path(pdf_path))
        count = len(doc)
        doc.close()
        return count
    except Exception:
        return 1


def _normalize_arabic_text(text: str) -> str:
    text = unicodedata.normalize("NFKC", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def _ocr_image(image_bytes: bytes) -> str:
    if not settings.GEMINI_API_KEY:
        return ""

    import time

    import google.generativeai as genai

    genai.configure(api_key=settings.GEMINI_API_KEY)
    model = genai.GenerativeModel(settings.GEMINI_MODEL)

    image_part = {
        "mime_type": "image/png",
        "data": base64.b64encode(image_bytes).decode(),
    }

    max_attempts = 3
    for attempt in range(1, max_attempts + 1):
        try:
            response = model.generate_content(
                [
                    "انسخ كل النص الموجود في هذه الصورة بالضبط كما هو، بدون أي شرح أو "
                    "تعليق أو ترجمة أو تنسيق إضافي. حافظ على لغة النص الأصلية وترتيب الأسطر.",
                    image_part,
                ],
                generation_config={"temperature": 0},
                request_options={"timeout": 30},
            )
            return (response.text or "").strip()
        except Exception as exc:
            if attempt == max_attempts:
                logger.warning("Gemini OCR failed for page after %s attempts: %s", attempt, exc)
                return ""
            logger.info("Gemini OCR attempt %s failed, retrying: %s", attempt, exc)
            time.sleep(attempt * 2)
    return ""


def chunk_text(text: str, chunk_size: int | None = None, overlap: int | None = None) -> list[str]:
    chunk_size = chunk_size or settings.CHUNK_SIZE
    overlap = overlap or settings.CHUNK_OVERLAP
    if not text:
        return []

    paragraphs = [p.strip() for p in re.split(r"\n{2,}", text) if p.strip()]
    chunks: list[str] = []
    current = ""

    for para in paragraphs:
        if len(current) + len(para) + 2 <= chunk_size:
            current = f"{current}\n\n{para}".strip() if current else para
        else:
            if current:
                chunks.append(current)
            if len(para) <= chunk_size:
                current = para
            else:
                # Split long paragraph by sentences
                sentences = re.split(r"(?<=[.!?؟。])\s+", para)
                current = ""
                for sent in sentences:
                    if len(current) + len(sent) + 1 <= chunk_size:
                        current = f"{current} {sent}".strip()
                    else:
                        if current:
                            chunks.append(current)
                        current = sent
                if current:
                    chunks.append(current)
                current = ""

    if current:
        chunks.append(current)

    # Apply overlap by prepending tail of previous chunk
    if overlap > 0 and len(chunks) > 1:
        overlapped: list[str] = [chunks[0]]
        for i in range(1, len(chunks)):
            prev_tail = chunks[i - 1][-overlap:]
            overlapped.append(f"{prev_tail}\n{chunks[i]}".strip())
        chunks = overlapped

    return chunks
