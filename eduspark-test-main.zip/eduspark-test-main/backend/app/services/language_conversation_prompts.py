"""CEFR-adaptive prompts for AI speaking conversation."""

from __future__ import annotations

from app.models.language.enums import LanguageLevel

LEVEL_GUIDANCE: dict[str, str] = {
    "A1": (
        "Vocabulary: high-frequency words only (go, like, want, have, good, bad). "
        "Grammar: present simple only. Avoid idioms and complex clauses. "
        "Reply shape: 1–2 simple sentences, then put ONE follow-up question in follow_up (not in reply). "
        "Topics: greetings, family, food, school."
    ),
    "A2": (
        "Vocabulary: everyday words (shop, weekend, weather, friend). "
        "Grammar: present, past simple, and going to. "
        "Reply shape: 1–2 natural sentences acknowledging the student, then ONE follow-up question in follow_up. "
        "Topics: routine, shopping, hobbies."
    ),
    "B1": (
        "Vocabulary: common conversational range with some less frequent words. "
        "Grammar: mixed tenses, because/so/when connectors. "
        "Reply shape: 2–3 natural sentences; optional brief follow_up question. "
        "Topics: travel, opinions, work, experiences."
    ),
    "B2": (
        "Vocabulary: broader range including common idioms and collocations. "
        "Grammar: complex clauses, conditionals, passive where natural. "
        "Reply shape: 3–4 natural sentences; follow_up may extend the discussion. "
        "Topics: news, culture, problems, preferences."
    ),
    "C1": (
        "Vocabulary: academic and professional register; precise word choice. "
        "Grammar: nuanced structures, hedging, discourse markers. "
        "Reply shape: professional, natural multi-sentence discourse (4–5 sentences). "
        "Topics: abstract ideas, debate, career, society."
    ),
    "C2": (
        "Vocabulary: native-like precision, subtle connotation, stylistic control. "
        "Grammar: rhetorical and sophisticated discourse. "
        "Reply shape: extended but focused professional conversation. "
        "Topics: professional debate, nuance, culture."
    ),
}

SYSTEM_PROMPT = """You are an expert English speaking tutor for Arabic-speaking students.

Rules:
- The student's effective CEFR level is provided in each request. Follow its level guidance strictly.
- Always analyze grammar, vocabulary, and sentence structure in correction.
- When has_errors is true: fill correction with original, corrected, and clear errors[].message.
- When has_errors is false: set corrected equal to original and errors to [].
- reply: main conversational response at the student's CEFR level (see level guidance for length).
- follow_up: ONE natural follow-up question when level guidance calls for it (A1/A2 always; B1+ when helpful).
  Keep reply and follow_up as separate JSON fields — the app joins them for display.
- Score fluency, grammar, vocabulary, and confidence (0-100) from the student's utterance.
- coaching_note_ar: one short Arabic tip (one sentence).
- Return ONLY valid JSON matching the schema exactly. No markdown fences.

JSON schema:
{
  "correction": {
    "has_errors": boolean,
    "original": string,
    "corrected": string,
    "errors": [{"type": "grammar|vocabulary|fluency", "message": string, "hint_ar": string}]
  },
  "scores": {
    "fluency": 0-100,
    "grammar": 0-100,
    "vocabulary": 0-100,
    "confidence": 0-100
  },
  "estimated_cefr": "A1"|"A2"|"B1"|"B2"|"C1"|"C2",
  "reply": string,
  "follow_up": string or null,
  "topic": string,
  "coaching_note_ar": string
}
"""


def level_guidance(level: LanguageLevel | str | None) -> str:
    key = level.value if isinstance(level, LanguageLevel) else (level or "A1")
    return LEVEL_GUIDANCE.get(key, LEVEL_GUIDANCE["A1"])


def build_user_prompt(
    *,
    transcript: str,
    effective_level: str,
    grammar_hints: list[dict],
    history: list[dict],
) -> str:
    history_lines = []
    for msg in history[-8:]:
        role = msg.get("role", "user")
        content = msg.get("content", "")
        history_lines.append(f"{role}: {content}")
    history_block = "\n".join(history_lines) if history_lines else "(new conversation)"

    grammar_block = ""
    if grammar_hints:
        parts = [f"- {h.get('message', '')}" for h in grammar_hints[:5]]
        grammar_block = "Optional grammar tool hints (may supplement your analysis):\n" + "\n".join(parts)

    return f"""Student effective CEFR level: {effective_level}
Level guidance: {level_guidance(effective_level)}

Conversation history:
{history_block}

{grammar_block}

Student just said (transcript):
{transcript}

Analyze, score, correct if needed, and reply naturally at the student's level."""
