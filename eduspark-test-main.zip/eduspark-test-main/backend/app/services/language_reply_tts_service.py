"""English reply TTS for AI conversation — reuses platform XTTS (tts_service)."""

from __future__ import annotations

import logging
import uuid
from pathlib import Path

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.models.media import MediaObject, StorageProvider
from app.services.media_storage_service import register_media_object
from app.services.tts_service import synthesize_cloned_speech

logger = logging.getLogger(__name__)
settings = get_settings()


def _conversation_speaker_wav() -> str | None:
    raw = (settings.LANGUAGE_CONVERSATION_SPEAKER_WAV or "").strip()
    if not raw:
        return None
    path = Path(raw)
    if path.exists():
        return str(path.resolve())
    logger.warning("Language conversation speaker wav not found: %s", raw)
    return None


async def synthesize_english_reply(
    db: AsyncSession,
    *,
    student_id: int,
    text: str,
) -> MediaObject | None:
    """Generate English reply audio via XTTS. Returns None when TTS is disabled or unavailable."""
    cleaned = (text or "").strip()
    if not cleaned:
        return None

    if not settings.ENABLE_TTS:
        logger.info("ENABLE_TTS=false — skipping conversation reply audio")
        return None

    speaker_wav = _conversation_speaker_wav()
    if not speaker_wav:
        logger.info("No LANGUAGE_CONVERSATION_SPEAKER_WAV — skipping reply audio")
        return None

    upload_dir = Path(settings.UPLOAD_DIR) / f"student_{student_id}" / "language_conversation"
    upload_dir.mkdir(parents=True, exist_ok=True)
    filename = f"reply_{uuid.uuid4().hex}.wav"
    dest = upload_dir / filename

    ok = await synthesize_cloned_speech(
        cleaned,
        speaker_wav,
        language="en",
        output_path=dest,
    )
    if not ok or not dest.exists():
        logger.warning("XTTS conversation reply failed (continuing without audio)")
        if dest.exists():
            dest.unlink(missing_ok=True)
        return None

    rel = dest.resolve().relative_to(Path(settings.UPLOAD_DIR).resolve())
    storage_key = "/".join(rel.parts)
    media = await register_media_object(
        db,
        storage_path="uploads/" + storage_key,
        mime_type="audio/wav",
        file_size_bytes=dest.stat().st_size,
        original_filename=filename,
        uploaded_by_user_id=student_id,
        storage_provider=StorageProvider.local.value,
        storage_key=storage_key,
    )
    media.public_url = "/uploads/" + storage_key
    return media
