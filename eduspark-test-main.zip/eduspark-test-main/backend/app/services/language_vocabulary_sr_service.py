"""Spaced repetition for vocabulary — SM-2 scheduling over LanguageVocabularyProgress."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from fastapi import HTTPException, status
from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.language.content import LanguageContentItem
from app.models.language.enums import LanguageVocabularyStatus
from app.models.language.progress import LanguageVocabularyProgress

REVIEW_LIMIT = 20

VOCABULARY_CONTENT_TYPE = "vocabulary"


async def _meaning_map(
    db: AsyncSession, *, language_id: int, lemmas: list[str]
) -> dict[str, dict]:
    """Map normalized lemma -> {translation_ar, example, example_ar} from vocabulary content."""
    if not lemmas:
        return {}
    from app.services.language_content_service import normalize_word

    wanted = {l for l in lemmas if l}
    if not wanted:
        return {}
    result = await db.execute(
        select(LanguageContentItem).where(
            LanguageContentItem.language_id == language_id,
            LanguageContentItem.content_type == VOCABULARY_CONTENT_TYPE,
        )
    )
    out: dict[str, dict] = {}
    for item in result.scalars().all():
        body = item.body_json or {}
        lemma = normalize_word(body.get("word") or "")
        if not lemma or lemma not in wanted or lemma in out:
            continue
        out[lemma] = {
            "translation_ar": body.get("translation_ar"),
            "example": body.get("example"),
            "example_ar": body.get("example_ar"),
        }
    return out


def compute_sm2(
    ease_factor: float, interval_days: int, repetition_number: int, quality: int
) -> tuple[float, int, int]:
    """SM-2: returns (ease_factor, interval_days, repetition_number). quality is 0-5."""
    if quality < 3:
        repetition_number = 0
        interval_days = 1
    else:
        if repetition_number == 0:
            interval_days = 1
        elif repetition_number == 1:
            interval_days = 6
        else:
            interval_days = round(interval_days * ease_factor)
        repetition_number += 1
    ease_factor = max(1.3, ease_factor + 0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02))
    return ease_factor, interval_days, repetition_number


def _due_condition(now: datetime):
    """Items that are due: scheduled at/before now (or never scheduled) and not yet 'known'."""
    return (
        or_(
            LanguageVocabularyProgress.next_review_at <= now,
            LanguageVocabularyProgress.next_review_at.is_(None),
        ),
        LanguageVocabularyProgress.status != LanguageVocabularyStatus.known,
    )


def _item_out(row: LanguageVocabularyProgress, meaning: dict | None = None) -> dict:
    meaning = meaning or {}
    return {
        "vocabulary_id": row.id,
        "lemma": row.lemma,
        "status": row.status.value if hasattr(row.status, "value") else str(row.status),
        "interval_days": int(row.interval_days or 1),
        "ease_factor": round(float(row.ease_factor or 2.5), 2),
        "repetition_number": int(row.repetition_number or 0),
        "review_count": int(row.review_count or 0),
        "mastery_score": round(float(row.mastery_score or 0.0), 2),
        "next_review_at": row.next_review_at,
        "translation_ar": meaning.get("translation_ar"),
        "example": meaning.get("example"),
        "example_ar": meaning.get("example_ar"),
    }


async def get_review_queue(
    db: AsyncSession, *, student_id: int, language_id: int, limit: int = REVIEW_LIMIT
) -> list[dict]:
    now = datetime.now(timezone.utc)
    result = await db.execute(
        select(LanguageVocabularyProgress)
        .where(
            LanguageVocabularyProgress.student_id == student_id,
            LanguageVocabularyProgress.language_id == language_id,
            *_due_condition(now),
        )
        .order_by(LanguageVocabularyProgress.next_review_at.asc().nulls_first())
        .limit(limit)
    )
    rows = result.scalars().all()
    meanings = await _meaning_map(
        db, language_id=language_id, lemmas=[r.lemma for r in rows]
    )
    return [_item_out(r, meanings.get(r.lemma)) for r in rows]


async def count_due(db: AsyncSession, *, student_id: int, language_id: int) -> int:
    now = datetime.now(timezone.utc)
    result = await db.execute(
        select(func.count())
        .select_from(LanguageVocabularyProgress)
        .where(
            LanguageVocabularyProgress.student_id == student_id,
            LanguageVocabularyProgress.language_id == language_id,
            *_due_condition(now),
        )
    )
    return int(result.scalar() or 0)


async def submit_review(db: AsyncSession, *, student_id: int, vocabulary_id: int, quality: int) -> dict:
    if not isinstance(quality, int) or quality < 0 or quality > 5:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="quality must be between 0 and 5")

    row = await db.get(LanguageVocabularyProgress, vocabulary_id)
    if not row or row.student_id != student_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Vocabulary item not found")

    ease, interval, repetition = compute_sm2(
        float(row.ease_factor or 2.5),
        int(row.interval_days or 1),
        int(row.repetition_number or 0),
        quality,
    )
    now = datetime.now(timezone.utc)
    row.ease_factor = ease
    row.interval_days = interval
    row.repetition_number = repetition
    row.review_count = int(row.review_count or 0) + 1
    row.last_reviewed_at = now
    row.next_review_at = now + timedelta(days=interval)

    if repetition >= 5 and quality >= 4:
        row.status = LanguageVocabularyStatus.known
        row.mastery_score = 1.0
    elif quality >= 3:
        row.status = LanguageVocabularyStatus.learning
        row.mastery_score = min(0.99, repetition / 5.0)
    else:
        row.status = LanguageVocabularyStatus.new
        row.mastery_score = max(0.0, float(row.mastery_score or 0.0) - 0.2)

    await db.flush()
    from app.services.language_engagement_service import record_activity

    await record_activity(
        db,
        student_id=student_id,
        language_id=row.language_id,
        event_type="vocabulary_reviewed",
        payload_json={"lemma": row.lemma, "quality": quality, "new_status": row.status.value},
    )
    return {
        "lemma": row.lemma,
        "new_status": row.status.value,
        "next_review_at": row.next_review_at,
        "interval_days": int(row.interval_days or 1),
        "ease_factor": round(float(row.ease_factor or 2.5), 2),
        "repetition_number": int(row.repetition_number or 0),
        "mastery_score": round(float(row.mastery_score or 0.0), 2),
    }


async def upsert_vocabulary_with_sr(
    db: AsyncSession, *, student_id: int, language_id: int, lemmas: list[str]
) -> None:
    """Insert new lemmas (scheduled due now) and backfill next_review_at on existing rows."""
    if not lemmas:
        return
    now = datetime.now(timezone.utc)
    for raw in lemmas:
        lemma = (raw or "").strip().lower()
        if not lemma or len(lemma) > 120:
            continue
        existing = await db.execute(
            select(LanguageVocabularyProgress).where(
                LanguageVocabularyProgress.student_id == student_id,
                LanguageVocabularyProgress.language_id == language_id,
                LanguageVocabularyProgress.lemma == lemma,
            )
        )
        row = existing.scalar_one_or_none()
        if row is not None:
            if row.next_review_at is None:
                row.next_review_at = now
            continue
        db.add(
            LanguageVocabularyProgress(
                student_id=student_id,
                language_id=language_id,
                lemma=lemma,
                status=LanguageVocabularyStatus.new,
                review_count=0,
                first_seen_at=now,
                mastery_score=0.0,
                next_review_at=now,
                interval_days=1,
                ease_factor=2.5,
                repetition_number=0,
            )
        )
    await db.flush()


async def get_vocabulary_stats(db: AsyncSession, *, student_id: int, language_id: int) -> dict:
    result = await db.execute(
        select(LanguageVocabularyProgress.status, func.count())
        .where(
            LanguageVocabularyProgress.student_id == student_id,
            LanguageVocabularyProgress.language_id == language_id,
        )
        .group_by(LanguageVocabularyProgress.status)
    )
    counts = {"new": 0, "learning": 0, "known": 0}
    for st, cnt in result.all():
        key = st.value if hasattr(st, "value") else str(st)
        counts[key] = int(cnt)
    due = await count_due(db, student_id=student_id, language_id=language_id)
    total = counts["new"] + counts["learning"] + counts["known"]
    return {
        "new": counts["new"],
        "learning": counts["learning"],
        "known": counts["known"],
        "total": total,
        "due_today": due,
    }
