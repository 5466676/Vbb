"""Text-to-speech for AI tutor answers.

The preferred provider is an external XTTS worker so the main API does not
load the heavy voice-cloning model in-process.
"""

import asyncio
import logging
import mimetypes
import time
import uuid
from pathlib import Path

import httpx

from app.core.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

_tts_model = None


def _allowed_languages() -> set[str]:
    return {
        lang.strip().lower()
        for lang in (settings.TTS_ALLOWED_LANGUAGES or "ar,en,fr").split(",")
        if lang.strip()
    }


def _tts_language() -> str:
    language = (settings.TTS_LANGUAGE or "ar").strip().lower()
    allowed = _allowed_languages()
    if language in allowed:
        return language
    fallback = "ar" if "ar" in allowed else next(iter(allowed), "ar")
    logger.warning("Unsupported TTS_LANGUAGE=%s; falling back to %s", language, fallback)
    return fallback


def _get_tts_model():
    global _tts_model
    if _tts_model is not None:
        return _tts_model

    import torch
    from TTS.api import TTS

    device = "cuda" if torch.cuda.is_available() else "cpu"
    logger.info("Loading TTS model %s on %s", settings.TTS_MODEL, device)
    _tts_model = TTS(settings.TTS_MODEL).to(device)
    return _tts_model


def _resolve_language(language: str | None) -> str:
    if language:
        normalized = language.strip().lower()
        allowed = _allowed_languages()
        if normalized in allowed:
            return normalized
        logger.warning("Unsupported TTS language=%s; falling back to default", language)
    return _tts_language()


async def synthesize_cloned_speech(
    text: str,
    speaker_wav: str | None,
    *,
    language: str,
    output_path: Path,
) -> bool:
    """Generate cloned speech at output_path via XTTS (worker or inline)."""
    cleaned = prepare_synthesis_text(text)
    if not settings.ENABLE_TTS or not cleaned or not speaker_wav:
        return False

    speaker_path = Path(speaker_wav)
    if not speaker_path.exists():
        logger.warning("XTTS skipped: speaker file missing path=%s", speaker_wav)
        return False

    output_path.parent.mkdir(parents=True, exist_ok=True)
    lang = _resolve_language(language)
    try:
        return await _synthesize(cleaned, speaker_path, output_path, language=lang)
    except Exception as exc:
        logger.warning("XTTS synthesis failed: %s", exc)
        return False


async def synthesize_answer_audio(
    text: str,
    speaker_wav: str | None,
    lesson_id: int,
) -> str | None:
    """Return a public /uploads URL for generated audio, or None on fallback."""
    text = prepare_synthesis_text(text)
    if not settings.ENABLE_TTS or not text or not speaker_wav:
        return None

    speaker_path = Path(speaker_wav)
    if not speaker_path.exists():
        logger.warning("Answer TTS skipped: speaker file missing lesson_id=%s path=%s", lesson_id, speaker_wav)
        return None

    started = time.perf_counter()
    try:
        output_dir = Path(settings.TTS_OUTPUT_DIR)
        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = output_dir / f"lesson_{lesson_id}_{uuid.uuid4().hex}.wav"
        ok = await _synthesize(text, speaker_path, output_path)
        duration_s = time.perf_counter() - started
        if not ok:
            logger.warning(
                "Answer TTS synthesis failed lesson_id=%s duration_s=%.2f",
                lesson_id,
                duration_s,
            )
            return None
        url = _upload_url(output_path)
        logger.info("Answer TTS synthesis ok lesson_id=%s duration_s=%.2f url=%s", lesson_id, duration_s, url)
        return url
    except Exception as exc:
        duration_s = time.perf_counter() - started
        logger.warning(
            "Answer TTS synthesis failed lesson_id=%s duration_s=%.2f error=%s",
            lesson_id,
            duration_s,
            exc,
        )
        return None


def prepare_synthesis_text(text: str, *, max_chars: int | None = None) -> str:
    """Normalize tutor reply text before XTTS (avoids empty/tokenizer failures)."""
    import re

    no_bullets = re.sub(r"(?m)^[ \t]*-\s+", "", text or "")
    cleaned = " ".join(no_bullets.split())
    cleaned = re.sub(r"[\[\](){}]", " ", cleaned)
    cleaned = " ".join(cleaned.split())
    limit = max_chars or int(getattr(settings, "TTS_MAX_TEXT_CHARS", 1200) or 1200)
    if len(cleaned) > limit:
        cleaned = cleaned[:limit].rsplit(" ", 1)[0].strip() or cleaned[:limit].strip()
    return cleaned.strip()


async def synthesize_preview_audio(
    text: str,
    speaker_wav: str | None,
    *,
    sample_id: int,
) -> str | None:
    """Generate a teacher voice preview clip (not tied to a lesson)."""
    if not settings.ENABLE_TTS or not text.strip() or not speaker_wav:
        return None

    speaker_path = Path(speaker_wav)
    if not speaker_path.exists():
        return None

    try:
        output_dir = Path(settings.TTS_OUTPUT_DIR)
        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = output_dir / f"voice_preview_{sample_id}_{uuid.uuid4().hex}.wav"
        ok = await _synthesize(text, speaker_path, output_path)
        if not ok:
            return None
        return _upload_url(output_path)
    except Exception as exc:
        logger.warning("Voice preview synthesis failed: %s", exc)
        return None


async def _synthesize(
    text: str,
    speaker_path: Path,
    output_path: Path,
    *,
    language: str | None = None,
) -> bool:
    lang = _resolve_language(language)
    provider = (settings.TTS_PROVIDER or "worker").strip().lower()
    if provider == "inline":
        await asyncio.to_thread(_synthesize_sync, text, speaker_path, output_path, language=lang)
        return output_path.exists()
    return await _synthesize_via_worker(text, speaker_path, output_path, language=lang)


async def _synthesize_via_worker(
    text: str,
    speaker_path: Path,
    output_path: Path,
    *,
    language: str,
) -> bool:
    worker_url = (settings.TTS_WORKER_URL or "").rstrip("/")
    if not worker_url:
        return False

    mime_type = mimetypes.guess_type(speaker_path.name)[0] or "audio/wav"
    timeout = httpx.Timeout(float(settings.TTS_REQUEST_TIMEOUT_SECONDS))
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            with speaker_path.open("rb") as speaker_file:
                response = await client.post(
                    f"{worker_url}/synthesize",
                    data={
                        "text": text,
                        "language": language,
                    },
                    files={
                        "speaker": (speaker_path.name, speaker_file, mime_type),
                    },
                )
        if response.status_code != 200:
            logger.warning(
                "TTS worker failed status=%s body=%s",
                response.status_code,
                response.text[:500],
            )
            return False
        output_path.write_bytes(response.content)
        return output_path.exists() and output_path.stat().st_size > 0
    except Exception as exc:
        logger.warning("TTS worker request failed: %s", exc)
        return False


def _synthesize_sync(text: str, speaker_path: Path, output_path: Path, *, language: str | None = None) -> None:
    model = _get_tts_model()
    model.tts_to_file(
        text=text,
        speaker_wav=str(speaker_path),
        language=_resolve_language(language),
        file_path=str(output_path),
    )


def _upload_url(path: Path) -> str:
    upload_root = Path(settings.UPLOAD_DIR).resolve()
    rel = path.resolve().relative_to(upload_root).as_posix()
    return f"/uploads/{rel}"
