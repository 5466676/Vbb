"""Nightly AI lesson generation — keep each (skill, level) lesson pool topped up.

A cron/off-peak job calls run_nightly_topup(); Gemini generates fresh, CEFR-aligned lessons
(woven with the level's curriculum grammar/vocab themes), they are validated with the same
rules as the seed content, then stored as published LanguageContentItem rows. During the day
the normal lesson endpoints serve them from the (now larger, fresher) pool — no live AI cost.

Falls back to a no-op when Gemini is unavailable, so the seeded 240 always remain.
"""

from __future__ import annotations

import json
import logging
import re
from datetime import datetime, timezone

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.models.language.content import LanguageContentItem
from app.models.language.enums import LanguageLevel, LanguageSkill
from app.services.ai_service import generate_gemini_json
from app.services.language_curriculum_service import get_level_curriculum
from app.services.language_subscription_service import get_default_language

logger = logging.getLogger(__name__)
settings = get_settings()

LEVELS = ["A1", "A2", "B1", "B2", "C1", "C2"]
SKILLS = ["reading", "listening", "writing", "speaking"]
CONTENT_TYPE = {
    "reading": "lesson",
    "listening": "lesson",
    "writing": "writing_prompt",
    "speaking": "speaking_prompt",
}
TARGET_PER_BUCKET = 12
MAX_PER_CALL = 3
WORDS_FOR_LEVEL = {"A1": 45, "A2": 70, "B1": 110, "B2": 170, "C1": 230, "C2": 280}


def _parse(raw: str) -> list[dict] | None:
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", (raw or "").strip())
    s, e = text.find("{"), text.rfind("}")
    if s == -1 or e == -1:
        return None
    try:
        data = json.loads(text[s : e + 1])
    except json.JSONDecodeError:
        return None
    items = data.get("items")
    return items if isinstance(items, list) and items else None


def _valid_mcq(body: dict) -> bool:
    qs = body.get("questions")
    if not isinstance(qs, list) or not qs:
        return False
    for q in qs:
        ch = q.get("choices")
        if not isinstance(ch, list) or len(ch) != 4:
            return False
        if not isinstance(q.get("correct_index"), int) or q["correct_index"] not in (0, 1, 2, 3):
            return False
    return True


def _build_prompt(skill: str, level: str, count: int, themes: str) -> tuple[str, str]:
    words = WORDS_FOR_LEVEL.get(level, 100)
    theme_line = f" Reinforce these grammar/vocabulary themes where natural: {themes}." if themes else ""
    common = (
        f"You are a CEFR curriculum author. Generate exactly {count} DISTINCT CEFR {level} "
        f"English {skill} lessons for adult Arabic-speaking English learners "
        f"(everyday life, study, and integration topics).{theme_line} "
        "Every title_ar / *_ar field MUST be in SYRIAN ARABIC dialect (شو، ليش، هلأ؛ never Egyptian)."
    )
    if skill in ("reading", "listening"):
        field = "passage" if skill == "reading" else "audio_transcript"
        extra = "" if skill == "reading" else '"instructions": short English listening instruction, '
        sys = (
            common
            + f" Each lesson: a ~{words}-word English {field} + exactly 2 multiple-choice questions "
            "(4 choices each, exactly one correct). "
            'Return ONLY JSON: {"items":[{"title": str, "title_ar": str, '
            + (f'"{field}": str, "{field}_ar": str, ' if skill == "reading" else f'"{field}": str, ')
            + extra
            + '"questions":[{"stem": str, "choices":[str,str,str,str], "correct_index": 0-3}]}]}'
        )
    elif skill == "writing":
        sys = (
            common
            + " Each lesson: a clear writing prompt + a minimum word count appropriate to the level. "
            'Return ONLY JSON: {"items":[{"title": str, "title_ar": str, "prompt": str, '
            '"prompt_ar": str, "min_words": int, "min_sentences": int}]}'
        )
    else:
        sys = (
            common
            + " Each lesson: a speaking prompt the learner answers aloud + a minimum duration in seconds. "
            'Return ONLY JSON: {"items":[{"title": str, "title_ar": str, "prompt": str, '
            '"prompt_ar": str, "min_seconds": int}]}'
        )
    user = f"Write the {count} CEFR {level} {skill} lessons now as JSON."
    return sys, user


def _to_body(skill: str, level: str, raw: dict) -> dict | None:
    title = str(raw.get("title") or "").strip()
    title_ar = str(raw.get("title_ar") or "").strip()
    if not title or not title_ar:
        return None
    body: dict = {
        "title_ar": title_ar,
        "source": "ai_nightly",
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }
    if skill == "reading":
        passage = str(raw.get("passage") or "").strip()
        if not passage:
            return None
        body.update(
            passage=passage,
            passage_ar=str(raw.get("passage_ar") or "").strip() or None,
            questions=raw.get("questions") or [],
        )
        if not _valid_mcq(body):
            return None
    elif skill == "listening":
        transcript = str(raw.get("audio_transcript") or "").strip()
        if not transcript:
            return None
        body.update(
            audio_transcript=transcript,
            instructions=str(raw.get("instructions") or "Listen and answer the questions.").strip(),
            questions=raw.get("questions") or [],
        )
        if not _valid_mcq(body):
            return None
    elif skill == "writing":
        prompt = str(raw.get("prompt") or "").strip()
        if not prompt or not isinstance(raw.get("min_words"), int):
            return None
        body.update(
            prompt=prompt,
            prompt_ar=str(raw.get("prompt_ar") or "").strip() or None,
            min_words=int(raw["min_words"]),
            min_sentences=int(raw.get("min_sentences") or 2),
        )
    else:
        prompt = str(raw.get("prompt") or "").strip()
        if not prompt or not isinstance(raw.get("min_seconds"), int):
            return None
        body.update(
            prompt=prompt,
            prompt_ar=str(raw.get("prompt_ar") or "").strip() or None,
            min_seconds=int(raw["min_seconds"]),
        )
    return {"title": title, "body": body}


async def _existing_titles(db: AsyncSession, *, language_id: int, skill: str, level: str) -> set[str]:
    rows = await db.execute(
        select(LanguageContentItem.title).where(
            LanguageContentItem.language_id == language_id,
            LanguageContentItem.skill == LanguageSkill(skill),
            LanguageContentItem.level == LanguageLevel(level),
            LanguageContentItem.content_type == CONTENT_TYPE[skill],
        )
    )
    return {str(t).strip() for (t,) in rows.all() if t}


async def _published_count(db: AsyncSession, *, language_id: int, skill: str, level: str) -> int:
    res = await db.execute(
        select(func.count())
        .select_from(LanguageContentItem)
        .where(
            LanguageContentItem.language_id == language_id,
            LanguageContentItem.skill == LanguageSkill(skill),
            LanguageContentItem.level == LanguageLevel(level),
            LanguageContentItem.content_type == CONTENT_TYPE[skill],
            LanguageContentItem.is_published.is_(True),
        )
    )
    return int(res.scalar() or 0)


async def generate_and_store(
    db: AsyncSession, *, language_id: int, skill: str, level: str, count: int
) -> int:
    """Generate up to `count` lessons for (skill, level) and store the valid, non-duplicate ones."""
    if not settings.GEMINI_API_KEY or count <= 0:
        return 0
    objectives = await get_level_curriculum(level)
    themes = ", ".join(
        f"{o.get('grammar') or ''} / {o.get('vocab') or ''}".strip(" /") for o in objectives[:5]
    )
    existing = await _existing_titles(db, language_id=language_id, skill=skill, level=level)
    inserted = 0
    remaining = count
    while remaining > 0:
        n = min(MAX_PER_CALL, remaining)
        sys, user = _build_prompt(skill, level, n, themes)
        try:
            raw = await generate_gemini_json(user, system=sys, temperature=0.7, max_output_tokens=8192)
        except Exception as exc:
            logger.warning("lesson gen failed [%s][%s]: %s", skill, level, exc)
            break
        items = _parse(raw)
        if not items:
            break
        produced = 0
        for raw_item in items:
            norm = _to_body(skill, level, raw_item if isinstance(raw_item, dict) else {})
            if not norm or norm["title"] in existing:
                continue
            existing.add(norm["title"])
            db.add(
                LanguageContentItem(
                    language_id=language_id,
                    skill=LanguageSkill(skill),
                    level=LanguageLevel(level),
                    content_type=CONTENT_TYPE[skill],
                    title=norm["title"],
                    body_json=norm["body"],
                    sort_order=0,
                    is_published=True,
                )
            )
            inserted += 1
            produced += 1
        await db.flush()
        remaining -= n
        if produced == 0:
            break
    return inserted


async def run_nightly_topup(
    db: AsyncSession, *, language_id: int | None = None, target: int = TARGET_PER_BUCKET
) -> dict:
    """Top every (skill, level) bucket up to `target` published lessons. Returns a summary."""
    if language_id is None:
        language = await get_default_language(db)
        language_id = language.id
    summary: dict[str, int] = {}
    total = 0
    for skill in SKILLS:
        for level in LEVELS:
            have = await _published_count(db, language_id=language_id, skill=skill, level=level)
            deficit = max(0, target - have)
            if deficit <= 0:
                continue
            made = await generate_and_store(db, language_id=language_id, skill=skill, level=level, count=deficit)
            if made:
                summary[f"{skill}_{level}"] = made
                total += made
    summary["_total"] = total
    return summary
