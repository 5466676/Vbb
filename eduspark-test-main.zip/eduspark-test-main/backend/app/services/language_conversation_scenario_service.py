"""Guided English conversation scenarios — role-play with adaptive difficulty.

Supports text and voice turns (STT/TTS), in-character AI replies, end-of-session
scoring (communication, grammar, vocabulary, fluency), and structured feedback.
"""

from __future__ import annotations

import json
import logging
import re
import time
from datetime import datetime, timezone
from io import BytesIO

from fastapi import HTTPException, UploadFile, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.models.language.analytics import LanguageAnalytics
from app.models.language.conversation import (
    LanguageSpeakingConversationSession,
    LanguageSpeakingConversationTurn,
)
from app.models.language.enums import LanguageLevel, LanguageSkill
from app.models.language.scenario import LanguageConversationScenario
from app.models.media import MediaObject
from app.services.ai_service import generate_gemini_json
from app.services.language_adaptive_service import get_adaptive_state_overview, record_lesson_result
from app.services.language_curriculum_service import build_curriculum_overview
from app.services.language_engagement_service import record_activity
from app.services.language_level_utils import CEFR_RANK, RANK_CEFR
from app.services.language_media_service import upload_student_speaking
from app.services.language_reply_tts_service import synthesize_english_reply
from app.services.language_transcription_service import transcribe_english_audio

logger = logging.getLogger(__name__)
settings = get_settings()

HISTORY_LIMIT = 10

SCENARIO_CATEGORIES = (
    "airport",
    "hotel",
    "restaurant",
    "university",
    "job_interview",
    "doctor",
    "shopping",
    "daily_conversation",
)

CATEGORY_LABELS = {
    "airport": {"en": "Airport", "ar": "المطار"},
    "hotel": {"en": "Hotel", "ar": "الفندق"},
    "restaurant": {"en": "Restaurant", "ar": "المطعم"},
    "university": {"en": "University", "ar": "الجامعة"},
    "job_interview": {"en": "Job Interview", "ar": "مقابلة عمل"},
    "doctor": {"en": "Doctor", "ar": "الطبيب"},
    "shopping": {"en": "Shopping", "ar": "التسوّق"},
    "daily_conversation": {"en": "Daily Conversation", "ar": "محادثة يومية"},
}

_LEVEL_INSTRUCTIONS = {
    "A1": "Use very simple vocabulary and short sentences (5-8 words). Ask yes/no or one-word-answer questions.",
    "A2": "Use everyday vocabulary and simple questions. Keep sentences short and clear.",
    "B1": "Use natural conversational English with common idioms. Ask follow-up questions.",
    "B2": "Use fluent, natural conversation with varied sentence structures and appropriate register.",
    "C1": "Use sophisticated vocabulary and nuanced expressions while staying in character.",
    "C2": "Use fully natural, native-like conversation with subtle cultural references when appropriate.",
}


def _parse_json(raw: str) -> dict | None:
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", (raw or "").strip())
    s, e = text.find("{"), text.rfind("}")
    if s == -1 or e == -1:
        return None
    try:
        data = json.loads(text[s : e + 1])
    except json.JSONDecodeError:
        return None
    return data if isinstance(data, dict) else None


async def _student_speaking_level(db: AsyncSession, *, student_id: int, language_id: int) -> LanguageLevel:
    analytics = await db.get(LanguageAnalytics, {"student_id": student_id, "language_id": language_id})
    if analytics and analytics.speaking_level:
        return analytics.speaking_level
    return LanguageLevel.A1


async def _adaptive_session_level(db: AsyncSession, *, student_id: int, language_id: int) -> LanguageLevel:
    """Blend placement/speaking level, adaptive streaks, and curriculum progress."""
    speaking = await _student_speaking_level(db, student_id=student_id, language_id=language_id)
    rank = CEFR_RANK[speaking]

    overview = await build_curriculum_overview(db, student_id=student_id)
    cur_rank = CEFR_RANK.get(LanguageLevel(overview.get("current_level") or speaking.value), rank)
    mastery = int(overview.get("mastery_progress_percent") or 0)

    adaptive = await get_adaptive_state_overview(db, student_id=student_id, language_id=language_id)
    speaking_snap = (adaptive.get("skills") or {}).get("speaking") or {}
    passes = int(speaking_snap.get("consecutive_pass") or 0)
    fails = int(speaking_snap.get("consecutive_fail") or 0)

    if passes >= 2 and rank < 6:
        rank = min(rank + 1, 6)
    elif fails >= 1 and rank > 1:
        rank = max(rank - 1, 1)

    if mastery >= 70 and cur_rank > rank:
        rank = min(rank + 1, cur_rank)
    elif mastery < 30 and cur_rank < rank:
        rank = max(rank - 1, cur_rank)

    rank = max(MIN_RANK := 1, min(rank, cur_rank + 1, 6))
    return RANK_CEFR[rank]


def _scenario_out(s: LanguageConversationScenario, locked: bool, *, recommended: bool = False) -> dict:
    skills = s.target_skills_json if isinstance(s.target_skills_json, list) else []
    labels = CATEGORY_LABELS.get(s.category, {"en": s.category, "ar": s.category})
    return {
        "id": s.id,
        "scenario_key": s.scenario_key,
        "category": s.category,
        "category_label_en": labels["en"],
        "category_label_ar": labels["ar"],
        "title_en": s.title_en,
        "title_ar": s.title_ar,
        "description_en": s.description_en,
        "description_ar": s.description_ar,
        "level_min": s.level_min.value,
        "target_skills": skills,
        "ai_role": s.ai_role,
        "student_role": s.student_role,
        "opening_message": s.opening_line,
        "locked": locked,
        "recommended": recommended,
    }


async def list_scenarios(
    db: AsyncSession,
    *,
    student_id: int,
    language_id: int,
    category: str | None = None,
) -> list[dict]:
    level = await _student_speaking_level(db, student_id=student_id, language_id=language_id)
    rank = CEFR_RANK[level]
    q = (
        select(LanguageConversationScenario)
        .where(
            LanguageConversationScenario.language_id == language_id,
            LanguageConversationScenario.is_active.is_(True),
        )
        .order_by(LanguageConversationScenario.sort_order, LanguageConversationScenario.id)
    )
    if category:
        q = q.where(LanguageConversationScenario.category == category)
    scenarios = list((await db.execute(q)).scalars().all())
    unlocked = [s for s in scenarios if CEFR_RANK[s.level_min] <= rank]
    recommended_id = unlocked[0].id if unlocked else None
    return [
        _scenario_out(s, CEFR_RANK[s.level_min] > rank, recommended=(s.id == recommended_id))
        for s in scenarios
    ]


async def get_scenario_detail(
    db: AsyncSession,
    *,
    student_id: int,
    language_id: int,
    scenario_id: int,
) -> dict:
    scenario = await db.get(LanguageConversationScenario, scenario_id)
    if not scenario or not scenario.is_active or scenario.language_id != language_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Scenario not found")

    level = await _student_speaking_level(db, student_id=student_id, language_id=language_id)
    locked = CEFR_RANK[scenario.level_min] > CEFR_RANK[level]
    effective = await _adaptive_session_level(db, student_id=student_id, language_id=language_id)
    return {
        **_scenario_out(scenario, locked),
        "effective_level": effective.value,
        "student_level": level.value,
    }


async def start_scenario_session(db: AsyncSession, *, student_id: int, language_id: int, scenario_id: int) -> dict:
    scenario = await db.get(LanguageConversationScenario, scenario_id)
    if not scenario or not scenario.is_active or scenario.language_id != language_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Scenario not found")

    level = await _student_speaking_level(db, student_id=student_id, language_id=language_id)
    if CEFR_RANK[scenario.level_min] > CEFR_RANK[level]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"This scenario needs level {scenario.level_min.value} or higher.",
        )

    effective = await _adaptive_session_level(db, student_id=student_id, language_id=language_id)
    now = datetime.now(timezone.utc)
    active = await db.execute(
        select(LanguageSpeakingConversationSession).where(
            LanguageSpeakingConversationSession.student_id == student_id,
            LanguageSpeakingConversationSession.language_id == language_id,
            LanguageSpeakingConversationSession.status == "active",
        )
    )
    for sess in active.scalars().all():
        sess.status = "ended"
        sess.ended_at = now

    session = LanguageSpeakingConversationSession(
        student_id=student_id,
        language_id=language_id,
        status="active",
        scenario_id=scenario.id,
        effective_level_at_start=effective,
        turn_count=0,
    )
    db.add(session)
    await db.flush()
    await record_activity(
        db,
        student_id=student_id,
        language_id=language_id,
        event_type="scenario_start",
        skill=LanguageSkill.speaking,
        payload_json={"scenario_id": scenario.id},
    )
    return {
        "session_id": session.id,
        "scenario": _scenario_out(scenario, False),
        "opening_message": scenario.opening_line,
        "opening_line": scenario.opening_line,
        "ai_role": scenario.ai_role,
        "student_role": scenario.student_role,
        "effective_level": effective.value,
    }


async def _load_scenario_session(
    db: AsyncSession, *, session_id: int, student_id: int
) -> tuple[LanguageSpeakingConversationSession, LanguageConversationScenario]:
    session = await db.get(LanguageSpeakingConversationSession, session_id)
    if not session or session.student_id != student_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Session not found")
    if session.status != "active":
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="This session has ended")
    if not session.scenario_id:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="This session is not a scenario session")
    scenario = await db.get(LanguageConversationScenario, session.scenario_id)
    if not scenario:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Scenario not found")
    return session, scenario


def _level_instruction(level: LanguageLevel) -> str:
    return _LEVEL_INSTRUCTIONS.get(level.value, _LEVEL_INSTRUCTIONS["A1"])


async def _generate_in_character_reply(
    *,
    scenario: LanguageConversationScenario,
    effective_level: LanguageLevel,
    recent_turns: list[LanguageSpeakingConversationTurn],
    user_text: str,
) -> str:
    system = (
        f"You are {scenario.ai_role}. The student is {scenario.student_role}.\n"
        "Speak only English. Keep responses to 2-4 sentences.\n"
        "Stay strictly in character. Never break the scenario.\n"
        "Never switch to Arabic. Never explain grammar.\n"
        f"Adaptive session level: {effective_level.value}. {_level_instruction(effective_level)}\n"
        'Return ONLY JSON: {"reply": "<your in-character reply>"}'
    )

    lines = [f"Scenario opening: {scenario.opening_line}"]
    for t in recent_turns:
        if t.user_transcript:
            lines.append(f"Student: {t.user_transcript}")
        if t.assistant_reply:
            lines.append(f"You: {t.assistant_reply}")
    lines.append(f"Student: {user_text}")
    lines.append("Reply in character as JSON now.")
    prompt = "\n".join(lines)

    raw = await generate_gemini_json(prompt, system=system, temperature=0.6, max_output_tokens=512)
    parsed = _parse_json(raw)
    reply = str(parsed.get("reply") or "").strip() if parsed else ""
    return reply or "Sorry, could you say that again, please?"


async def _persist_turn(
    db: AsyncSession,
    *,
    session: LanguageSpeakingConversationSession,
    student_id: int,
    user_text: str,
    reply: str,
    user_media_id: int | None = None,
    reply_media_id: int | None = None,
    duration_seconds: int | None = None,
    evaluation: dict | None = None,
) -> LanguageSpeakingConversationTurn:
    turn_index = int(session.turn_count or 0) + 1
    turn = LanguageSpeakingConversationTurn(
        session_id=session.id,
        student_id=student_id,
        turn_index=turn_index,
        user_transcript=user_text,
        assistant_reply=reply,
        user_media_object_id=user_media_id,
        reply_media_object_id=reply_media_id,
        duration_seconds=duration_seconds,
        evaluation_json=evaluation,
        scoring_version="scenario_v2",
    )
    db.add(turn)
    session.turn_count = turn_index
    await db.flush()
    return turn


async def process_scenario_turn(
    db: AsyncSession, *, session_id: int, student_id: int, user_text: str, language_id: int
) -> dict:
    session, scenario = await _load_scenario_session(db, session_id=session_id, student_id=student_id)
    user_text = (user_text or "").strip()
    if not user_text:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Your message is empty")

    effective = session.effective_level_at_start or await _adaptive_session_level(
        db, student_id=student_id, language_id=language_id
    )

    history_result = await db.execute(
        select(LanguageSpeakingConversationTurn)
        .where(LanguageSpeakingConversationTurn.session_id == session.id)
        .order_by(LanguageSpeakingConversationTurn.turn_index.desc())
        .limit(HISTORY_LIMIT)
    )
    recent = list(reversed(history_result.scalars().all()))
    reply = await _generate_in_character_reply(
        scenario=scenario, effective_level=effective, recent_turns=recent, user_text=user_text
    )

    turn = await _persist_turn(
        db, session=session, student_id=student_id, user_text=user_text, reply=reply
    )
    return {
        "turn_index": turn.turn_index,
        "assistant_reply": reply,
        "session_id": session.id,
        "effective_level": effective.value if isinstance(effective, LanguageLevel) else str(effective),
    }


async def process_scenario_voice_turn(
    db: AsyncSession,
    *,
    session_id: int,
    student_id: int,
    language_id: int,
    file: UploadFile,
    duration_seconds: int | None = None,
) -> dict:
    session, scenario = await _load_scenario_session(db, session_id=session_id, student_id=student_id)

    data = await file.read()
    if not data:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Audio file is empty")

    upload_file = UploadFile(
        filename=file.filename or "speech.webm",
        file=BytesIO(data),
        headers={"content-type": file.content_type or "audio/webm"},
    )
    user_media = await upload_student_speaking(
        db,
        student_id=student_id,
        subfolder="language_scenario",
        filename_hint=f"turn_{session.turn_count + 1}",
        file=upload_file,
    )

    suffix = ".webm"
    if file.filename and "." in file.filename:
        suffix = "." + file.filename.rsplit(".", 1)[-1].lower()

    stt = await transcribe_english_audio(data, suffix=suffix)
    user_text = (stt.text or "").strip()
    if not user_text:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Could not understand the audio")

    effective = session.effective_level_at_start or await _adaptive_session_level(
        db, student_id=student_id, language_id=language_id
    )

    history_result = await db.execute(
        select(LanguageSpeakingConversationTurn)
        .where(LanguageSpeakingConversationTurn.session_id == session.id)
        .order_by(LanguageSpeakingConversationTurn.turn_index.desc())
        .limit(HISTORY_LIMIT)
    )
    recent = list(reversed(history_result.scalars().all()))
    reply = await _generate_in_character_reply(
        scenario=scenario, effective_level=effective, recent_turns=recent, user_text=user_text
    )

    reply_media = None
    if settings.ENABLE_TTS and reply.strip():
        reply_media = await synthesize_english_reply(db, student_id=student_id, text=reply)

    turn = await _persist_turn(
        db,
        session=session,
        student_id=student_id,
        user_text=user_text,
        reply=reply,
        user_media_id=user_media.id,
        reply_media_id=reply_media.id if reply_media else None,
        duration_seconds=duration_seconds,
        evaluation={"stt": {"engine": stt.engine, "low_confidence": stt.low_confidence}},
    )

    reply_url = reply_media.public_url if reply_media else None
    return {
        "turn_index": turn.turn_index,
        "user_transcript": user_text,
        "assistant_reply": reply,
        "reply_audio_url": reply_url,
        "session_id": session.id,
        "effective_level": effective.value if isinstance(effective, LanguageLevel) else str(effective),
    }


def _pick_recommended_next(
    scenarios: list[LanguageConversationScenario],
    *,
    current: LanguageConversationScenario,
    student_rank: int,
    scores: dict,
) -> dict | None:
    avg = sum(float(v) for v in scores.values()) / max(len(scores), 1)
    candidates = [
        s
        for s in scenarios
        if s.id != current.id
        and s.is_active
        and CEFR_RANK[s.level_min] <= student_rank + (1 if avg >= 75 else 0)
    ]
    if not candidates:
        return None
    same_cat = [s for s in candidates if s.category == current.category]
    pool = same_cat or candidates
    nxt = min(pool, key=lambda s: (CEFR_RANK[s.level_min], s.sort_order, s.id))
    return {
        "id": nxt.id,
        "title_en": nxt.title_en,
        "title_ar": nxt.title_ar,
        "category": nxt.category,
        "level_min": nxt.level_min.value,
    }


async def end_session_with_feedback(db: AsyncSession, *, session_id: int, student_id: int) -> dict:
    session, scenario = await _load_scenario_session(db, session_id=session_id, student_id=student_id)
    language_id = session.language_id

    turns_result = await db.execute(
        select(LanguageSpeakingConversationTurn)
        .where(LanguageSpeakingConversationTurn.session_id == session.id)
        .order_by(LanguageSpeakingConversationTurn.turn_index)
    )
    turns = list(turns_result.scalars().all())

    effective = session.effective_level_at_start or LanguageLevel.A1
    fallback_scores = {"communication": 65, "grammar": 60, "vocabulary": 62, "fluency": 58}
    fallback = {
        "scores": fallback_scores,
        "what_went_well": ["You started the scenario and tried to communicate in English."],
        "what_to_improve": ["Practice speaking more turns to build fluency."],
        "overall_impression": "You completed the scenario — keep practising!",
        "strengths": ["Participated in the role-play"],
        "errors": [],
        "vocabulary_suggestions": [],
        "estimated_cefr": effective.value,
        "encouragement": "Every conversation makes you stronger — try another scenario!",
        "recommended_next_scenario": None,
    }

    feedback: dict
    if turns:
        transcript_lines = []
        for t in turns:
            if t.user_transcript:
                transcript_lines.append(f"Student: {t.user_transcript}")
            if t.assistant_reply:
                transcript_lines.append(f"{scenario.ai_role}: {t.assistant_reply}")
        transcript = "\n".join(transcript_lines)

        system = (
            "You are an English-speaking examiner reviewing a role-play conversation. "
            f"The student played {scenario.student_role} talking to {scenario.ai_role}. "
            f"Session adaptive level was {effective.value}. "
            "Judge only the student's English (the 'Student:' lines). "
            "Return ONLY JSON with this exact shape: "
            '{"scores": {"communication": 0-100, "grammar": 0-100, "vocabulary": 0-100, "fluency": 0-100}, '
            '"what_went_well": [str, str], "what_to_improve": [str, str], '
            '"overall_impression": str, "strengths": [str], '
            '"errors": [{"original": str, "corrected": str, "explanation_en": str}], '
            '"vocabulary_suggestions": [str], "estimated_cefr": "A1|A2|B1|B2|C1|C2", "encouragement": str}'
        )
        raw = await generate_gemini_json(
            f"Conversation transcript:\n{transcript}\n\nWrite the feedback JSON now.",
            system=system,
            temperature=0.4,
            max_output_tokens=2048,
        )
        parsed = _parse_json(raw) or {}
        scores = parsed.get("scores") or fallback_scores
        for key in fallback_scores:
            try:
                scores[key] = max(0, min(100, int(float(scores.get(key, fallback_scores[key])))))
            except (TypeError, ValueError):
                scores[key] = fallback_scores[key]

        student_level = await _student_speaking_level(db, student_id=student_id, language_id=language_id)
        all_scenarios = list(
            (
                await db.execute(
                    select(LanguageConversationScenario).where(
                        LanguageConversationScenario.language_id == language_id,
                        LanguageConversationScenario.is_active.is_(True),
                    )
                )
            )
            .scalars()
            .all()
        )
        recommended = _pick_recommended_next(
            all_scenarios,
            current=scenario,
            student_rank=CEFR_RANK[student_level],
            scores=scores,
        )

        feedback = {
            **fallback,
            **parsed,
            "scores": scores,
            "what_went_well": parsed.get("what_went_well") or fallback["what_went_well"],
            "what_to_improve": parsed.get("what_to_improve") or fallback["what_to_improve"],
            "recommended_next_scenario": recommended,
            "scenario": _scenario_out(scenario, False),
        }
    else:
        feedback = {**fallback, "scenario": _scenario_out(scenario, False)}

    session.summary_json = feedback
    session.status = "ended"
    session.ended_at = datetime.now(timezone.utc)
    await db.flush()

    avg_score = sum(feedback["scores"].values()) / len(feedback["scores"])
    await record_lesson_result(
        db,
        student_id=student_id,
        language_id=language_id,
        skill=LanguageSkill.speaking,
        score_percent=avg_score,
    )
    await record_activity(
        db,
        student_id=student_id,
        language_id=language_id,
        event_type="scenario_complete",
        skill=LanguageSkill.speaking,
        payload_json={"scenario_id": scenario.id, "scenario_key": scenario.scenario_key, "scores": feedback["scores"]},
    )
    return feedback


async def get_scenario_session(db: AsyncSession, *, session_id: int, student_id: int) -> dict:
    session = await db.get(LanguageSpeakingConversationSession, session_id)
    if not session or session.student_id != student_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Session not found")
    if not session.scenario_id:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="This session is not a scenario session")
    scenario = await db.get(LanguageConversationScenario, session.scenario_id)
    if not scenario:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Scenario not found")

    turns_result = await db.execute(
        select(LanguageSpeakingConversationTurn)
        .where(LanguageSpeakingConversationTurn.session_id == session.id)
        .order_by(LanguageSpeakingConversationTurn.turn_index)
    )
    turns = list(turns_result.scalars().all())

    messages: list[dict] = [{"role": "assistant", "text": scenario.opening_line, "content": scenario.opening_line}]
    for t in turns:
        if t.user_transcript:
            messages.append({"role": "user", "text": t.user_transcript, "content": t.user_transcript})
        if t.assistant_reply:
            reply_url = None
            if t.reply_media_object_id:
                media = await db.get(MediaObject, t.reply_media_object_id)
                reply_url = media.public_url if media else None
            messages.append(
                {
                    "role": "assistant",
                    "text": t.assistant_reply,
                    "content": t.assistant_reply,
                    "reply_audio_url": reply_url,
                }
            )

    return {
        "session_id": session.id,
        "status": session.status,
        "scenario": _scenario_out(scenario, False),
        "messages": messages,
        "turn_count": int(session.turn_count or 0),
        "effective_level": session.effective_level_at_start.value if session.effective_level_at_start else "A1",
        "summary": session.summary_json if session.status == "ended" else None,
    }
