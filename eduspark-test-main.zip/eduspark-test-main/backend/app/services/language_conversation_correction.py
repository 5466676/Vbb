"""Format speaking corrections for display and TTS from Gemini correction payload."""

from __future__ import annotations

NO_CORRECTION_MESSAGE = "ممتاز. لا حاجة لتصحيح."


def _brief_explanation(errors: list) -> str:
    messages: list[str] = []
    for err in errors:
        if not isinstance(err, dict):
            continue
        msg = (err.get("message") or "").strip()
        if msg and msg not in messages:
            messages.append(msg)
    if not messages:
        return "راجع القواعد والمفردات وتركيب الجملة."
    if len(messages) == 1:
        return messages[0]
    return " ".join(messages[:3])


def build_correction_display(correction: dict | None) -> dict:
    """Structured correction block for UI and spoken prefix (Gemini payload unchanged)."""
    correction = correction or {}
    original = (correction.get("original") or "").strip()
    corrected = (correction.get("corrected") or "").strip()
    errors = correction.get("errors") or []
    if not isinstance(errors, list):
        errors = []

    has_errors = bool(correction.get("has_errors"))
    if has_errors and not original and not corrected:
        has_errors = False

    if not has_errors:
        return {
            "has_errors": False,
            "no_correction_message": NO_CORRECTION_MESSAGE,
            "speech_prefix": "Excellent. No correction needed.",
        }

    explanation = _brief_explanation(errors)
    your_sentence = original or corrected
    corrected_sentence = corrected or original

    speech_prefix = (
        f"Your sentence: {your_sentence}. "
        f"Corrected sentence: {corrected_sentence}. "
        f"Explanation: {explanation}"
    )

    return {
        "has_errors": True,
        "your_sentence": your_sentence,
        "corrected_sentence": corrected_sentence,
        "explanation": explanation,
        "speech_prefix": speech_prefix,
    }


def resolve_correction_display(evaluation: dict | None) -> dict:
    """Return stored correction_display or build from legacy evaluation.correction."""
    evaluation = evaluation or {}
    stored = evaluation.get("correction_display")
    if isinstance(stored, dict) and stored:
        return stored
    return build_correction_display(evaluation.get("correction"))


def build_spoken_reply_text(*, correction_display: dict, conversation_reply: str) -> str:
    """Full XTTS script: correction first, then the conversational reply."""
    prefix = (correction_display.get("speech_prefix") or "").strip()
    reply = (conversation_reply or "").strip()
    if prefix and reply:
        return f"{prefix} {reply}"
    return prefix or reply
