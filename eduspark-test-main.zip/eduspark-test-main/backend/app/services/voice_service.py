"""Whisper transcription and teaching-style persona extraction."""

from __future__ import annotations

import asyncio
import json
import logging
import os
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

from app.core.config import get_settings
from app.services.ai_service import generate_ollama_text

logger = logging.getLogger(__name__)
settings = get_settings()

DEFAULT_PERSONA = """أنت معلم سوري ودود يشرح للطلاب باللهجة السورية المبسطة.
استخدم أمثلة من الحياة اليومية، اشرح خطوة بخطوة، وشجع الطالب.
لا تجب إلا من محتوى الدرس المرفوع. إذا السؤال خارج المحتوى قل ذلك بلطف."""

GEMINI_TRANSCRIBE_VIDEO_PROMPT = (
    "انسخ كل الكلام المنطوق في هذا الفيديو التعليمي بالعربية. "
    "أعد النص الكامل فقط دون أي تعليقات أو تنسيق إضافي."
)

_whisper_model = None
_whisper_run_patched = False
_lesson_faster_whisper_model = None
_lesson_openai_whisper_model = None

# Map openai-whisper names to multilingual faster-whisper ids (never .en for Syria).
_FASTER_WHISPER_MODEL_ALIASES: dict[str, str] = {
    "turbo": "small",
    "large": "large-v3",
    "medium": "medium",
    "small": "small",
    "base": "base",
    "tiny": "tiny",
}


@dataclass
class VideoTranscriptionResult:
    text: str
    engine: str
    model: str
    duration_s: float
    fallback_reason: str | None = None


def _find_ffmpeg_executable() -> str | None:
    ffmpeg = shutil.which("ffmpeg")
    if ffmpeg:
        return ffmpeg

    try:
        import imageio_ffmpeg

        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception as exc:
        logger.warning("FFmpeg executable not found; install imageio-ffmpeg or system ffmpeg: %s", exc)
        return None


def _patch_whisper_ffmpeg() -> bool:
    """Let openai-whisper use bundled imageio-ffmpeg on Windows when ffmpeg is not in PATH."""
    global _whisper_run_patched
    if _whisper_run_patched:
        return True

    ffmpeg = _find_ffmpeg_executable()
    if not ffmpeg:
        return False

    try:
        import whisper.audio as whisper_audio

        original_run = whisper_audio.run

        def run_with_resolved_ffmpeg(cmd, *args, **kwargs):
            if isinstance(cmd, (list, tuple)) and cmd and cmd[0] == "ffmpeg":
                cmd = [ffmpeg, *cmd[1:]]
            return original_run(cmd, *args, **kwargs)

        whisper_audio.run = run_with_resolved_ffmpeg
        _whisper_run_patched = True
        logger.info("Whisper audio decoding will use ffmpeg at %s", ffmpeg)
        return True
    except Exception as exc:
        logger.warning("Could not configure ffmpeg for Whisper: %s", exc)
        return False


def _lesson_whisper_language() -> str:
    return (settings.LESSON_VIDEO_WHISPER_LANGUAGE or "ar").strip() or "ar"


def _lesson_faster_whisper_model_id() -> str:
    override = (settings.LESSON_VIDEO_FASTER_WHISPER_MODEL or "").strip()
    if override:
        return override
    if settings.WHISPER_MODEL_PATH.strip():
        return settings.WHISPER_MODEL_PATH.strip()
    configured = (settings.WHISPER_MODEL or "turbo").strip()
    return _FASTER_WHISPER_MODEL_ALIASES.get(configured, configured)


def _get_lesson_faster_whisper_model():
    global _lesson_faster_whisper_model
    if _lesson_faster_whisper_model is not None:
        return _lesson_faster_whisper_model

    from faster_whisper import WhisperModel

    model_id = _lesson_faster_whisper_model_id()
    logger.info("Loading faster-whisper model for lesson video: %s", model_id)
    _lesson_faster_whisper_model = WhisperModel(model_id, device="cpu", compute_type="int8")
    return _lesson_faster_whisper_model


def _get_lesson_openai_whisper_model():
    global _lesson_openai_whisper_model
    if _lesson_openai_whisper_model is not None:
        return _lesson_openai_whisper_model

    _patch_whisper_ffmpeg()
    import whisper

    model_name = settings.WHISPER_MODEL or "turbo"
    logger.info("Loading openai-whisper model for lesson video: %s", model_name)
    _lesson_openai_whisper_model = whisper.load_model(model_name)
    return _lesson_openai_whisper_model


def _extract_video_to_wav(video_path: Path) -> Path:
    """Extract mono 16 kHz PCM wav from video; close handle before ffmpeg (Windows-safe)."""
    ffmpeg = _find_ffmpeg_executable()
    if not ffmpeg:
        raise RuntimeError("ffmpeg not available")

    fd, wav_name = tempfile.mkstemp(suffix=".wav")
    os.close(fd)
    wav_path = Path(wav_name)
    try:
        result = subprocess.run(
            [
                ffmpeg,
                "-y",
                "-i",
                str(video_path),
                "-ar",
                "16000",
                "-ac",
                "1",
                "-c:a",
                "pcm_s16le",
                str(wav_path),
            ],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0 or not wav_path.exists() or wav_path.stat().st_size == 0:
            raise RuntimeError(f"ffmpeg audio extract failed: {(result.stderr or result.stdout)[-400:]}")
        return wav_path
    except Exception:
        _safe_unlink(wav_path)
        raise


def _safe_unlink(path: Path) -> None:
    try:
        path.unlink(missing_ok=True)
    except OSError as exc:
        logger.warning("Could not delete temp file %s: %s", path, exc)


def _transcribe_wav_faster_whisper(wav_path: Path) -> str:
    model = _get_lesson_faster_whisper_model()
    language = _lesson_whisper_language()
    segments, _info = model.transcribe(
        str(wav_path),
        language=language,
        beam_size=5,
        vad_filter=False,
    )
    return "".join(s.text for s in segments).strip()


def _transcribe_wav_openai_whisper(wav_path: Path) -> str:
    model = _get_lesson_openai_whisper_model()
    language = _lesson_whisper_language()
    result = model.transcribe(str(wav_path), language=language, task="transcribe")
    return (result.get("text") or "").strip()


def _log_video_transcription(result: VideoTranscriptionResult, *, path: Path) -> None:
    logger.info(
        "Lesson video transcription engine=%s model=%s duration_s=%.2f chars=%s path=%s fallback_reason=%s",
        result.engine,
        result.model,
        result.duration_s,
        len(result.text),
        path.name,
        result.fallback_reason or "none",
    )


def _transcribe_lesson_video_whisper_sync(video_path: Path) -> VideoTranscriptionResult | None:
    """Try faster-whisper then openai-whisper. Returns empty result when Gemini fallback is needed."""
    started = time.perf_counter()
    wav_path: Path | None = None
    last_reason = "whisper_disabled"

    if not settings.ENABLE_WHISPER:
        return None

    try:
        wav_path = _extract_video_to_wav(video_path)

        try:
            text = _transcribe_wav_faster_whisper(wav_path)
            if text.strip():
                return VideoTranscriptionResult(
                    text=text.strip(),
                    engine="faster-whisper",
                    model=_lesson_faster_whisper_model_id(),
                    duration_s=time.perf_counter() - started,
                    fallback_reason=None,
                )
            last_reason = "faster_whisper_empty"
        except ImportError as exc:
            last_reason = f"faster_whisper_unavailable:{exc}"
            logger.warning("faster-whisper unavailable — %s", exc)
        except Exception as exc:
            last_reason = f"faster_whisper_failed:{exc}"
            logger.warning("faster-whisper lesson video transcription failed: %s", exc)

        try:
            text = _transcribe_wav_openai_whisper(wav_path)
            if text.strip():
                return VideoTranscriptionResult(
                    text=text.strip(),
                    engine="openai-whisper",
                    model=settings.WHISPER_MODEL or "turbo",
                    duration_s=time.perf_counter() - started,
                    fallback_reason=last_reason,
                )
            last_reason = "openai_whisper_empty"
        except Exception as exc:
            last_reason = f"openai_whisper_failed:{exc}"
            logger.warning("openai-whisper lesson video transcription failed: %s", exc)

        return VideoTranscriptionResult(
            text="",
            engine="none",
            model="",
            duration_s=time.perf_counter() - started,
            fallback_reason=last_reason,
        )
    finally:
        if wav_path is not None:
            _safe_unlink(wav_path)


async def transcribe_lesson_video(video_path: str | Path) -> str:
    """Transcribe lesson video — ffmpeg WAV → faster-whisper → openai-whisper → Gemini."""
    path = Path(video_path)
    if not path.exists():
        return ""

    started = time.perf_counter()
    whisper_result = await asyncio.to_thread(_transcribe_lesson_video_whisper_sync, path)

    if whisper_result and whisper_result.text.strip():
        _log_video_transcription(whisper_result, path=path)
        return whisper_result.text

    fallback_reason = whisper_result.fallback_reason if whisper_result else "whisper_disabled"
    timeout_s = int(settings.LESSON_VIDEO_GEMINI_TIMEOUT_SECONDS or 600)
    if settings.GEMINI_API_KEY:
        try:
            text = await _transcribe_video_with_gemini(path, timeout_s=timeout_s)
            if text.strip():
                result = VideoTranscriptionResult(
                    text=text.strip(),
                    engine="gemini",
                    model=settings.GEMINI_MODEL,
                    duration_s=time.perf_counter() - started,
                    fallback_reason=fallback_reason,
                )
                _log_video_transcription(result, path=path)
                return result.text
            fallback_reason = f"{fallback_reason};gemini_empty"
        except Exception as exc:
            fallback_reason = f"{fallback_reason};gemini_failed:{exc}"
            logger.warning("Gemini lesson video transcription failed: %s", exc)
    else:
        fallback_reason = f"{fallback_reason};gemini_unconfigured"

    result = VideoTranscriptionResult(
        text="",
        engine="none",
        model="",
        duration_s=time.perf_counter() - started,
        fallback_reason=fallback_reason,
    )
    _log_video_transcription(result, path=path)
    return ""


async def _transcribe_video_with_gemini(path: Path, *, timeout_s: int) -> str:
    import google.generativeai as genai

    genai.configure(api_key=settings.GEMINI_API_KEY)
    uploaded = await asyncio.to_thread(genai.upload_file, str(path))
    for _ in range(60):
        file_info = await asyncio.to_thread(genai.get_file, uploaded.name)
        state = getattr(file_info, "state", None)
        state_name = getattr(state, "name", str(state))
        if state_name == "ACTIVE":
            uploaded = file_info
            break
        if state_name == "FAILED":
            raise RuntimeError(f"Gemini file processing failed: {uploaded.name}")
        await asyncio.sleep(1)
    else:
        raise RuntimeError(f"Gemini file not ACTIVE after wait: {uploaded.name}")

    model = genai.GenerativeModel(settings.GEMINI_MODEL)
    response = await asyncio.to_thread(
        model.generate_content,
        [GEMINI_TRANSCRIBE_VIDEO_PROMPT, uploaded],
        request_options={"timeout": timeout_s},
    )
    return (response.text or "").strip()


def _get_whisper_model():
    global _whisper_model
    if _whisper_model is not None:
        return _whisper_model

    if settings.WHISPER_MODEL_PATH:
        from faster_whisper import WhisperModel

        logger.info("Loading faster-whisper model from: %s", settings.WHISPER_MODEL_PATH)
        _whisper_model = WhisperModel(settings.WHISPER_MODEL_PATH, device="cpu", compute_type="int8")
        return _whisper_model

    import whisper

    logger.info("Loading Whisper model: %s", settings.WHISPER_MODEL)
    _whisper_model = whisper.load_model(settings.WHISPER_MODEL)
    return _whisper_model


async def transcribe_audio(audio_path: str | Path) -> str:
    path = Path(audio_path)
    if not path.exists():
        return ""

    if settings.ENABLE_WHISPER:
        try:
            return await asyncio.to_thread(_transcribe_with_whisper_sync, path)
        except Exception as exc:
            logger.warning("Whisper transcription failed: %s", exc)

    if settings.GEMINI_API_KEY:
        try:
            import google.generativeai as genai

            genai.configure(api_key=settings.GEMINI_API_KEY)
            uploaded = await asyncio.to_thread(genai.upload_file, path)
            model = genai.GenerativeModel(settings.GEMINI_MODEL)
            response = await asyncio.to_thread(
                model.generate_content,
                [
                    "انسخ هذا التسجيل الصوتي بالعربية. أعد النص فقط بدون تعليقات.",
                    uploaded,
                ],
                request_options={"timeout": 60},
            )
            return (response.text or "").strip()
        except Exception as exc:
            logger.warning("Gemini transcription failed: %s", exc)

    return ""


def _transcribe_with_whisper_sync(path: Path) -> str:
    if settings.WHISPER_MODEL_PATH:
        model = _get_whisper_model()
        segments, _info = model.transcribe(str(path), language="ar")
        return "".join(segment.text for segment in segments).strip()

    _patch_whisper_ffmpeg()
    model = _get_whisper_model()
    result = model.transcribe(str(path), language="ar", task="transcribe")
    return (result.get("text") or "").strip()


async def build_persona_prompt(transcript: str, subject: str, grade: str) -> str:
    if transcript and settings.LLM_PROVIDER.lower() == "ollama":
        try:
            prompt = f"""Analyze this teacher transcript and write a concise persona prompt in Arabic.
The persona should guide an AI tutor to explain in the same friendly Syrian Arabic style.
Return JSON only:
{{"persona": "..."}}

Subject: {subject}
Grade: {grade}

Teacher transcript:
{transcript[:3000]}
"""
            text = await generate_ollama_text(prompt, temperature=0.1)
            if "{" in text and "}" in text:
                data = json.loads(text[text.index("{") : text.rindex("}") + 1])
                persona = data.get("persona")
                if persona:
                    return persona
        except Exception as exc:
            logger.warning("Ollama persona generation failed: %s", exc)

    if settings.GEMINI_API_KEY and transcript:
        try:
            import google.generativeai as genai

            genai.configure(api_key=settings.GEMINI_API_KEY)
            model = genai.GenerativeModel(settings.GEMINI_MODEL)
            prompt = f"""حلل أسلوب هذا المعلم من النص الصوتي واكتب Persona Prompt بالعربية لتوجيه ذكاء اصطناعي
للشرح بنفس الأسلوب واللهجة السورية. المادة: {subject}، الصف: {grade}.

نص المعلم:
{transcript[:3000]}

أعد JSON فقط بالشكل:
{{"persona": "..."}}"""
            response = await asyncio.to_thread(
                model.generate_content,
                prompt,
                request_options={"timeout": 20},
            )
            text = (response.text or "").strip()
            if "{" in text:
                data = json.loads(text[text.index("{") : text.rindex("}") + 1])
                return data.get("persona", DEFAULT_PERSONA)
        except Exception as exc:
            logger.warning("Persona generation failed: %s", exc)

    style_hint = f"\n\nالمادة: {subject}، الصف: {grade}."
    if transcript:
        style_hint += f"\nاستفد من عينة صوت المعلم هذه: {transcript[:500]}"
    return f"{DEFAULT_PERSONA}{style_hint}"
