from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path

from fastapi import HTTPException, UploadFile, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.models.language.analytics import LanguageAnalytics
from app.models.language.assessment import LanguageAssessment, LanguageAssessmentSkillScore
from app.models.language.enums import (
    LanguageLevel,
    LanguageOnboardingStep,
    LanguagePlacementAttemptStatus,
    LanguageSkill,
)
from app.models.language.placement import (
    LanguagePlacementAttempt,
    LanguagePlacementQuestion,
    LanguagePlacementResponse,
    LanguagePlacementSection,
)
from app.models.language.profile import LanguageStudentProfile
from app.models.media import MediaObject, StorageProvider
from app.services.language_learning_path_service import generate_learning_path
from app.services.language_placement_ai_scoring import score_speaking_ai, score_writing_ai
from app.services.language_placement_scoring_service import (
    bottleneck_overall,
    percent_to_level,
    score_mcq,
    score_speaking,
    score_writing,
)
from app.services.language_validation import validate_speaking_duration, validate_writing_submission
from app.services.language_subscription_service import get_default_language
from app.services.media_storage_service import register_media_object
from app.services.voice_validation_service import _duration_via_ffprobe

settings = get_settings()


def _probe_media_duration_seconds(storage_key: str | None) -> int | None:
    if not storage_key:
        return None
    path = Path(settings.UPLOAD_DIR) / storage_key
    if not path.is_file():
        return None
    probed = _duration_via_ffprobe(path)
    if probed is None or probed < 1:
        return None
    return int(round(probed))


async def _backfill_speaking_durations(
    db: AsyncSession,
    *,
    questions: list[LanguagePlacementQuestion],
    responses: list[LanguagePlacementResponse],
) -> None:
    q_by_id = {int(q.id): q for q in questions}
    for row in responses:
        q = q_by_id.get(int(row.question_id))
        if not q or q.question_type != "speaking":
            continue
        resp = dict(row.response_json or {})
        if resp.get("duration_seconds") is not None:
            continue
        media_id = resp.get("media_object_id")
        if not media_id:
            continue
        media = await db.get(MediaObject, int(media_id))
        if not media:
            continue
        probed = _probe_media_duration_seconds(media.storage_key)
        if probed is None:
            continue
        resp["duration_seconds"] = probed
        row.response_json = resp
    await db.flush()


async def _ensure_profile(db: AsyncSession, *, student_id: int, language_id: int) -> LanguageStudentProfile:
    result = await db.execute(
        select(LanguageStudentProfile).where(
            LanguageStudentProfile.student_id == student_id,
            LanguageStudentProfile.language_id == language_id,
        )
    )
    profile = result.scalar_one_or_none()
    if profile:
        return profile
    profile = LanguageStudentProfile(
        student_id=student_id,
        language_id=language_id,
        onboarding_step=LanguageOnboardingStep.placement,
        selected_at=datetime.now(timezone.utc),
    )
    db.add(profile)
    await db.flush()
    return profile


async def start_or_resume_attempt(db: AsyncSession, *, student_id: int) -> tuple[int, int]:
    language = await get_default_language(db)
    profile = await _ensure_profile(db, student_id=student_id, language_id=language.id)
    if profile.placement_completed_at:
        now = datetime.now(timezone.utc)
        allow_at = profile.next_allowed_retake_date
        if allow_at and allow_at.tzinfo is None:
            allow_at = allow_at.replace(tzinfo=timezone.utc)
        # Retake enforcement: block until next_allowed_retake_date (90 days after completion)
        if allow_at and allow_at > now:
            raise HTTPException(
                status_code=409,
                detail={
                    "code": "placement_retake_blocked",
                    "message": "لا يمكنك إعادة الاختبار الآن",
                    "next_allowed_retake_date": allow_at.isoformat(),
                },
            )
        # Past or missing allow_at: allow a retake attempt.

    existing = await db.execute(
        select(LanguagePlacementAttempt)
        .where(
            LanguagePlacementAttempt.student_id == student_id,
            LanguagePlacementAttempt.language_id == language.id,
            LanguagePlacementAttempt.status == LanguagePlacementAttemptStatus.in_progress,
        )
        .order_by(LanguagePlacementAttempt.started_at.desc())
        .limit(1)
    )
    attempt = existing.scalar_one_or_none()
    if attempt:
        return attempt.id, language.id

    attempt = LanguagePlacementAttempt(
        student_id=student_id,
        language_id=language.id,
        is_retake=bool(profile.placement_completed_at),
    )
    db.add(attempt)
    await db.flush()
    return attempt.id, language.id


async def get_bank_with_responses(
    db: AsyncSession, *, student_id: int, attempt_id: int
) -> tuple[list[LanguagePlacementSection], list[LanguagePlacementQuestion], dict[int, dict]]:
    attempt = await db.get(LanguagePlacementAttempt, attempt_id)
    if not attempt or attempt.student_id != student_id:
        raise HTTPException(status_code=404, detail="محاولة غير موجودة")

    sections_res = await db.execute(
        select(LanguagePlacementSection)
        .where(LanguagePlacementSection.language_id == attempt.language_id)
        .order_by(LanguagePlacementSection.sort_order)
    )
    sections = sections_res.scalars().all()
    qres = await db.execute(
        select(LanguagePlacementQuestion)
        .join(LanguagePlacementSection, LanguagePlacementSection.id == LanguagePlacementQuestion.section_id)
        .where(LanguagePlacementSection.language_id == attempt.language_id)
        .order_by(LanguagePlacementSection.sort_order, LanguagePlacementQuestion.sort_order, LanguagePlacementQuestion.id)
    )
    questions = qres.scalars().all()
    rres = await db.execute(
        select(LanguagePlacementResponse).where(LanguagePlacementResponse.attempt_id == attempt_id)
    )
    responses = rres.scalars().all()
    await _backfill_speaking_durations(db, questions=questions, responses=responses)
    by_qid: dict[int, dict] = {}
    for r in responses:
        by_qid[int(r.question_id)] = r.response_json or {}
    return sections, questions, by_qid


async def save_response(
    db: AsyncSession,
    *,
    student_id: int,
    attempt_id: int,
    question_id: int,
    response_json: dict,
) -> None:
    attempt = await db.get(LanguagePlacementAttempt, attempt_id)
    if not attempt or attempt.student_id != student_id:
        raise HTTPException(status_code=404, detail="محاولة غير موجودة")
    if attempt.status != LanguagePlacementAttemptStatus.in_progress:
        raise HTTPException(status_code=409, detail="هذه المحاولة ليست قيد التقدم")

    question = await db.get(LanguagePlacementQuestion, question_id)
    if not question:
        raise HTTPException(status_code=404, detail="سؤال غير موجود")

    existing = await db.execute(
        select(LanguagePlacementResponse).where(
            LanguagePlacementResponse.attempt_id == attempt_id,
            LanguagePlacementResponse.question_id == question_id,
        )
    )
    row = existing.scalar_one_or_none()
    if row:
        row.response_json = response_json
    else:
        db.add(
            LanguagePlacementResponse(
                attempt_id=attempt_id,
                question_id=question_id,
                response_json=response_json,
            )
        )
    await db.flush()


async def upload_speaking_audio(
    db: AsyncSession,
    *,
    student_id: int,
    attempt_id: int,
    question_id: int,
    file: UploadFile,
    duration_seconds: int | None = None,
) -> tuple[MediaObject, int | None]:
    # Store to disk under student_* to reuse existing uploads mount.
    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="الملف الصوتي فارغ")
    ext = Path(file.filename or "speech.webm").suffix or ".webm"
    upload_dir = Path(settings.UPLOAD_DIR) / f"student_{student_id}" / "language_placement"
    upload_dir.mkdir(parents=True, exist_ok=True)
    dest = upload_dir / f"speaking_q{question_id}_{attempt_id}{ext}"
    dest.write_bytes(data)

    rel = dest.resolve().relative_to(Path(settings.UPLOAD_DIR).resolve())
    public_url = "/uploads/" + "/".join(rel.parts)
    storage_key = "/".join(rel.parts)

    media = await register_media_object(
        db,
        storage_path="uploads/" + storage_key,
        mime_type=file.content_type or "audio/webm",
        file_size_bytes=len(data),
        original_filename=file.filename or "speech.webm",
        uploaded_by_user_id=student_id,
        storage_provider=StorageProvider.local.value,
        storage_key=storage_key,
    )

    # Persist response_json with media_object_id (+ duration for scoring).
    response_json: dict = {"media_object_id": media.id}
    if duration_seconds is not None:
        response_json["duration_seconds"] = int(duration_seconds)
    else:
        probed = _probe_media_duration_seconds(storage_key)
        if probed is not None:
            response_json["duration_seconds"] = probed
    await save_response(
        db,
        student_id=student_id,
        attempt_id=attempt_id,
        question_id=question_id,
        response_json=response_json,
    )
    # Caller can use media.public_url for immediate playback; we keep only the id in placement response.
    media.public_url = public_url
    return media, response_json.get("duration_seconds")


async def submit_attempt(db: AsyncSession, *, student_id: int, attempt_id: int) -> tuple[LanguageAssessment, int | None]:
    attempt = await db.get(LanguagePlacementAttempt, attempt_id)
    if not attempt or attempt.student_id != student_id:
        raise HTTPException(status_code=404, detail="محاولة غير موجودة")
    if attempt.status != LanguagePlacementAttemptStatus.in_progress:
        raise HTTPException(status_code=409, detail="هذه المحاولة ليست قيد التقدم")

    profile = await _ensure_profile(db, student_id=student_id, language_id=attempt.language_id)

    # Load questions/responses with section joins to determine skill.
    qres = await db.execute(
        select(LanguagePlacementQuestion, LanguagePlacementSection)
        .join(LanguagePlacementSection, LanguagePlacementSection.id == LanguagePlacementQuestion.section_id)
        .where(LanguagePlacementSection.language_id == attempt.language_id)
        .order_by(LanguagePlacementSection.sort_order, LanguagePlacementQuestion.sort_order, LanguagePlacementQuestion.id)
    )
    qrows = qres.all()
    rres = await db.execute(select(LanguagePlacementResponse).where(LanguagePlacementResponse.attempt_id == attempt_id))
    responses = {int(r.question_id): r for r in rres.scalars().all()}

    points_by_skill: dict[LanguageSkill, float] = {s: 0.0 for s in LanguageSkill}
    max_by_skill: dict[LanguageSkill, float] = {s: 0.0 for s in LanguageSkill}
    metrics_by_skill: dict[LanguageSkill, dict] = {s: {} for s in LanguageSkill}

    for q, sec in qrows:
        skill: LanguageSkill = sec.skill
        max_by_skill[skill] += float(q.max_points or 1)
        resp = responses.get(int(q.id))
        resp_json = resp.response_json if resp else {}

        if q.question_type in ("mcq", "mcq_listening"):
            pts = score_mcq(resp_json, q.answer_key_json, max_points=q.max_points or 1)
            points_by_skill[skill] += float(pts)
        elif q.question_type == "writing":
            min_words = int((q.prompt_json or {}).get("min_words") or 20)
            min_sentences = int((q.prompt_json or {}).get("min_sentences") or 0)
            text = str(resp_json.get("text") or resp_json.get("answer") or "").strip()
            if not text:
                raise HTTPException(status_code=400, detail="أكمل سؤال الكتابة قبل إرسال الاختبار")
            validate_writing_submission(text, min_words=min_words, min_sentences=min_sentences)
            prompt_text = (q.prompt_json or {}).get("prompt") or (q.prompt_json or {}).get("instructions") or ""
            ai_writing = await score_writing_ai(text=text, prompt=prompt_text)
            pct, m = ai_writing if ai_writing else score_writing(resp_json, min_words=min_words)
            points_by_skill[skill] += (pct / 100.0) * float(q.max_points or 10)
            metrics_by_skill[skill].setdefault("writing_tasks", []).append(m)
        elif q.question_type == "speaking":
            min_seconds = int((q.prompt_json or {}).get("min_seconds") or 20)
            if not resp_json.get("media_object_id"):
                raise HTTPException(status_code=400, detail="أكمل سؤال التحدث قبل إرسال الاختبار")
            if resp_json.get("duration_seconds") is None:
                media = await db.get(MediaObject, int(resp_json["media_object_id"]))
                if media:
                    probed = _probe_media_duration_seconds(media.storage_key)
                    if probed is not None:
                        resp_json = {**resp_json, "duration_seconds": probed}
            duration = validate_speaking_duration(
                resp_json.get("duration_seconds"),
                min_seconds=min_seconds,
            )
            resp_json = {**resp_json, "duration_seconds": duration}
            ai_speaking = None
            media = await db.get(MediaObject, int(resp_json["media_object_id"]))
            if media:
                try:
                    audio_bytes = (Path(settings.UPLOAD_DIR) / media.storage_key).read_bytes()
                    ai_speaking = await score_speaking_ai(
                        audio_data=audio_bytes,
                        suffix=Path(media.storage_key).suffix or ".webm",
                        prompt=(q.prompt_json or {}).get("prompt") or "",
                    )
                except Exception:
                    ai_speaking = None
            pct, m = ai_speaking if ai_speaking else score_speaking(resp_json, min_seconds=min_seconds)
            points_by_skill[skill] += (pct / 100.0) * float(q.max_points or 10)
            metrics_by_skill[skill].setdefault("speaking_tasks", []).append(m)

    # Create assessment + skill scores
    assessment = LanguageAssessment(
        student_id=student_id,
        language_id=attempt.language_id,
        attempt_id=attempt.id,
    )
    db.add(assessment)
    await db.flush()

    skill_levels: dict[LanguageSkill, LanguageLevel] = {}
    for skill in LanguageSkill:
        max_pts = max_by_skill.get(skill) or 0.0
        score_pct = round((points_by_skill.get(skill) or 0.0) / max_pts * 100.0, 2) if max_pts else 0.0
        level = percent_to_level(score_pct)
        skill_levels[skill] = level
        db.add(
            LanguageAssessmentSkillScore(
                assessment_id=assessment.id,
                skill=skill,
                score_percent=score_pct,
                level=level,
                raw_metrics_json=metrics_by_skill.get(skill) or None,
                ai_evaluation_json=None,
            )
        )

    overall = bottleneck_overall(skill_levels)
    assessment.overall_level = overall
    assessment.overall_calculation_method = "bottleneck"

    # Mark attempt/profile complete
    attempt.status = LanguagePlacementAttemptStatus.submitted
    attempt.submitted_at = datetime.now(timezone.utc)
    profile.placement_completed_at = datetime.now(timezone.utc)
    profile.last_assessment_date = profile.placement_completed_at
    profile.next_allowed_retake_date = profile.placement_completed_at + timedelta(days=90)
    profile.onboarding_step = LanguageOnboardingStep.dashboard

    # Update analytics for quick access payload
    analytics = await db.get(LanguageAnalytics, {"student_id": student_id, "language_id": attempt.language_id})
    if not analytics:
        analytics = LanguageAnalytics(student_id=student_id, language_id=attempt.language_id)
        db.add(analytics)
        await db.flush()
    analytics.reading_level = skill_levels[LanguageSkill.reading]
    analytics.listening_level = skill_levels[LanguageSkill.listening]
    analytics.writing_level = skill_levels[LanguageSkill.writing]
    analytics.speaking_level = skill_levels[LanguageSkill.speaking]
    analytics.overall_level_internal = overall

    # Generate weighted learning path
    path = await generate_learning_path(
        db,
        student_id=student_id,
        language_id=attempt.language_id,
        assessment_id=assessment.id,
        overall_level=overall,
        skill_levels=skill_levels,
    )
    await db.flush()

    return assessment, path.id

