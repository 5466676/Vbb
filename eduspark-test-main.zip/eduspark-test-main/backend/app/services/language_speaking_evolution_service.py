"""Long-term speaking level evolution from placement + conversation turns."""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import desc, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.models.language.analytics import LanguageAnalytics
from app.models.language.assessment import LanguageAssessment, LanguageAssessmentSkillScore
from app.models.language.conversation import LanguageSpeakingConversationSession, LanguageSpeakingConversationTurn
from app.models.language.enums import LanguageLevel, LanguageSkill
from app.services.language_level_utils import CEFR_RANK, RANK_CEFR, bottleneck_level, primary_focus_and_strength
from app.services.language_subscription_service import get_default_language

settings = get_settings()


def _parse_level(value: str | LanguageLevel | None) -> LanguageLevel | None:
    if value is None:
        return None
    if isinstance(value, LanguageLevel):
        return value
    try:
        return LanguageLevel(value.upper())
    except ValueError:
        return None


async def _placement_speaking_level(db: AsyncSession, *, student_id: int, language_id: int) -> LanguageLevel | None:
    result = await db.execute(
        select(LanguageAssessmentSkillScore.level)
        .join(LanguageAssessment, LanguageAssessment.id == LanguageAssessmentSkillScore.assessment_id)
        .where(
            LanguageAssessment.student_id == student_id,
            LanguageAssessment.language_id == language_id,
            LanguageAssessmentSkillScore.skill == LanguageSkill.speaking,
        )
        .order_by(desc(LanguageAssessment.completed_at))
        .limit(1)
    )
    row = result.scalar_one_or_none()
    return _parse_level(row)


async def _rolling_turn_levels(
    db: AsyncSession,
    *,
    student_id: int,
    window: int,
) -> list[int]:
    result = await db.execute(
        select(LanguageSpeakingConversationTurn.estimated_cefr)
        .where(LanguageSpeakingConversationTurn.student_id == student_id)
        .order_by(desc(LanguageSpeakingConversationTurn.created_at))
        .limit(window)
    )
    ranks = []
    for lv in result.scalars().all():
        parsed = _parse_level(lv)
        if parsed:
            ranks.append(CEFR_RANK[parsed])
    return ranks


def _weighted_median_rank(ranks: list[int]) -> int | None:
    if not ranks:
        return None
    return sorted(ranks)[len(ranks) // 2]


def _blend_level(
    *,
    placement: LanguageLevel | None,
    rolling_rank: int | None,
    current: LanguageLevel | None,
    turn_count: int,
) -> LanguageLevel | None:
    if rolling_rank is None and placement is None:
        return current
    if rolling_rank is None:
        return placement
    if placement is None:
        return RANK_CEFR.get(rolling_rank)

    placement_rank = CEFR_RANK[placement]
    # Weight conversation more as turn count grows (max 70% conversation weight)
    conv_weight = min(0.7, turn_count / max(turn_count + 10, 1))
    blended = round(placement_rank * (1 - conv_weight) + rolling_rank * conv_weight)
    blended = max(1, min(6, blended))

    # Cap movement to ±1 from current effective level per update when current exists
    if current:
        cur_rank = CEFR_RANK[current]
        if blended > cur_rank + 1:
            blended = cur_rank + 1
        elif blended < cur_rank - 1:
            blended = cur_rank - 1

    return RANK_CEFR.get(blended)


async def update_speaking_level_from_conversation(
    db: AsyncSession,
    *,
    student_id: int,
    language_id: int,
) -> tuple[LanguageLevel | None, bool]:
    """Recompute speaking_level; returns (new_level, changed)."""
    analytics = await db.get(LanguageAnalytics, {"student_id": student_id, "language_id": language_id})
    if not analytics:
        analytics = LanguageAnalytics(student_id=student_id, language_id=language_id)
        db.add(analytics)
        await db.flush()

    turn_count_q = await db.execute(
        select(func.count())
        .select_from(LanguageSpeakingConversationTurn)
        .where(LanguageSpeakingConversationTurn.student_id == student_id)
    )
    turn_count = int(turn_count_q.scalar() or 0)

    placement = await _placement_speaking_level(db, student_id=student_id, language_id=language_id)
    rolling = await _rolling_turn_levels(
        db,
        student_id=student_id,
        window=settings.LANGUAGE_CONVERSATION_LEVEL_WINDOW,
    )
    rolling_rank = _weighted_median_rank(rolling)
    previous = analytics.speaking_level
    new_level = _blend_level(
        placement=placement,
        rolling_rank=rolling_rank,
        current=previous,
        turn_count=turn_count,
    )
    changed = new_level != previous
    if new_level:
        analytics.speaking_level = new_level

    growth = dict(analytics.skill_growth_json or {})
    speaking_growth = dict(growth.get("speaking") or {})

    recent = await db.execute(
        select(LanguageSpeakingConversationTurn.evaluation_json)
        .where(LanguageSpeakingConversationTurn.student_id == student_id)
        .order_by(desc(LanguageSpeakingConversationTurn.created_at))
        .limit(settings.LANGUAGE_CONVERSATION_LEVEL_WINDOW)
    )
    score_sums = {"fluency": 0, "grammar": 0, "vocabulary": 0, "confidence": 0}
    score_n = 0
    for ev in recent.scalars().all():
        if not ev:
            continue
        scores = ev.get("scores") or {}
        if not scores:
            continue
        score_n += 1
        for k in score_sums:
            score_sums[k] += int(scores.get(k) or 0)
    avg_scores = {k: round(v / score_n) if score_n else 0 for k, v in score_sums.items()}

    speaking_growth["conversation"] = {
        "turns_total": turn_count,
        "average_scores": avg_scores,
        "effective_level": new_level.value if new_level else None,
        "placement_baseline": placement.value if placement else None,
        "level_trend": "up" if changed and new_level and previous and CEFR_RANK[new_level] > CEFR_RANK[previous] else (
            "down" if changed and new_level and previous and CEFR_RANK[new_level] < CEFR_RANK[previous] else "stable"
        ),
    }
    growth["speaking"] = speaking_growth
    analytics.skill_growth_json = growth

    levels = {
        "reading": analytics.reading_level.value if analytics.reading_level else None,
        "listening": analytics.listening_level.value if analytics.listening_level else None,
        "writing": analytics.writing_level.value if analytics.writing_level else None,
        "speaking": analytics.speaking_level.value if analytics.speaking_level else None,
    }
    overall = bottleneck_level(levels)
    if overall:
        analytics.overall_level_internal = overall
    focus, strength = primary_focus_and_strength(levels)
    analytics.primary_focus_skill = focus
    analytics.strength_skill = strength
    await db.flush()
    return new_level, changed


async def build_conversation_progress(
    db: AsyncSession,
    *,
    student_id: int,
    language_id: int | None = None,
) -> dict:
    language = await get_default_language(db) if language_id is None else None
    lang_id = language_id or language.id
    analytics = await db.get(LanguageAnalytics, {"student_id": student_id, "language_id": lang_id})

    placement = await _placement_speaking_level(db, student_id=student_id, language_id=lang_id)
    turn_count_q = await db.execute(
        select(func.count())
        .select_from(LanguageSpeakingConversationTurn)
        .where(LanguageSpeakingConversationTurn.student_id == student_id)
    )
    sessions_q = await db.execute(
        select(func.count())
        .select_from(LanguageSpeakingConversationSession)
        .where(
            LanguageSpeakingConversationSession.student_id == student_id,
            LanguageSpeakingConversationSession.language_id == lang_id,
            LanguageSpeakingConversationSession.status == "completed",
        )
    )
    last_q = await db.execute(
        select(LanguageSpeakingConversationTurn.created_at)
        .where(LanguageSpeakingConversationTurn.student_id == student_id)
        .order_by(desc(LanguageSpeakingConversationTurn.created_at))
        .limit(1)
    )

    conv_meta = {}
    if analytics and analytics.skill_growth_json:
        conv_meta = (analytics.skill_growth_json.get("speaking") or {}).get("conversation") or {}

    return {
        "effective_speaking_level": analytics.speaking_level.value if analytics and analytics.speaking_level else None,
        "placement_baseline_level": placement.value if placement else None,
        "conversation_turns_total": int(turn_count_q.scalar() or 0),
        "sessions_completed": int(sessions_q.scalar() or 0),
        "average_scores": conv_meta.get("average_scores") or {
            "fluency": 0,
            "grammar": 0,
            "vocabulary": 0,
            "confidence": 0,
        },
        "level_trend": conv_meta.get("level_trend"),
        "last_conversation_at": last_q.scalar_one_or_none(),
    }
