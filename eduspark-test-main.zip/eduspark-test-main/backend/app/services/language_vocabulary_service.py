"""Vocabulary flashcards — review and progress."""

from __future__ import annotations

from datetime import datetime, timezone

from fastapi import HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.language.content import LanguageContentItem
from app.models.language.enums import LanguageSkill, LanguageVocabularyStatus
from app.models.language.progress import LanguageVocabularyProgress
from app.services.language_analytics_service import refresh_language_analytics
from app.services.language_content_service import get_content_item, list_content_items, normalize_word
from app.services.language_curriculum_service import credit_feature_objectives
from app.services.language_engagement_service import record_activity
from app.services.language_subscription_service import get_default_language

CONTENT_TYPE = "vocabulary"


async def _progress_by_lemma(
    db: AsyncSession, *, student_id: int, language_id: int, lemmas: list[str]
) -> dict[str, LanguageVocabularyProgress]:
    if not lemmas:
        return {}
    result = await db.execute(
        select(LanguageVocabularyProgress).where(
            LanguageVocabularyProgress.student_id == student_id,
            LanguageVocabularyProgress.language_id == language_id,
            LanguageVocabularyProgress.lemma.in_(lemmas),
        )
    )
    return {p.lemma: p for p in result.scalars().all()}


async def _get_or_create_progress(
    db: AsyncSession,
    *,
    student_id: int,
    language_id: int,
    lemma: str,
) -> LanguageVocabularyProgress:
    result = await db.execute(
        select(LanguageVocabularyProgress).where(
            LanguageVocabularyProgress.student_id == student_id,
            LanguageVocabularyProgress.language_id == language_id,
            LanguageVocabularyProgress.lemma == lemma,
        )
    )
    row = result.scalar_one_or_none()
    if row:
        return row
    row = LanguageVocabularyProgress(
        student_id=student_id,
        language_id=language_id,
        lemma=lemma,
        status=LanguageVocabularyStatus.new,
        review_count=0,
        mastery_score=0.0,
    )
    db.add(row)
    await db.flush()
    return row


async def vocabulary_metrics(
    db: AsyncSession,
    *,
    student_id: int,
    language_id: int,
    content_ids: list[int],
) -> dict:
    total_words = len(content_ids)
    if total_words == 0:
        return {"total_words": 0, "known_words": 0, "learning_words": 0, "new_words": 0}
    items = await db.execute(select(LanguageContentItem).where(LanguageContentItem.id.in_(content_ids)))
    lemmas = []
    for item in items.scalars().all():
        body = item.body_json or {}
        w = normalize_word(body.get("word") or "")
        if w:
            lemmas.append(w)
    prog_map = await _progress_by_lemma(db, student_id=student_id, language_id=language_id, lemmas=lemmas)
    known = learning = new = 0
    for lemma in lemmas:
        p = prog_map.get(lemma)
        if not p or p.status == LanguageVocabularyStatus.new:
            new += 1
        elif p.status == LanguageVocabularyStatus.known:
            known += 1
        elif p.status == LanguageVocabularyStatus.learning:
            learning += 1
    return {
        "total_words": total_words,
        "known_words": known,
        "learning_words": learning,
        "new_words": new,
    }


def _card_out(item: LanguageContentItem, progress: LanguageVocabularyProgress | None) -> dict:
    body = item.body_json or {}
    word = body.get("word") or ""
    st = progress.status.value if progress else LanguageVocabularyStatus.new.value
    return {
        "id": item.id,
        "word": word,
        "translation_ar": body.get("translation_ar"),
        "example": body.get("example"),
        "example_ar": body.get("example_ar"),
        "level": item.level.value if item.level else None,
        "status": st,
        "review_count": int(progress.review_count if progress else 0),
        "last_reviewed_at": progress.last_reviewed_at if progress else None,
    }


async def list_vocabulary(db: AsyncSession, *, student_id: int) -> dict:
    language = await get_default_language(db)
    student_level, lesson_level, items = await list_content_items(
        db,
        student_id=student_id,
        content_type=CONTENT_TYPE,
        skill=None,
        level_skill=LanguageSkill.reading,
    )
    lemmas = [normalize_word((i.body_json or {}).get("word") or "") for i in items]
    lemmas = [l for l in lemmas if l]
    prog_map = await _progress_by_lemma(db, student_id=student_id, language_id=language.id, lemmas=lemmas)
    cards = []
    for item in items:
        lemma = normalize_word((item.body_json or {}).get("word") or "")
        cards.append(_card_out(item, prog_map.get(lemma)))
    metrics = await vocabulary_metrics(
        db,
        student_id=student_id,
        language_id=language.id,
        content_ids=[i.id for i in items],
    )
    return {
        "student_level": student_level.value,
        "lesson_level": lesson_level.value if lesson_level else None,
        "metrics": metrics,
        "cards": cards,
    }


async def get_vocabulary_card(db: AsyncSession, *, student_id: int, content_id: int) -> dict:
    language = await get_default_language(db)
    item = await get_content_item(
        db,
        student_id=student_id,
        content_id=content_id,
        content_type=CONTENT_TYPE,
        skill=None,
        level_skill=LanguageSkill.reading,
    )
    if not item:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="البطاقة غير موجودة")
    lemma = normalize_word((item.body_json or {}).get("word") or "")
    prog_map = await _progress_by_lemma(db, student_id=student_id, language_id=language.id, lemmas=[lemma])
    return _card_out(item, prog_map.get(lemma))


async def review_vocabulary(
    db: AsyncSession,
    *,
    student_id: int,
    content_id: int,
    action: str,
) -> dict:
    if action not in ("known", "review_later"):
        raise HTTPException(status_code=400, detail="إجراء غير صالح")
    language = await get_default_language(db)
    item = await get_content_item(
        db,
        student_id=student_id,
        content_id=content_id,
        content_type=CONTENT_TYPE,
        skill=None,
        level_skill=LanguageSkill.reading,
    )
    if not item:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="البطاقة غير موجودة")
    lemma = normalize_word((item.body_json or {}).get("word") or "")
    if not lemma:
        raise HTTPException(status_code=400, detail="بطاقة غير صالحة")
    progress = await _get_or_create_progress(
        db, student_id=student_id, language_id=language.id, lemma=lemma
    )
    now = datetime.now(timezone.utc)
    progress.review_count = int(progress.review_count or 0) + 1
    progress.last_reviewed_at = now
    if action == "known":
        progress.status = LanguageVocabularyStatus.known
        progress.mastery_score = 1.0
        event = "vocabulary_known"
    else:
        progress.status = LanguageVocabularyStatus.learning
        progress.mastery_score = max(float(progress.mastery_score or 0), 0.5)
        event = "vocabulary_review_later"
    await db.flush()
    await record_activity(
        db,
        student_id=student_id,
        language_id=language.id,
        event_type=event,
        skill=LanguageSkill.reading,
        payload_json={"content_item_id": item.id, "word": lemma, "title": item.title},
    )
    await refresh_language_analytics(db, student_id=student_id, language_id=language.id)
    if action == "known":
        await credit_feature_objectives(
            db,
            student_id=student_id,
            language_id=language.id,
            feature="vocabulary",
            score_percent=100.0,
            passed=True,
        )
    return _card_out(item, progress)
