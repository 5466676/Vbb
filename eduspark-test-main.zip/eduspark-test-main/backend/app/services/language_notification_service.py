"""Language module notifications — Phase A: subscription activated only."""

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.notification import NotificationType
from app.services import notification_service
from app.services.integration_hooks import notify_parent_alert


async def notify_language_subscription_activated(db: AsyncSession, *, student_id: int) -> None:
    await notification_service.create_notification(
        db,
        user_id=student_id,
        notification_type=NotificationType.system.value,
        title="تم تفعيل اشتراك تعلّم اللغة",
        body="يمكنك الآن البدء باختبار تحديد المستوى للإنجليزية.",
        payload={"module": "language", "event": "subscription_activated"},
    )
    await notify_parent_alert(
        db,
        student_id=student_id,
        title="اشتراك تعلّم اللغة",
        body="تم تفعيل اشتراك تعلّم اللغة للطالب.",
        payload={"module": "language", "event": "subscription_activated"},
    )
