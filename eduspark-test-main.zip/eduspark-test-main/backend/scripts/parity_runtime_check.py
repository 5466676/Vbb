"""Runtime feature parity — Germany vs Syria (authenticated ASGI probes)."""

from __future__ import annotations

import asyncio
import json
import subprocess
import sys
from pathlib import Path

import httpx
from httpx import ASGITransport
from sqlalchemy import create_engine, text

FEATURES = [
    "Speaking",
    "Speaking Coach",
    "Scenarios",
    "Adaptive",
    "Curriculum",
    "Analytics",
    "Planner",
    "Parent Monitoring",
    "Teacher AI Identity",
    "Learning Memory",
    "Voice Cloning",
]


def load_app(backend: Path):
    sys.path.insert(0, str(backend))
    for mod in list(sys.modules):
        if mod == "app" or mod.startswith("app."):
            del sys.modules[mod]
    from app.core.config import get_settings
    from app.main import app
    from app.core.test_users import TEST_USER_PASSWORD, default_test_email
    cfg = get_settings()
    creds = (default_test_email("auth_student"), TEST_USER_PASSWORD,
             default_test_email("auth_parent"), TEST_USER_PASSWORD,
             default_test_email("auth_teacher"), TEST_USER_PASSWORD)
    return app, cfg.DATABASE_URL, creds


def unload_app(backend: Path):
    sys.path.remove(str(backend))
    for mod in list(sys.modules):
        if mod == "app" or mod.startswith("app."):
            del sys.modules[mod]


async def probe(app, student_email, student_pw, parent_email, parent_pw, teacher_email, teacher_pw):
    transport = ASGITransport(app=app)
    out: dict = {}
    async with httpx.AsyncClient(transport=transport, base_url="http://t", timeout=90) as c:
        async def token(email, pw):
            r = await c.post("/api/auth/login", json={"email": email, "password": pw})
            out[f"login:{email.split('.')[1]}"] = r.status_code
            return {"Authorization": f"Bearer {r.json()['access_token']}"} if r.status_code == 200 else {}

        sh = await token(student_email, student_pw)
        ph = await token(parent_email, parent_pw)
        th = await token(teacher_email, teacher_pw)

        async def hit(key, method, path, headers, body=None):
            if not headers:
                out[key] = -1
                return
            if method == "GET":
                r = await c.get(path, headers=headers)
            else:
                r = await c.post(path, headers=headers, json=body or {})
            out[key] = r.status_code
            out[f"{key}_detail"] = r.text[:120].replace("\n", " ") if r.status_code not in (200, 201) else ""

        # Speaking & language
        await hit("speaking_list", "GET", "/api/student/languages/speaking", sh)
        await hit("speaking_conv", "GET", "/api/student/languages/speaking/conversation", sh)
        await hit("scenarios_list", "GET", "/api/student/languages/speaking/scenarios", sh)
        await hit("scenarios_start", "POST", "/api/student/languages/speaking/scenarios/1/start", sh)
        await hit("adaptive", "GET", "/api/student/languages/adaptive/state", sh)
        await hit("hub", "GET", "/api/student/languages/hub", sh)
        await hit("analytics", "GET", "/api/student/languages/analytics/dashboard", sh)
        await hit("achievements", "GET", "/api/student/languages/achievements", sh)

        # Speaking coach (Germany standalone route)
        await hit("coach_turn", "POST", "/api/speaking/coach/turn", sh, {"session_id": "probe", "message": "Hello"})

        # Planner
        await hit("planner", "GET", "/api/student/planner", sh)
        await hit("planner_gen", "POST", "/api/student/planner/generate", sh)

        # Parent
        await hit("parent_dash", "GET", "/api/parent/dashboard", ph)
        await hit("parent_planner", "GET", "/api/parent/planner-visibility", ph)
        await hit("parent_notes_cat", "GET", "/api/parent/notes/categories", ph)

        # Teacher
        await hit("teacher_ai", "GET", "/api/teacher/ai-profile", th)
        await hit("voice_sample", "GET", "/api/teacher/voice-sample", th)
        await hit("voice_profile", "GET", "/api/teacher/voice-profile", th)

    return out


def db_facts(db_url: str) -> dict:
    e = create_engine(db_url.replace("+asyncpg", ""))
    q = {
        "scenario_rows": "SELECT COUNT(*) FROM language_conversation_scenarios",
        "scenario_progress": "SELECT COUNT(*) FROM language_scenario_progress",
        "achievements_tbl": "SELECT COUNT(*) FROM information_schema.tables WHERE table_name='language_student_achievements'",
        "learning_profile_tbl": "SELECT COUNT(*) FROM information_schema.tables WHERE table_name='student_learning_profiles'",
        "teacher_ai_cols": (
            "SELECT COUNT(*) FROM information_schema.columns "
            "WHERE table_name='teacher_profiles' AND column_name='teacher_teaching_style'"
        ),
        "planner_slots": "SELECT COUNT(*) FROM planner_schedule_slots",
        "voice_samples": "SELECT COUNT(*) FROM teacher_voice_samples",
        "listening_urls": (
            "SELECT COUNT(*) FROM language_content_items WHERE skill='listening' "
            "AND is_published=true AND COALESCE(body_json->>'audio_url','') != ''"
        ),
    }
    with e.connect() as conn:
        return {k: str(conn.execute(text(sql)).scalar()) for k, sql in q.items()}


def route_facts(app) -> dict:
    paths = [getattr(r, "path", "") for r in app.routes]
    def has(*parts):
        return [p for p in paths if all(x in p for x in parts)]
    return {
        "scenario_routes": len(has("scenario")),
        "coach_routes": len(has("coach")),
        "planner_student": len(has("/student/planner")),
        "analytics_routes": len(has("analytics")),
        "ai_profile_routes": len(has("ai-profile")),
        "voice_routes": len([p for p in paths if "voice-sample" in p or "voice-profile" in p]),
    }


def run_verify(backend: Path, script: str) -> str:
    p = backend / "scripts" / script
    if not p.is_file():
        return "no script"
    try:
        r = subprocess.run(
            [sys.executable, str(p)],
            cwd=str(backend),
            capture_output=True,
            text=True,
            timeout=120,
        )
        tail = (r.stdout or r.stderr or "").strip().splitlines()
        summary = tail[-1] if tail else f"exit {r.returncode}"
        return f"exit {r.returncode}: {summary[:80]}"
    except Exception as ex:
        return f"ERR {ex}"


def classify(feature: str, de: dict, sy: dict, de_r: dict, sy_r: dict, de_db: dict, sy_db: dict) -> tuple[str, str, str]:
    h = lambda d, k: d.get(k, 0)
    ev = lambda d, k: f"HTTP {h(d,k)}" if h(d,k) != -1 else "login fail"

    if feature == "Speaking":
        de_ok = h(de, "speaking_list") == 200 and h(de, "speaking_conv") == 200
        sy_ok = h(sy, "speaking_list") == 200 and h(sy, "speaking_conv") == 200
        g = f"{ev(de,'speaking_list')}, {ev(de,'speaking_conv')}"
        s = f"{ev(sy,'speaking_list')}, {ev(sy,'speaking_conv')}"
    elif feature == "Speaking Coach":
        de_ok = h(de, "coach_turn") in (200, 422)  # 422 = route exists, validation
        sy_ok = de_r["coach_routes"] == 0 and h(sy, "speaking_list") == 200  # embedded on submit
        g = f"standalone API {ev(de,'coach_turn')} ({de_r['coach_routes']} routes)"
        s = f"embedded in /languages/speaking submit (no /coach route); list {ev(sy,'speaking_list')}"
        if de_ok and not sy_r["coach_routes"]:
            return g, s, "Partially Ported"
    elif feature == "Scenarios":
        de_ok = h(de, "scenarios_start") == 200
        sy_ok = h(sy, "scenarios_start") == 200
        g = f"start {ev(de,'scenarios_start')}, routes={de_r['scenario_routes']}, db={de_db['scenario_rows']} rows"
        s = f"start {ev(sy,'scenarios_start')}, routes={sy_r['scenario_routes']}, db={sy_db['scenario_rows']} orphan rows"
    elif feature == "Adaptive":
        de_ok = h(de, "adaptive") == 200
        sy_ok = h(sy, "adaptive") == 200
        g, s = ev(de, "adaptive"), ev(sy, "adaptive")
    elif feature == "Curriculum":
        de_ok = h(de, "hub") == 200
        sy_ok = h(sy, "hub") == 200
        g, s = ev(de, "hub"), ev(sy, "hub")
    elif feature == "Analytics":
        de_ok = h(de, "analytics") == 200
        sy_ok = h(sy, "analytics") == 200 and h(sy, "achievements") == 200
        g = f"lang analytics {ev(de,'analytics')} (no /achievements route)"
        s = f"dashboard {ev(sy,'analytics')}, achievements {ev(sy,'achievements')}, tbl={sy_db['achievements_tbl']}"
    elif feature == "Planner":
        de_ok = h(de, "planner") == 200
        sy_ok = h(sy, "planner") == 200
        g = f"student {ev(de,'planner')}, routes={de_r['planner_student']}"
        s = f"student {ev(sy,'planner')}, gen {ev(sy,'planner_gen')}, slots={sy_db['planner_slots']}"
    elif feature == "Parent Monitoring":
        de_ok = h(de, "parent_dash") in (200, 400)
        sy_ok = h(sy, "parent_dash") in (200, 400)
        g = f"dashboard {ev(de,'parent_dash')}, planner-vis {ev(de,'parent_planner')}"
        s = f"dashboard {ev(sy,'parent_dash')}, notes-cat {ev(sy,'parent_notes_cat')}, UI mounted"
    elif feature == "Teacher AI Identity":
        de_ok = de_db["teacher_ai_cols"] == "1"
        sy_ok = h(sy, "teacher_ai") == 200
        g = f"no /ai-profile route; col={de_db['teacher_ai_cols']}"
        s = f"/teacher/ai-profile {ev(sy,'teacher_ai')}, col={sy_db['teacher_ai_cols']}"
    elif feature == "Learning Memory":
        de_ok = de_db["learning_profile_tbl"] == "1"
        sy_ok = sy_db["learning_profile_tbl"] == "1"
        g = f"table={de_db['learning_profile_tbl']}, no API"
        s = f"table={sy_db['learning_profile_tbl']}, wired in lesson chat"
    elif feature == "Voice Cloning":
        de_ok = h(de, "voice_sample") == 200
        sy_ok = h(sy, "voice_sample") == 200
        g = f"{ev(de,'voice_sample')}, samples={de_db['voice_samples']}"
        s = f"{ev(sy,'voice_sample')}, samples={sy_db['voice_samples']}"
    else:
        de_ok = sy_ok = False
        g = s = "?"

    if feature == "Speaking Coach":
        pass  # already returned
    elif feature == "Scenarios":
        if de_ok and not sy_ok:
            status = "Missing"
        elif de_ok and sy_ok:
            status = "Fully Ported"
        else:
            status = "Partially Ported"
    elif feature == "Analytics":
        status = "Fully Ported" if sy_ok and not de_ok else ("Fully Ported" if de_ok and sy_ok else ("Partially Ported" if sy_ok or de_ok else "Missing"))
    elif feature == "Planner":
        status = "Fully Ported" if sy_ok and not de_ok else ("Fully Ported" if de_ok and sy_ok else ("Partially Ported" if sy_ok or de_ok else "Missing"))
    elif feature == "Teacher AI Identity":
        status = "Fully Ported" if sy_ok and not de_ok else ("Fully Ported" if de_ok and sy_ok else ("Partially Ported" if sy_ok or de_ok else "Missing"))
    elif feature == "Learning Memory":
        status = "Fully Ported" if sy_ok and not de_ok else ("Fully Ported" if de_ok and sy_ok else ("Partially Ported" if sy_ok or de_ok else "Missing"))
    else:
        if de_ok and sy_ok:
            status = "Fully Ported"
        elif de_ok or sy_ok:
            status = "Partially Ported"
        else:
            status = "Missing"

    if feature != "Speaking Coach":
        return g, s, status
    return g, s, "Partially Ported"


def main():
    germany = Path(r"C:\Projects\EduSpark-Germany\backend")
    syria = Path(r"C:\Projects\EduSpark-Syrian\backend")

    app_de, db_de, creds_de = load_app(germany)
    routes_de = route_facts(app_de)
    http_de = asyncio.run(probe(app_de, *creds_de))
    facts_de = db_facts(db_de)
    unload_app(germany)

    app_sy, db_sy, creds_sy = load_app(syria)
    routes_sy = route_facts(app_sy)
    http_sy = asyncio.run(probe(app_sy, *creds_sy))
    facts_sy = db_facts(db_sy)

    # mp3 on disk
    facts_de["mp3"] = str(len(list((germany.parent / "public" / "language-assets").rglob("*.mp3"))))
    facts_sy["mp3"] = str(len(list((syria.parent / "public" / "language-assets").rglob("*.mp3"))))

    print(json.dumps({"germany_http": http_de, "syria_http": http_sy, "germany_db": facts_de, "syria_db": facts_sy,
                      "germany_routes": routes_de, "syria_routes": routes_sy}, indent=2))

    print("\n| Feature | Germany | Syria | Status |")
    print("|---------|---------|-------|--------|")
    for f in FEATURES:
        g, s, st = classify(f, http_de, http_sy, routes_de, routes_sy, facts_de, facts_sy)
        print(f"| {f} | {g} | {s} | **{st}** |")

    print("\n### Verify scripts (runtime)")
    for repo, backend, scripts in [
        ("Germany", germany, ["verify_language_scenarios.py", "verify_voice_upload.py"]),
        ("Syria", syria, ["verify_language_analytics_achievements.py", "verify_language_adaptive_progression.py",
                          "verify_language_curriculum.py", "verify_language_speaking_coach.py",
                          "verify_teacher_identity.py", "verify_student_learning_memory.py", "verify_priority_repairs.py"]),
    ]:
        print(f"\n{repo}:")
        for sc in scripts:
            print(f"  {sc}: {run_verify(backend, sc)}")

    unload_app(syria)


if __name__ == "__main__":
    main()
