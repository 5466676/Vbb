"""Verify migration repair — idempotent 0042/0043 and ghost revision removal.

Usage (from backend/):
    python scripts/verify_migration_repair.py
    python scripts/verify_migration_repair.py --live-db
"""

from __future__ import annotations

import argparse
import importlib.util
import re
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

BACKEND = Path(__file__).resolve().parents[1]
VERSIONS = BACKEND / "alembic" / "versions"


def _load_upgrade(module_name: str, filename: str):
    path = VERSIONS / filename
    spec = importlib.util.spec_from_file_location(module_name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.upgrade, mod.downgrade


def _static_checks() -> dict[str, bool]:
    m42 = (VERSIONS / "0042_adaptive_difficulty.py").read_text(encoding="utf-8")
    m43 = (VERSIONS / "0043_add_recent_scores_json.py").read_text(encoding="utf-8")
    repair = (BACKEND / "scripts" / "repair_alembic_migration_chain.py").read_text(encoding="utf-8")
    return {
        "0042_exists": (VERSIONS / "0042_adaptive_difficulty.py").exists(),
        "0043_exists": (VERSIONS / "0043_add_recent_scores_json.py").exists(),
        "0042_idempotent_skip": "language_skill_level_state" in m42 and "in insp.get_table_names()" in m42,
        "0042_no_recent_scores_in_create": "recent_scores_json" not in m42.split("op.create_table")[1].split("def downgrade")[0],
        "0043_revises_0042": 'down_revision = "0042_adaptive_difficulty"' in m43,
        "0043_idempotent_column": "recent_scores_json" in m43 and "in cols" in m43,
        "repair_script_exists": (BACKEND / "scripts" / "repair_alembic_migration_chain.py").exists(),
        "repair_targets_0044": "0044_scenario_multilang" in repair,
        "no_0044_in_repo": not (VERSIONS / "0044_scenario_multilang.py").exists(),
    }


def _simulate_fresh_path() -> dict[str, bool]:
    """Table absent: 0042 creates base table; 0043 adds recent_scores_json."""
    upgrade_42, _ = _load_upgrade("m42", "0042_adaptive_difficulty.py")
    upgrade_43, _ = _load_upgrade("m43", "0043_add_recent_scores_json.py")

    created = {"language_skill_level_state": False}
    columns = {"language_skill_level_state": set()}

    tables = set()

    def fake_create_table(name, *args, **kwargs):
        created[name] = True
        tables.add(name)

    def fake_create_index(name, table, cols, **kw):
        pass

    def fake_add_column(table, col, **kw):
        col_name = getattr(col, "name", None) or getattr(col, "key", None)
        if col_name:
            columns.setdefault(table, set()).add(col_name)

    insp = MagicMock()
    insp.get_table_names.side_effect = lambda: sorted(tables)
    insp.get_columns.side_effect = lambda t: [{"name": c} for c in sorted(columns.get(t, set()))]

    conn = MagicMock()
    with patch("alembic.op.get_bind", return_value=conn), patch("sqlalchemy.inspect", return_value=insp), patch(
        "alembic.op.create_table", side_effect=fake_create_table
    ), patch("alembic.op.create_index", side_effect=fake_create_index), patch(
        "alembic.op.add_column", side_effect=fake_add_column
    ):
        upgrade_42()
        upgrade_43()

    return {
        "fresh_table_created": created["language_skill_level_state"],
        "fresh_column_added": "recent_scores_json" in columns["language_skill_level_state"],
    }


def _simulate_mixed_path() -> dict[str, bool]:
    """Table present without recent_scores_json: 0042 skip; 0043 adds column."""
    upgrade_42, _ = _load_upgrade("m42", "0042_adaptive_difficulty.py")
    upgrade_43, _ = _load_upgrade("m43", "0043_add_recent_scores_json.py")

    create_called = {"v": False}
    columns = {
        "language_skill_level_state": {
            "id",
            "student_id",
            "language_id",
            "skill",
            "current_level",
            "consecutive_pass_count",
            "consecutive_fail_count",
            "last_level_change_at",
            "updated_at",
        }
    }

    def fake_create_table(name, *args, **kwargs):
        create_called["v"] = True

    def fake_add_column(table, col, **kw):
        col_name = getattr(col, "name", None) or getattr(col, "key", None)
        if col_name:
            columns[table].add(col_name)

    insp = MagicMock()
    insp.get_table_names.return_value = ["language_skill_level_state"]
    insp.get_columns.side_effect = lambda t: [{"name": c} for c in sorted(columns.get(t, set()))]

    conn = MagicMock()
    with patch("alembic.op.get_bind", return_value=conn), patch("sqlalchemy.inspect", return_value=insp), patch(
        "alembic.op.create_table", side_effect=fake_create_table
    ), patch("alembic.op.add_column", side_effect=fake_add_column):
        upgrade_42()
        upgrade_43()

    return {
        "mixed_create_skipped": not create_called["v"],
        "mixed_column_added": "recent_scores_json" in columns["language_skill_level_state"],
    }


def _simulate_mixed_already_repaired() -> dict[str, bool]:
    """Table present with column: both migrations no-op."""
    upgrade_42, _ = _load_upgrade("m42", "0042_adaptive_difficulty.py")
    upgrade_43, _ = _load_upgrade("m43", "0043_add_recent_scores_json.py")

    create_called = {"v": False}
    add_called = {"v": False}
    columns = {
        "language_skill_level_state": {
            "id",
            "recent_scores_json",
            "current_level",
        }
    }

    def fake_create_table(*a, **k):
        create_called["v"] = True

    def fake_add_column(*a, **k):
        add_called["v"] = True

    insp = MagicMock()
    insp.get_table_names.return_value = ["language_skill_level_state"]
    insp.get_columns.side_effect = lambda t: [{"name": c} for c in columns[t]]

    conn = MagicMock()
    with patch("alembic.op.get_bind", return_value=conn), patch("sqlalchemy.inspect", return_value=insp), patch(
        "alembic.op.create_table", side_effect=fake_create_table
    ), patch("alembic.op.add_column", side_effect=fake_add_column):
        upgrade_42()
        upgrade_43()

    return {
        "repaired_create_skipped": not create_called["v"],
        "repaired_add_skipped": not add_called["v"],
    }


def _chain_check() -> dict[str, bool]:
    try:
        from alembic.config import Config
        from alembic.script import ScriptDirectory

        cfg = Config(str(BACKEND / "alembic.ini"))
        script = ScriptDirectory.from_config(cfg)
        heads = set(script.get_heads())
        has_0043_head = "0043_add_recent_scores_json" in heads
        rev = script.get_revision("0043_add_recent_scores_json")
        chain_ok = rev.down_revision == "0042_adaptive_difficulty"
        no_0044 = all(r.revision != "0044_scenario_multilang" for r in script.walk_revisions())
        return {
            "head_is_0043": has_0043_head,
            "0043_down_revision_0042": chain_ok,
            "no_0044_in_script_dir": no_0044,
        }
    except Exception:
        return {"head_is_0043": False, "0043_down_revision_0042": False, "no_0044_in_script_dir": False}


def _live_db_check() -> dict[str, bool]:
    try:
        import psycopg2
        from app.core.config import get_settings

        url = get_settings().sync_database_url
        m = re.match(r"postgresql\+psycopg2://([^:]+):([^@]+)@([^:]+):(\d+)/(.+)", url)
        user, pw, host, port, db = m.groups()
        conn = psycopg2.connect(host=host, port=port, dbname=db, user=user, password=pw)
        cur = conn.cursor()
        cur.execute("SELECT version_num FROM alembic_version ORDER BY 1")
        versions = [r[0] for r in cur.fetchall()]
        cur.execute(
            """
            SELECT column_name FROM information_schema.columns
            WHERE table_name = 'language_skill_level_state'
            ORDER BY ordinal_position
            """
        )
        cols = [r[0] for r in cur.fetchall()]
        conn.close()
        return {
            "live_no_0044_stamp": "0044_scenario_multilang" not in versions,
            "live_has_recent_scores_json": "recent_scores_json" in cols,
            "live_skill_state_table": "language_skill_level_state" in {c for c in cols} or bool(cols),
        }
    except Exception:
        return {
            "live_no_0044_stamp": False,
            "live_has_recent_scores_json": False,
            "live_skill_state_table": False,
        }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--live-db", action="store_true", help="Include live PostgreSQL checks")
    args = parser.parse_args()

    print("Migration repair — verify_migration_repair\n")

    sections = [
        ("Static checks", _static_checks()),
        ("Simulated fresh DB path", _simulate_fresh_path()),
        ("Simulated mixed Germany/Syria path", _simulate_mixed_path()),
        ("Simulated already-repaired path", _simulate_mixed_already_repaired()),
        ("Alembic chain", _chain_check()),
    ]
    if args.live_db:
        sections.append(("Live database", _live_db_check()))

    total = passed = 0
    for title, checks in sections:
        print(title)
        print("-" * len(title))
        for k, v in checks.items():
            print(f"  {k}: {'PASS' if v else 'FAIL'}")
            total += 1
            if v:
                passed += 1
        print()

    print(f"{passed}/{total} checks passed.")
    return 0 if passed == total else 1


if __name__ == "__main__":
    raise SystemExit(main())
