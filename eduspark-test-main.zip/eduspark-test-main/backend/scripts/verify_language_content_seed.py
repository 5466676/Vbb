"""Verify Phase 10.2 Language Content Seed Pipeline parity.

Usage (from backend/):
    python scripts/verify_language_content_seed.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

BACKEND = Path(__file__).resolve().parents[1]
ROOT = BACKEND.parent
GER_SEED = Path(r"C:\Projects\EduSpark-Germany\backend\alembic\seeds\language_content")
SYR_SEED = BACKEND / "alembic" / "seeds" / "language_content"
SKILLS = ["reading", "listening", "writing", "speaking"]
LEVELS = ["A1", "A2", "B1", "B2", "C1", "C2"]


def _count_seed_items(seed_dir: Path) -> tuple[int, int]:
    if not seed_dir.is_dir():
        return 0, 0
    files = list(seed_dir.glob("*.json"))
    total = 0
    for path in files:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, list):
                total += len(data)
        except (json.JSONDecodeError, OSError):
            pass
    return len(files), total


def static_checks() -> dict[str, bool | int]:
    mig_dir = BACKEND / "alembic" / "versions"
    ger_files, ger_items = _count_seed_items(GER_SEED)
    syr_files, syr_items = _count_seed_items(SYR_SEED)
    return {
        "seed_dir_exists": SYR_SEED.is_dir(),
        "seed_file_count_24": syr_files >= 24,
        "seed_item_parity": syr_items == ger_items and ger_items > 0,
        "migration_0049": (mig_dir / "0049_placement_listening_stems.py").is_file(),
        "migration_0050": (mig_dir / "0050_seed_language_content.py").is_file(),
        "migration_0051": (mig_dir / "0051_fix_lesson_content_type.py").is_file(),
        "test_seed_script": (BACKEND / "scripts" / "test_seed_migration.py").is_file(),
        "ger_seed_files": ger_files,
        "syr_seed_files": syr_files,
        "ger_seed_items": ger_items,
        "syr_seed_items": syr_items,
    }


def db_checks() -> dict[str, bool | int]:
    from sqlalchemy import create_engine, text

    from app.core.config import get_settings

    engine = create_engine(get_settings().DATABASE_URL.replace("+asyncpg", ""))
    out: dict[str, bool | int] = {}
    with engine.connect() as conn:
        rev = conn.execute(text("SELECT version_num FROM alembic_version")).scalar()
        out["alembic_at_head"] = rev == "0051_fix_lesson_content_type"

        lang_id = conn.execute(text("SELECT id FROM languages WHERE code='en' LIMIT 1")).scalar()
        if not lang_id:
            out["db_content_checks"] = False
            return out

        for skill in SKILLS:
            count = conn.execute(
                text(
                    "SELECT count(*) FROM language_content_items "
                    "WHERE language_id=:lang AND skill=cast(:skill as language_skill) AND is_published=true"
                ),
                {"lang": lang_id, "skill": skill},
            ).scalar()
            out[f"db_{skill}"] = int(count or 0)

        lesson_type = conn.execute(
            text(
                "SELECT count(*) FROM language_content_items "
                "WHERE language_id=:lang AND skill IN ('reading','listening') "
                "AND content_type='lesson' AND is_published=true"
            ),
            {"lang": lang_id},
        ).scalar()
        out["db_reading_listening_lesson_type"] = int(lesson_type or 0)

        legacy = conn.execute(
            text(
                "SELECT count(*) FROM language_content_items "
                "WHERE skill IN ('reading','listening') "
                "AND content_type IN ('reading_lesson','listening_lesson')"
            )
        ).scalar()
        out["legacy_bad_content_type_zero"] = int(legacy or 0) == 0

        placement_fixed = conn.execute(
            text(
                "SELECT count(*) FROM language_placement_questions "
                "WHERE question_type='mcq_listening' "
                "AND (prompt_json->>'audio_transcript') IS NOT NULL "
                "AND length(trim(prompt_json->>'audio_transcript')) > 0"
            )
        ).scalar()
        placement_total = conn.execute(
            text(
                "SELECT count(*) FROM language_placement_questions WHERE question_type='mcq_listening'"
            )
        ).scalar()
        out["placement_listening_with_transcript"] = int(placement_fixed or 0)
        out["placement_listening_total"] = int(placement_total or 0)
        out["placement_stems_ok"] = int(placement_total or 0) == 0 or int(placement_fixed or 0) >= int(
            placement_total or 0
        )

        title_ar = conn.execute(
            text(
                "SELECT count(*) FROM language_content_items "
                "WHERE language_id=:lang AND body_json ? 'title_ar' AND is_published=true"
            ),
            {"lang": lang_id},
        ).scalar()
        out["db_items_with_title_ar"] = int(title_ar or 0)

    return out


def main() -> int:
    static = static_checks()

    print("=== Phase 10.2 Language Content Seed Pipeline ===\n")
    print("Static:")
    for k, v in static.items():
        if isinstance(v, bool):
            print(f"  {k}: {'PASS' if v else 'FAIL'}")
        else:
            print(f"  {k}: {v}")

    # Run seed JSON validator
    import subprocess

    proc = subprocess.run(
        [sys.executable, str(BACKEND / "scripts" / "test_seed_migration.py")],
        cwd=str(BACKEND),
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    seed_valid = proc.returncode == 0
    print(f"\n  test_seed_migration: {'PASS' if seed_valid else 'FAIL'}")
    if proc.stdout.strip():
        for line in proc.stdout.strip().splitlines()[-3:]:
            print(f"    {line}")

    db = db_checks()
    print("\nDatabase:")
    for k, v in db.items():
        if isinstance(v, bool):
            print(f"  {k}: {'PASS' if v else 'FAIL'}")
        else:
            print(f"  {k}: {v}")

    bool_static = [v for v in static.values() if isinstance(v, bool)]
    bool_db = [v for v in db.values() if isinstance(v, bool)]
    passed = sum(bool_static) + (1 if seed_valid else 0) + sum(bool_db)
    total = len(bool_static) + 1 + len(bool_db)
    print(f"\n=== Results: {passed}/{total} checks passed ===")

    ok = all(bool_static) and seed_valid and all(bool_db)
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
