"""Runtime trace: which speaker_wav reaches XTTS /synthesize."""
from __future__ import annotations

import asyncio
import hashlib
import json
import sys
import time
from pathlib import Path

import httpx
import psycopg2

BACKEND = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND))

BASE = "http://127.0.0.1:8000"
WORKER = "http://127.0.0.1:8010"
OUT = Path(__file__).resolve().parent / "voice_synthesis_runtime_trace.json"
PASSWORDS = ("Hk2003hk123", "teacher123", "password123", "qwerty")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def login(email: str) -> str | None:
    for pwd in PASSWORDS:
        r = httpx.post(f"{BASE}/api/auth/login", json={"email": email, "password": pwd}, timeout=30)
        if r.status_code == 200:
            return r.json()["access_token"]
    return None


async def trace_synthesis(speaker_path: Path, text: str) -> dict:
    from app.services.tts_service import _synthesize_via_worker, prepare_synthesis_text

    out = Path(BACKEND / "uploads" / "answers" / f"trace_{int(time.time())}.wav")
    out.parent.mkdir(parents=True, exist_ok=True)
    cleaned = prepare_synthesis_text(text)
    t0 = time.perf_counter()
    ok = await _synthesize_via_worker(cleaned, speaker_path, out)
    return {
        "backend_speaker_path": str(speaker_path),
        "backend_speaker_sha256": sha256_file(speaker_path),
        "backend_speaker_bytes": speaker_path.stat().st_size,
        "output_path": str(out),
        "output_exists": out.exists(),
        "output_bytes": out.stat().st_size if out.exists() else 0,
        "output_sha256": sha256_file(out) if out.exists() else None,
        "ok": ok,
        "duration_ms": int((time.perf_counter() - t0) * 1000),
    }


def main() -> None:
    report: dict = {"timestamp": time.time()}

    # Worker health
    try:
        wh = httpx.get(f"{WORKER}/health", timeout=15)
        report["worker_health"] = wh.json() if wh.status_code == 200 else {"status": wh.status_code, "body": wh.text[:300]}
    except Exception as exc:
        report["worker_health"] = {"error": str(exc)}

    from app.core.config import get_settings

    s = get_settings()
    report["settings"] = {
        "ENABLE_TTS": s.ENABLE_TTS,
        "TTS_PROVIDER": s.TTS_PROVIDER,
        "TTS_WORKER_URL": s.TTS_WORKER_URL,
        "TTS_LANGUAGE": s.TTS_LANGUAGE,
    }

    conn = psycopg2.connect(
        host="localhost", port=5432, user="postgres", password="Hk2003hk123", dbname="eduspark"
    )
    cur = conn.cursor()
    cur.execute(
        """
        SELECT tvs.id, tvs.teacher_profile_id, tp.user_id, u.email,
               tvs.processing_status, tvs.storage_path, tvs.duration_seconds,
               LEFT(tvs.transcript, 120), tvs.uploaded_at
        FROM teacher_voice_samples tvs
        JOIN teacher_profiles tp ON tp.id = tvs.teacher_profile_id
        JOIN users u ON u.id = tp.user_id
        ORDER BY tvs.uploaded_at DESC
        """
    )
    samples = []
    for row in cur.fetchall():
        p = Path(row[5]) if row[5] else None
        samples.append(
            {
                "id": row[0],
                "teacher_profile_id": row[1],
                "teacher_user_id": row[2],
                "email": row[3],
                "status": row[4],
                "storage_path": row[5],
                "exists": p.exists() if p else False,
                "bytes": p.stat().st_size if p and p.exists() else 0,
                "sha256": sha256_file(p) if p and p.exists() else None,
                "duration_seconds": float(row[6]) if row[6] else None,
                "transcript_preview": row[7],
                "uploaded_at": str(row[8]),
            }
        )
    report["teacher_voice_samples"] = samples

    cur.execute(
        """
        SELECT l.id, l.title, l.teacher_id, u.email, l.voice_path, la.storage_path
        FROM lessons l
        JOIN users u ON u.id = l.teacher_id
        LEFT JOIN lesson_assets la ON la.lesson_id = l.id AND la.asset_type = 'audio'
        WHERE l.status::text = 'processed'
        ORDER BY l.id DESC
        LIMIT 5
        """
    )
    lessons = []
    for row in cur.fetchall():
        lesson_voice = row[4]
        asset_audio = row[5]
        resolved = lesson_voice or None
        lessons.append(
            {
                "lesson_id": row[0],
                "title": row[1],
                "teacher_id": row[2],
                "teacher_email": row[3],
                "lesson_voice_path": lesson_voice,
                "lesson_audio_asset": asset_audio,
                "resolved_speaker_priority": "lesson.voice_path first, else teacher profile sample",
                "would_use_lesson_voice": bool(lesson_voice),
            }
        )
    report["lessons"] = lessons

    conn.close()

    # Resolve speaker for yaser lesson 79 (same logic as student.py chat)
    async def resolve_for_lesson(lesson_id: int) -> dict:
        from sqlalchemy import select
        from app.db.session import AsyncSessionLocal
        from app.models.lesson import Lesson
        from app.services.teacher_voice_service import get_ready_voice_path_for_teacher

        async with AsyncSessionLocal() as db:
            lesson = await db.get(Lesson, lesson_id)
            profile_path = await get_ready_voice_path_for_teacher(db, lesson.teacher_id)
            speaker = lesson.voice_path or profile_path
            p = Path(speaker) if speaker else None
            return {
                "lesson_id": lesson_id,
                "lesson_voice_path": lesson.voice_path,
                "profile_ready_path": profile_path,
                "speaker_wav_used": speaker,
                "same_file": lesson.voice_path == profile_path if lesson.voice_path and profile_path else None,
                "exists": p.exists() if p else False,
                "sha256": sha256_file(p) if p and p.exists() else None,
            }

    report["speaker_resolution"] = asyncio.run(resolve_for_lesson(79))

    # Direct worker /synthesize with uploaded bytes trace
    sample = next((s for s in samples if s["status"] == "ready" and s["exists"]), None)
    if sample:
        speaker = Path(sample["storage_path"])
        text = "مرحباً، هذا اختبار استنساخ صوت المعلم."
        uploaded_sha = sample["sha256"]
        t0 = time.perf_counter()
        with speaker.open("rb") as f:
            wr = httpx.post(
                f"{WORKER}/synthesize",
                data={"text": text, "language": "ar"},
                files={"speaker": (speaker.name, f, "audio/wav")},
                timeout=600,
            )
        report["worker_synthesize"] = {
            "sample_id": sample["id"],
            "teacher_email": sample["email"],
            "uploaded_speaker_path": str(speaker),
            "uploaded_speaker_sha256": uploaded_sha,
            "uploaded_filename_sent": speaker.name,
            "status_code": wr.status_code,
            "duration_ms": int((time.perf_counter() - t0) * 1000),
            "response_bytes": len(wr.content) if wr.status_code == 200 else wr.text[:400],
            "note": "Worker converts upload to tmp/speaker.wav @ 24kHz mono before XTTS",
        }
        if wr.status_code == 200:
            out = Path(BACKEND / "uploads" / "answers" / f"worker_direct_{sample['id']}.wav")
            out.write_bytes(wr.content)
            report["worker_synthesize"]["saved_output"] = str(out)

        report["backend_tts_service"] = asyncio.run(trace_synthesis(speaker, text))

    # Chat probe with worker up
    st = login("hamza.kuzbari1@gmail.com")
    if st:
        chat = httpx.post(
            f"{BASE}/api/student/chat",
            json={"lesson_id": 79, "message": "عرّف التركيب الضوئي بجملة واحدة."},
            headers={"Authorization": f"Bearer {st}"},
            timeout=120,
        )
        report["chat_immediate"] = {"status": chat.status_code}
        if chat.status_code == 200:
            body = chat.json()
            ai = [m for m in body.get("messages", []) if m.get("role") == "ai"]
            last = ai[-1] if ai else {}
            report["chat_immediate"].update(
                {
                    "audio_url": last.get("audioUrl"),
                    "text_preview": (last.get("text") or "")[:80],
                }
            )
            # wait for background TTS
            time.sleep(35)
            chat2 = httpx.post(
                f"{BASE}/api/student/chat",
                json={"lesson_id": 79, "message": "عرّف التركيب الضوئي بجملة واحدة."},
                headers={"Authorization": f"Bearer {st}"},
                timeout=120,
            )
            # reload messages via history - use GET if exists
            hist = httpx.get(
                f"{BASE}/api/student/lessons/79",
                headers={"Authorization": f"Bearer {st}"},
                timeout=60,
            )
            if hist.status_code == 200:
                msgs = hist.json().get("chatMessages") or hist.json().get("chat_messages") or []
                ai_msgs = [m for m in msgs if m.get("role") == "ai"]
                if ai_msgs:
                    last2 = ai_msgs[-1]
                    report["chat_after_wait"] = {
                        "audioUrl": last2.get("audioUrl"),
                        "has_audio": bool(last2.get("audioUrl")),
                    }

    # Read worker logs tail
    worker_log = Path(
        r"C:\Users\oabo7\.cursor\projects\c-Users-oabo7-AppData-Local-Packages-5319275A-WhatsAppDesktop-cv1g1gvanyjgm-LocalState-sessions-270D6E5E07462C2C46C99472527F70AF9E26797A-transfers-2026-21-eduspark-frontend-2-eduspark-frontend-main\terminals\826067.txt"
    )
    if worker_log.exists():
        lines = worker_log.read_text(encoding="utf-8", errors="replace").splitlines()
        report["worker_log_tail"] = [ln for ln in lines if "XTTS" in ln or "synthesis" in ln.lower() or "ffmpeg" in ln.lower()][-15:]

    report["findings"] = []
    if report.get("worker_health", {}).get("error"):
        report["findings"].append("TTS worker was unreachable — chat audio cannot be generated (no fallback default speaker in code).")
    if sample and "rk rk rk" in (sample.get("transcript_preview") or ""):
        report["findings"].append("Teacher sample transcript is garbage (Whisper failed) — XTTS still clones timbre from audio but quality will be poor.")
    if not any(l.get("lesson_voice_path") for l in lessons):
        report["findings"].append("All lessons have lesson.voice_path=null — synthesis uses teacher_voice_samples.storage_path only (not a default XTTS speaker).")

    OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(str(OUT))
    print(json.dumps(report.get("findings"), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
