"""Repair Alembic version table — remove ghost Germany revision 0044_scenario_multilang.

Usage (from backend/):
    python scripts/repair_alembic_migration_chain.py          # dry-run
    python scripts/repair_alembic_migration_chain.py --apply # delete ghost row

Then upgrade the Syria chain:
    .\\scripts\\alembic.ps1 upgrade 0040_student_learning_profile
    python scripts/repair_alembic_migration_chain.py --apply --stamp-curriculum
    .\\scripts\\alembic.ps1 upgrade 0043_add_recent_scores_json
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

GHOST_REVISIONS = frozenset({"0044_scenario_multilang"})
MIN_VERSION_NUM_LEN = 64


def _connect():
    import psycopg2
    from app.core.config import get_settings

    url = get_settings().sync_database_url
    m = re.match(r"postgresql\+psycopg2://([^:]+):([^@]+)@([^:]+):(\d+)/(.+)", url)
    if not m:
        raise RuntimeError(f"Cannot parse sync database URL: {url[:40]}...")
    user, pw, host, port, db = m.groups()
    return psycopg2.connect(host=host, port=port, dbname=db, user=user, password=pw)


def read_versions(conn) -> list[str]:
    cur = conn.cursor()
    cur.execute("SELECT version_num FROM alembic_version ORDER BY 1")
    return [r[0] for r in cur.fetchall()]


def ensure_version_num_length(conn, *, apply: bool) -> bool:
    """Widen alembic_version.version_num when varchar(32) blocks long Syria revision ids."""
    cur = conn.cursor()
    cur.execute(
        """
        SELECT character_maximum_length
        FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'alembic_version'
          AND column_name = 'version_num'
        """
    )
    row = cur.fetchone()
    if not row or row[0] is None or int(row[0]) >= MIN_VERSION_NUM_LEN:
        return False
    if apply:
        cur.execute(
            f"ALTER TABLE alembic_version ALTER COLUMN version_num TYPE VARCHAR({MIN_VERSION_NUM_LEN})"
        )
        conn.commit()
    return True


def stamp_revision_if_at(conn, *, expected: str, target: str, apply: bool) -> bool:
    current = read_versions(conn)
    if current != [expected]:
        return False
    if apply:
        cur = conn.cursor()
        cur.execute("UPDATE alembic_version SET version_num = %s WHERE version_num = %s", (target, expected))
        conn.commit()
    return True


def remove_ghost_revisions(conn, *, apply: bool) -> list[str]:
    current = read_versions(conn)
    ghosts = [v for v in current if v in GHOST_REVISIONS]
    if not ghosts:
        return []

    if apply:
        cur = conn.cursor()
        for rev in ghosts:
            cur.execute("DELETE FROM alembic_version WHERE version_num = %s", (rev,))
        conn.commit()
    return ghosts


def main() -> int:
    parser = argparse.ArgumentParser(description="Repair Alembic version table for Syria migration chain")
    parser.add_argument("--apply", action="store_true", help="Execute changes (default is dry-run)")
    parser.add_argument(
        "--stamp-curriculum",
        action="store_true",
        help="When at 0040, stamp 0041_language_curriculum_progress (mixed DB with existing table)",
    )
    args = parser.parse_args()

    conn = _connect()
    try:
        before = read_versions(conn)
        print("alembic_version (before):", before)

        widened = ensure_version_num_length(conn, apply=args.apply)
        if widened:
            print(("Widened" if args.apply else "Would widen") + f" alembic_version.version_num to VARCHAR({MIN_VERSION_NUM_LEN})")

        ghosts = remove_ghost_revisions(conn, apply=args.apply)
        if ghosts:
            print(("Removed" if args.apply else "Would remove") + " ghost revisions:", ghosts)

        if args.stamp_curriculum:
            stamped = stamp_revision_if_at(
                conn,
                expected="0040_student_learning_profile",
                target="0041_language_curriculum_progress",
                apply=args.apply,
            )
            if stamped:
                print(
                    ("Stamped" if args.apply else "Would stamp")
                    + " 0040_student_learning_profile -> 0041_language_curriculum_progress"
                )
            else:
                print("Skip curriculum stamp — not exactly at 0040_student_learning_profile")

        if args.apply:
            print("alembic_version (after):", read_versions(conn))
        elif not ghosts and not widened and not args.stamp_curriculum:
            print("Nothing to do.")
        elif not args.apply:
            print("Re-run with --apply to execute.")
        return 0
    finally:
        conn.close()


if __name__ == "__main__":
    raise SystemExit(main())
