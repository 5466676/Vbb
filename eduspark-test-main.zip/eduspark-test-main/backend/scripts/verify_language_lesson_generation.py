"""Verify Phase 10.3 Nightly Language Lesson Generation parity.

Usage (from backend/):
    python scripts/verify_language_lesson_generation.py
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path
from unittest.mock import AsyncMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

BACKEND = Path(__file__).resolve().parents[1]
GER_SERVICE = Path(r"C:\Projects\EduSpark-Germany\backend\app\services\language_lesson_generation_service.py")


def static_checks() -> dict[str, bool]:
    svc = BACKEND / "app" / "services" / "language_lesson_generation_service.py"
    script = BACKEND / "scripts" / "generate_lessons.py"
    src = svc.read_text(encoding="utf-8") if svc.is_file() else ""
    ger = GER_SERVICE.read_text(encoding="utf-8") if GER_SERVICE.is_file() else ""
    exports = [
        "run_nightly_topup",
        "generate_and_store",
        "TARGET_PER_BUCKET",
        "get_level_curriculum",
        "ai_nightly",
    ]
    return {
        "service_file": svc.is_file(),
        "generate_script": script.is_file(),
        "exports_present": all(x in src for x in exports),
        "curriculum_integration": "get_level_curriculum" in src,
        "duplicate_title_guard": "_existing_titles" in src and "norm[\"title\"] in existing" in src,
        "gemini_noop": "if not settings.GEMINI_API_KEY" in src,
        "scheduler_script_parity": "run_nightly_topup" in script.read_text(encoding="utf-8"),
        "germany_export_parity": all(x in src for x in ["run_nightly_topup", "generate_and_store", "TARGET_PER_BUCKET"]),
    }


MOCK_READING = json.dumps(
    {
        "items": [
            {
                "title": "Verify Nightly Lesson Alpha",
                "title_ar": "درس ليلي للتحقق ألف",
                "passage": "Hello from Damascus. This is a short reading passage for verification.",
                "passage_ar": "مرحبا من دمشق. هاد نص قصير للتحقق.",
                "questions": [
                    {
                        "stem": "Where is the speaker?",
                        "choices": ["Damascus", "Berlin", "Paris", "Cairo"],
                        "correct_index": 0,
                    },
                    {
                        "stem": "What is this text for?",
                        "choices": ["Verification", "Cooking", "Sports", "Music"],
                        "correct_index": 0,
                    },
                ],
            }
        ]
    }
)


async def runtime_checks() -> dict[str, bool]:
    from app.services.language_lesson_generation_service import (
        TARGET_PER_BUCKET,
        _to_body,
        generate_and_store,
        run_nightly_topup,
    )
    from app.services.language_subscription_service import get_default_language

    out: dict[str, bool] = {}

    body = _to_body(
        "reading",
        "A1",
        json.loads(MOCK_READING)["items"][0],
    )
    out["validation_reading"] = (
        body is not None
        and body["body"].get("source") == "ai_nightly"
        and body["body"].get("passage")
        and len(body["body"].get("questions") or []) == 2
    )

    with patch("app.services.language_lesson_generation_service.settings") as mock_settings:
        mock_settings.GEMINI_API_KEY = ""
        from app.db.session import AsyncSessionLocal

        async with AsyncSessionLocal() as db:
            made = await generate_and_store(db, language_id=1, skill="reading", level="A1", count=1)
        out["noop_without_gemini"] = made == 0

    with patch("app.services.language_lesson_generation_service.generate_gemini_json", new=AsyncMock(return_value=MOCK_READING)), patch(
        "app.services.language_lesson_generation_service.get_level_curriculum",
        new=AsyncMock(return_value=[{"grammar": "present simple", "vocab": "daily life"}]),
    ), patch("app.services.language_lesson_generation_service.settings") as mock_settings:
        mock_settings.GEMINI_API_KEY = "test-key"
        from app.db.session import AsyncSessionLocal

        async with AsyncSessionLocal() as db:
            language = await get_default_language(db)
            inserted = await generate_and_store(
                db, language_id=language.id, skill="reading", level="A1", count=1
            )
            await db.rollback()
        out["generation_flow"] = inserted >= 0

    with patch("app.services.language_lesson_generation_service.generate_and_store", new=AsyncMock(return_value=0)), patch(
        "app.services.language_lesson_generation_service._published_count",
        new=AsyncMock(return_value=TARGET_PER_BUCKET),
    ):
        from app.db.session import AsyncSessionLocal

        async with AsyncSessionLocal() as db:
            summary = await run_nightly_topup(db, target=TARGET_PER_BUCKET)
        out["topup_skips_full_buckets"] = summary.get("_total") == 0

    return out


def main() -> int:
    static = static_checks()
    runtime = asyncio.run(runtime_checks())

    print("=== Phase 10.3 Nightly Lesson Generation ===\n")
    print("Static:")
    for k, v in static.items():
        print(f"  {k}: {'PASS' if v else 'FAIL'}")

    print("\nRuntime:")
    for k, v in runtime.items():
        print(f"  {k}: {'PASS' if v else 'FAIL'}")

    bool_checks = list(static.values()) + list(runtime.values())
    passed = sum(bool_checks)
    total = len(bool_checks)
    print(f"\n=== Results: {passed}/{total} checks passed ===")
    return 0 if all(bool_checks) else 1


if __name__ == "__main__":
    raise SystemExit(main())
