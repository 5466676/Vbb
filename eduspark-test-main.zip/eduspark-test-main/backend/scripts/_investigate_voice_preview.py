"""Investigate voice preview timeout — read-only trace."""
from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from pathlib import Path

import httpx
import psycopg2

BASE = "http://127.0.0.1:8000"
WORKER = "http://127.0.0.1:8010"
PREVIEW_TEXT = "مرحباً، أنا معلمك الذكي. سأشرح لك الدرس بأسلوبي المعتاد."
FRONTEND_TIMEOUT_S = 120


def ts() -> str:
    return datetime.now(timezone.utc).strftime("%H:%M:%S.%f")[:-3]


def db_sample() -> dict:
    conn = psycopg2.connect(
        host="localhost", port=5432, user="postgres", password="Hk2003hk123", dbname="eduspark"
    )
    cur = conn.cursor()
    cur.execute(
        """
        SELECT tvs.id, tvs.processing_status, tvs.storage_path, u.email, u.id
        FROM teacher_voice_samples tvs
        JOIN teacher_profiles tp ON tp.id = tvs.teacher_profile_id
        JOIN users u ON u.id = tp.user_id
        WHERE u.email = %s AND tvs.processing_status = 'ready'
        ORDER BY tvs.uploaded_at DESC LIMIT 1
        """,
        ("yaser@gmail.com",),
    )
    row = cur.fetchone()
    conn.close()
    if not row:
        return {}
    return {
        "sample_id": row[0],
        "status": row[1],
        "storage_path": row[2],
        "email": row[3],
        "user_id": row[4],
        "speaker_exists": Path(row[2]).exists() if row[2] else False,
        "speaker_bytes": Path(row[2]).stat().st_size if row[2] and Path(row[2]).exists() else 0,
    }


def login_teacher() -> str:
    for pwd in ("Hk2003hk123", "qwerty"):
        r = httpx.post(
            f"{BASE}/api/auth/login",
            json={"email": "yaser@gmail.com", "password": pwd},
            timeout=60,
        )
        if r.status_code == 200:
            return r.json()["access_token"]
    raise RuntimeError("teacher login failed")


def main() -> None:
    report: dict = {"timeline": [], "findings": {}}
    sample = db_sample()
    report["sample"] = sample
    if not sample:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return

    token = login_teacher()
    sample_id = sample["sample_id"]
    speaker = sample["storage_path"]

    # Direct worker baseline (same text/speaker as preview)
    report["timeline"].append({"t": ts(), "event": "worker_direct_start"})
    t0 = time.perf_counter()
    try:
        with open(speaker, "rb") as f:
            wr = httpx.post(
                f"{WORKER}/synthesize",
                data={"text": PREVIEW_TEXT, "language": "ar"},
                files={"speaker": ("sample.wav", f, "audio/wav")},
                timeout=600,
            )
        worker_ms = int((time.perf_counter() - t0) * 1000)
        report["worker_direct"] = {
            "status": wr.status_code,
            "ms": worker_ms,
            "bytes": len(wr.content) if wr.status_code == 200 else wr.text[:300],
        }
    except Exception as exc:
        report["worker_direct"] = {
            "error": type(exc).__name__,
            "message": str(exc)[:300],
            "ms": int((time.perf_counter() - t0) * 1000),
        }
    report["timeline"].append({"t": ts(), "event": "worker_direct_end", **report["worker_direct"]})

    # Backend preview endpoint — simulate frontend 120s timeout
    report["timeline"].append({"t": ts(), "event": "preview_api_start"})
    t1 = time.perf_counter()
    try:
        pr = httpx.post(
            f"{BASE}/api/teacher/voice-samples/{sample_id}/preview",
            json={"text": PREVIEW_TEXT},
            headers={"Authorization": f"Bearer {token}"},
            timeout=FRONTEND_TIMEOUT_S,
        )
        preview_ms = int((time.perf_counter() - t1) * 1000)
        report["preview_api_120s"] = {
            "status": pr.status_code,
            "ms": preview_ms,
            "body": pr.json() if pr.headers.get("content-type", "").startswith("application/json") else pr.text[:300],
        }
    except httpx.ReadTimeout as exc:
        preview_ms = int((time.perf_counter() - t1) * 1000)
        report["preview_api_120s"] = {
            "status": "TIMEOUT",
            "ms": preview_ms,
            "error": "ECONNABORTED",
            "frontend_message": "استغرقت المعالجة وقتاً أطول من المتوقع...",
            "detail": str(exc)[:200],
        }
    except Exception as exc:
        preview_ms = int((time.perf_counter() - t1) * 1000)
        report["preview_api_120s"] = {
            "status": "ERROR",
            "ms": preview_ms,
            "error": type(exc).__name__,
            "detail": str(exc)[:300],
        }
    report["timeline"].append({"t": ts(), "event": "preview_api_end", **report["preview_api_120s"]})

    # Check for generated preview files
    uploads = Path(
        r"c:\Users\oabo7\AppData\Local\Packages\5319275A.WhatsAppDesktop_cv1g1gvanyjgm\LocalState\sessions"
        r"\270D6E5E07462C2C46C99472527F70AF9E26797A\transfers\2026-21\eduspark-frontend-2"
        r"\eduspark-frontend-main\backend\uploads"
    )
    preview_files = sorted(uploads.rglob(f"voice_preview_{sample_id}_*.wav"), key=lambda p: p.stat().st_mtime, reverse=True)
    report["generated_files"] = [
        {"path": str(p), "bytes": p.stat().st_size, "mtime": datetime.fromtimestamp(p.stat().st_mtime).isoformat()}
        for p in preview_files[:5]
    ]

    # Diagnosis
    wd = report.get("worker_direct", {})
    pa = report.get("preview_api_120s", {})
    if pa.get("status") == "TIMEOUT":
        if wd.get("ms", 0) > FRONTEND_TIMEOUT_S * 1000:
            report["findings"]["failing_step"] = "XTTS worker synthesis exceeds frontend 120s timeout"
        elif wd.get("status") == 200 and wd.get("ms", 999999) <= FRONTEND_TIMEOUT_S * 1000:
            report["findings"]["failing_step"] = "Backend preview endpoint blocked/waiting despite worker being fast in isolation"
        else:
            report["findings"]["failing_step"] = "Preview HTTP request timed out at 120s (frontend axios timeout)"
    elif pa.get("status") == 200 and not (pa.get("body") or {}).get("audio_url"):
        report["findings"]["failing_step"] = "Backend returned 200 but no audio_url"
    elif pa.get("status") == 200:
        report["findings"]["failing_step"] = "Preview succeeded in test — failure may be intermittent or worker contention"

    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
