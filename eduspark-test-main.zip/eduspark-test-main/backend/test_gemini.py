import os, sys, json, re
sys.path.insert(0, r"c:\Users\LEGION\Music\the last one\eduspark\backend")
os.chdir(r"c:\Users\LEGION\Music\the last one\eduspark\backend")

from dotenv import load_dotenv
load_dotenv()
import google.generativeai as genai

api_key = os.getenv("GEMINI_API_KEY")
genai.configure(api_key=api_key)
model = genai.GenerativeModel("gemini-3.5-flash")

OUT = r"c:\Users\LEGION\Music\the last one\gemini_test.txt"
open(OUT, "w", encoding="utf-8").close()

def log(s):
    with open(OUT, "a", encoding="utf-8") as f:
        f.write(s + "\n")

def test_msg(msg, label, start_anchor="وصول البيت بعد 13:30", sleep_time="23:00", day="الاثنين"):
    log(f"\n--- {label} ---")
    log(f"Input: {msg}")
    prompt = (
        f"أنت مساعد ذكي يفهم العربية الدارجة (سورية/لبنانية/خليجية).\n\n"
        f"الطالب يصف يوم {day}. معلومات ثابتة: بداية اليوم={start_anchor}، نوم={sleep_time}.\n\n"
        f'رسالة الطالب: "{msg}"\n\n'
        f"مهمتك: اكتب ملخصاً لأنشطة اليوم بأوقات منطقية.\n\n"
        f"قواعد الاستنتاج السريع:\n"
        f'• "شي X" = الساعة X (مثلاً "شي 2"=14:00)\n'
        f'• "بعد الضهر"≈14:30، "العصر"≈15:30، "المغرب"≈18:00، "العشا"≈20:00\n'
        f'• "درست/درس"=90 دقيقة، "رياضة"=60 دقيقة، "قيلولة"=60 دقيقة، "أكل"=30 دقيقة\n\n'
        f"قاعدة: إذا الرسالة تحتوي على أي نشاط → اكتب الملخص. لا تُرجع activities فارغة إلا إذا الرسالة فارغة تماماً.\n\n"
        f"أرجع JSON فقط:\n"
        f'{{"activities": "ملخص اليوم بالأوقات"}}'
    )
    try:
        resp = model.generate_content(prompt)
        raw = resp.text
        log(f"Raw response: {repr(raw[:500])}")
        m = re.search(r'\{[\s\S]*\}', raw)
        if m:
            try:
                parsed = json.loads(m.group())
                acts = parsed.get("activities", "")
                log(f"Activities: '{acts[:200]}'")
                log(f"Empty: {not bool(acts)}")
            except Exception as je:
                log(f"JSON parse error: {je}")
                log(f"Matched: {m.group()[:200]}")
        else:
            log("NO JSON FOUND in response")
    except Exception as e:
        log(f"API ERROR: {e}")

test_msg("رجعت 14، نمت قيلولة ساعة، درست فيزياء ساعة ونص، عشيت ونمت", "Test 1: failing message")
test_msg("رجعت من المدرسة، درست ساعتين، لعبت مع أصحابي، بحكيت مع العيلة، عشيت ونمت", "Test 2: casual")
test_msg("", "Test 3: empty")
test_msg("عادي", "Test 4: single word")

log("\nDone")
