"""Baseline migration placeholder.

Revision ID: 0001_baseline
Revises:
Create Date: 2026-05-28

This repository previously relied on `create_all()` + ad-hoc schema patches.
Going forward, all schema changes must be captured in Alembic migrations.

IMPORTANT:
You should generate a real baseline migration against your current production
database by running:

    alembic revision --autogenerate -m "baseline"

Then review and replace this placeholder.
"""

from alembic import op

# revision identifiers, used by Alembic.
revision = "0001_baseline"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Intentionally empty: placeholder to establish Alembic infrastructure.
    pass


def downgrade() -> None:
    pass

